package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;

import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2443;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3218;

public final class SwitchRailRouting {
    private SwitchRailRouting() {}

    public static class_2768 shapeFor(class_2350 travel, int choice) {
        if (travel.method_10166() == class_2350.class_2351.field_11052) return class_2768.field_12665;
        class_2350 entry = travel.method_10153();
        class_2350 exit = switch (cn.quit5700.fabrictrain.compat.MathCompat.clamp(choice, 0, 2)) {
            case 0 -> travel.method_10160();
            case 2 -> travel.method_10170();
            default -> travel;
        };
        return shapeBetween(entry, exit);
    }

    public static class_2350 exitFor(class_2350 entry, int choice) {
        if (entry.method_10166() == class_2350.class_2351.field_11052) entry = class_2350.field_11043;
        class_2350 travel = entry.method_10153();
        return switch (cn.quit5700.fabrictrain.compat.MathCompat.clamp(choice, 0, 2)) {
            case 0 -> travel.method_10160();
            case 2 -> travel.method_10170();
            default -> travel;
        };
    }

    public static class_2768 shapeForEntry(class_2350 entry, int choice) {
        return shapeBetween(entry, exitFor(entry, choice));
    }

    public static Optional<class_2768> shapeForFixedChoice(class_2350 fixedEntry, class_2350 travel, int choice) {
        if (travel.method_10166() == class_2350.class_2351.field_11052) return Optional.empty();
        class_2350 incomingSide = travel.method_10153();
        class_2350 fixedExit = exitFor(fixedEntry, choice);
        if (incomingSide == fixedExit) return Optional.empty();
        return Optional.of(shapeBetween(incomingSide, fixedExit));
    }

    public static class_2350 entryFor(RailwayDevice device, class_2680 state) {
        class_2350 placement = state.method_28498(DeviceRailBlock.PLACEMENT_ENTRY)
                ? state.method_11654(DeviceRailBlock.PLACEMENT_ENTRY)
                : state.method_11654(DeviceRailBlock.ENTRY_DIRECTION);
        return SwitchEntryDirectionRules.resolve(device.switchEntryOrdinal(), placement);
    }

    public static class_2768 shapeBetween(class_2350 first, class_2350 second) {
        if ((first == class_2350.field_11043 && second == class_2350.field_11035)
                || (first == class_2350.field_11035 && second == class_2350.field_11043)) return class_2768.field_12665;
        if ((first == class_2350.field_11034 && second == class_2350.field_11039)
                || (first == class_2350.field_11039 && second == class_2350.field_11034)) return class_2768.field_12674;
        if (contains(first, second, class_2350.field_11043, class_2350.field_11034)) return class_2768.field_12663;
        if (contains(first, second, class_2350.field_11043, class_2350.field_11039)) return class_2768.field_12672;
        if (contains(first, second, class_2350.field_11035, class_2350.field_11034)) return class_2768.field_12664;
        return class_2768.field_12671;
    }

    private static boolean contains(class_2350 first, class_2350 second, class_2350 expectedFirst, class_2350 expectedSecond) {
        return (first == expectedFirst && second == expectedSecond)
                || (first == expectedSecond && second == expectedFirst);
    }

    public static void applyChoice(class_3218 level, RailwayDevice before, int newChoice) {
        class_2338 pos = new class_2338(before.x(), before.y(), before.z());
        class_2680 state = level.method_8320(pos);
        if (!state.method_27852(ModBlocks.SWITCH_RAIL) || !state.method_28498(class_2443.field_11369)) return;
        int choice = cn.quit5700.fabrictrain.compat.MathCompat.clamp(newChoice, 0, 2);
        class_2350 entry = entryFor(before, state);
        level.method_8652(pos, state.method_11657(DeviceRailBlock.SWITCH_CHOICE, choice)
                .method_11657(DeviceRailBlock.ENTRY_DIRECTION, entry)
                .method_11657(class_2443.field_11369, shapeForEntry(entry, choice)), 3);
    }

    public static void applySettings(class_3218 level, RailwayDevice device, int newChoice, class_2350 entry) {
        class_2338 pos = new class_2338(device.x(), device.y(), device.z());
        class_2680 state = level.method_8320(pos);
        if (!state.method_27852(ModBlocks.SWITCH_RAIL) || !state.method_28498(class_2443.field_11369)) return;
        int choice = cn.quit5700.fabrictrain.compat.MathCompat.clamp(newChoice, 0, 2);
        level.method_8652(pos, state.method_11657(DeviceRailBlock.SWITCH_CHOICE, choice)
                .method_11657(DeviceRailBlock.ENTRY_DIRECTION, entry)
                .method_11657(class_2443.field_11369, shapeForEntry(entry, choice)), 3);
    }
}

