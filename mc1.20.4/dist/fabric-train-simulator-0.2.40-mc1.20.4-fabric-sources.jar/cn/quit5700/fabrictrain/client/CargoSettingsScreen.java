package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.CargoSettingsNetworking;
import cn.quit5700.fabrictrain.network.LegacyClientPlayNetworking;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class CargoSettingsScreen extends class_437 {
    private final int entityId;
    private final List<CargoSettingsNetworking.Station> stations;
    /** Zero is the explicit empty/inherit choice; station entries start at one. */
    private int selectedIndex;
    private int dropdownOffset;
    private boolean dropdownOpen;

    public CargoSettingsScreen(CargoSettingsNetworking.OpenPayload payload) {
        super(class_2561.method_43471("screen.fabric_train_simulator.cargo.title"));
        entityId = payload.entityId();
        stations = payload.stations();
        selectedIndex = 0;
        for (int i = 0; i < stations.size(); i++)
            if (stations.get(i).id() == payload.selectedStationId()) selectedIndex = i + 1;
    }

    @Override protected void method_25426() {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 240, 220, 20);
        int left = layout.left() + 10;
        int top = layout.top();
        int contentWidth = layout.panelWidth() - 20;
        method_37063(class_4185.method_46430(selectedLabel(), button -> {
            dropdownOpen = !dropdownOpen;
            method_41843();
        }).method_46434(left, top + 43, contentWidth, 20).method_46431());

        if (dropdownOpen) addDropdownOptions(layout, left, top + 65, contentWidth);

        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.cargo.unload_all"), button -> {
            LegacyClientPlayNetworking.send(new CargoSettingsNetworking.UnloadAllPayload(entityId));
            method_25419();
        }).method_46434(left, layout.footerY() - 24, contentWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.cargo.save"), button -> save())
                .method_46434(layout.left() + (layout.panelWidth() - 70) / 2, layout.footerY(), 70, 20).method_46431());
    }

    private void addDropdownOptions(ResponsiveScreenLayout layout, int left, int firstY, int width) {
        int availableRows = Math.max(1, Math.min(5, (layout.footerY() - 30 - firstY) / 20));
        int optionCount = stations.size() + 1;
        int maximumOffset = Math.max(0, optionCount - availableRows);
        dropdownOffset = cn.quit5700.fabrictrain.compat.MathCompat.clamp(dropdownOffset, 0, maximumOffset);
        for (int row = 0; row < availableRows && dropdownOffset + row < optionCount; row++) {
            int option = dropdownOffset + row;
            class_2561 label = option == 0
                    ? class_2561.method_43471("screen.fabric_train_simulator.cargo.inherit")
                    : class_2561.method_43470(stations.get(option - 1).name());
            method_37063(class_4185.method_46430(label, button -> {
                selectedIndex = option;
                dropdownOpen = false;
                method_41843();
            }).method_46434(left, firstY + row * 20, width, 20).method_46431());
        }
    }

    private class_2561 selectedLabel() {
        class_2561 value = selectedIndex == 0
                ? class_2561.method_43471("screen.fabric_train_simulator.cargo.inherit")
                : class_2561.method_43470(stations.get(selectedIndex - 1).name());
        return value.method_27661().method_27693(" ▼");
    }

    private void save() {
        long stationId = selectedIndex == 0 ? 0L : stations.get(selectedIndex - 1).id();
        LegacyClientPlayNetworking.send(new CargoSettingsNetworking.UpdatePayload(entityId, stationId));
        method_25419();
    }

    @Override public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        if (!dropdownOpen) return super.method_25401(mouseX, mouseY, horizontal, vertical);
        int next = cn.quit5700.fabrictrain.compat.MathCompat.clamp(dropdownOffset - (int) Math.signum(vertical), 0, Math.max(0, stations.size()));
        if (next == dropdownOffset) return false;
        dropdownOffset = next;
        method_41843();
        return true;
    }

    @Override public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 240, 220, 20);
        int top = layout.top();
        graphics.method_25294(layout.left(), top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_49601(layout.left(), top, layout.panelWidth(), layout.panelHeight(), 0xFFFFA64D);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 10, 0xFFFFFFFF);
        graphics.method_27535(field_22793, class_2561.method_43471("screen.fabric_train_simulator.cargo.destination_label"),
                layout.left() + 10, top + 30, 0xFFCCCCCC);
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }
}



