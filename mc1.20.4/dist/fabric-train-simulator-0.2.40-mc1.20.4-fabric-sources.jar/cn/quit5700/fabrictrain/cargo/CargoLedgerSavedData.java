package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_4284;

public final class CargoLedgerSavedData extends class_18 {
    public static final Codec<CargoLedgerSavedData> CODEC = PendingDelivery.CODEC.listOf()
            .optionalFieldOf("deliveries", List.of()).codec()
            .xmap(CargoLedgerSavedData::new, data -> List.copyOf(data.deliveries));
    public static final String DATA_ID = FabricTrainMod.MOD_ID + "_cargo_ledger";
    public static final class_18.class_8645<CargoLedgerSavedData> TYPE = new class_18.class_8645<>(
            CargoLedgerSavedData::new, CargoLedgerSavedData::load, class_4284.field_19212);

    private final ArrayList<PendingDelivery> deliveries;

    public CargoLedgerSavedData() { this(List.of()); }
    private CargoLedgerSavedData(List<PendingDelivery> deliveries) { this.deliveries = new ArrayList<>(deliveries); }

    public synchronized boolean containsSource(UUID sourceCarId) {
        return deliveries.stream().anyMatch(delivery -> delivery.sourceCarId().equals(sourceCarId));
    }

    public synchronized void add(PendingDelivery delivery) {
        if (deliveries.stream().anyMatch(existing -> existing.shipmentId().equals(delivery.shipmentId()))) return;
        deliveries.add(delivery);
        method_80();
    }

    public synchronized List<PendingDelivery> deliveries() { return List.copyOf(deliveries); }

    public synchronized void replace(PendingDelivery oldDelivery, PendingDelivery updated) {
        int index = deliveries.indexOf(oldDelivery);
        if (index >= 0) {
            if (updated.stacks().isEmpty()) deliveries.remove(index); else deliveries.set(index, updated);
            method_80();
        }
    }

    private static CargoLedgerSavedData load(class_2487 tag) {
        return CODEC.parse(class_2509.field_11560, tag)
                .result().orElseGet(CargoLedgerSavedData::new);
    }

    @Override public class_2487 method_75(class_2487 tag) {
        return CODEC.encodeStart(class_2509.field_11560, this)
                .result().filter(class_2487.class::isInstance).map(class_2487.class::cast).orElse(tag);
    }
}
