package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwaySavedData;
import cn.quit5700.fabrictrain.data.TrainManifest;

public final class TrainFormationService {
    public enum PairResult {
        CONNECTED, DISCONNECTED, CANCELLED, NOT_ADJACENT,
        TOO_FAR, TOO_LONG, TWO_LOCOMOTIVES, MIXED_ORIGIN, NO_CONTINUOUS_TRACK, FAILED
    }

    private TrainFormationService() {
    }

    private static PairResult connectPair(class_1297 first, class_1297 second) {
        List<class_1297> left = formation(first);
        List<class_1297> right = formation(second);
        ControlMode leftMode = ((LinkedTrainCar) first).trainLink().controlMode();
        ControlMode rightMode = ((LinkedTrainCar) second).trainLink().controlMode();
        UUID leftTrainId = ((LinkedTrainCar) first).trainLink().trainId();
        UUID rightTrainId = ((LinkedTrainCar) second).trainLink().trainId();
        if (!TrainRegistryRules.canMerge(leftMode, rightMode)) return PairResult.MIXED_ORIGIN;
        if (!ConnectorRules.canMerge(left.size(), right.size())) return PairResult.TOO_LONG;
        ArrayList<class_1297> joined = mergeOrder(left, right);
        List<LocomotiveEntity> locomotives = joined.stream().filter(LocomotiveEntity.class::isInstance)
                .map(LocomotiveEntity.class::cast).toList();
        if (locomotives.size() > 1) return PairResult.TWO_LOCOMOTIVES;
        if (locomotives.size() == 1) {
            int locomotiveIndex = joined.indexOf(locomotives.get(0));
            if (locomotiveIndex != 0 && locomotiveIndex != joined.size() - 1) return PairResult.FAILED;
            if (locomotiveIndex == joined.size() - 1) Collections.reverse(joined);
        }
        class_2350 formationForward = locomotives.isEmpty() ? null
                : locomotives.get(0).trainLink().formationForward().orElseGet(() -> joined.size() < 2 ? null
                : FormationDirection.fromPositions(locomotives.get(0).method_23317(), locomotives.get(0).method_23321(),
                joined.get(1).method_23317(), joined.get(1).method_23321()).orElse(null));
        if(formationForward!=null&&!locomotives.isEmpty())locomotives.get(0).method_36456(yaw(formationForward));
        if (!(first.method_37908() instanceof class_3218 serverLevel)
                || !RailFormationPlacer.place(serverLevel, joined, first, second)) {
            return PairResult.NO_CONTINUOUS_TRACK;
        }
        UUID inherited = locomotives.size() == 1
                ? ((LinkedTrainCar) locomotives.get(0)).trainLink().trainId()
                : ((LinkedTrainCar) first).trainLink().trainId();
        boolean depotGenerated=joined.stream().anyMatch(entity->((LinkedTrainCar)entity).trainLink().depotGenerated());
        double speedLimit=((LinkedTrainCar)(locomotives.isEmpty()?first:locomotives.get(0))).trainLink().configuredSpeedLimitKmh();
        assignFormation(joined, inherited, depotGenerated, leftMode, speedLimit, formationForward);
        if (!leftTrainId.equals(inherited)) RailwayDataManager.state(serverLevel).removeTrainRecord(leftTrainId);
        if (!rightTrainId.equals(inherited)) RailwayDataManager.state(serverLevel).removeTrainRecord(rightTrainId);
        TrainControllerManager.resetFormation(inherited, joined);
        first.method_37908().method_8396(null, first.method_24515(), class_3417.field_24063, class_3419.field_15245, 1, 1);
        return PairResult.CONNECTED;
    }

    public static PairResult operatePair(class_1297 first, class_1297 second) {
        if (!(first instanceof LinkedTrainCar firstCar) || !(second instanceof LinkedTrainCar secondCar)
                || first.method_37908() != second.method_37908()) {
            return PairResult.FAILED;
        }
        boolean sameEntity = first == second;
        if (sameEntity) return PairResult.CANCELLED;
        if (!ConnectorRules.withinRange(first.method_5858(second))) return PairResult.TOO_FAR;
        boolean sameFormation = firstCar.trainLink().trainId().equals(secondCar.trainLink().trainId());
        ConnectorActionRules.Action action = ConnectorActionRules.decide(sameEntity, sameFormation,
                firstCar.trainLink().carIndex(), secondCar.trainLink().carIndex());
        return switch (action) {
            case CANCEL_SELECTION -> PairResult.CANCELLED;
            case REJECT_NON_ADJACENT -> PairResult.NOT_ADJACENT;
            case CONNECT -> connectPair(first, second);
            case DISCONNECT_ADJACENT -> splitBetween(first, second)
                    ? PairResult.DISCONNECTED : PairResult.FAILED;
        };
    }

    private static ArrayList<class_1297> mergeOrder(List<class_1297> leftSource, List<class_1297> rightSource) {
        ArrayList<class_1297> left = new ArrayList<>(leftSource);
        ArrayList<class_1297> right = new ArrayList<>(rightSource);
        boolean leftHasLocomotive = left.stream().anyMatch(LocomotiveEntity.class::isInstance);
        boolean rightHasLocomotive = right.stream().anyMatch(LocomotiveEntity.class::isInstance);
        if (leftHasLocomotive ^ rightHasLocomotive) {
            ArrayList<class_1297> base = leftHasLocomotive ? left : right;
            ArrayList<class_1297> addon = leftHasLocomotive ? right : left;
            int locomotiveIndex = indexOfLocomotive(base);
            if (locomotiveIndex == base.size() - 1) Collections.reverse(base);
            if (!addon.isEmpty() && base.get(base.size() - 1).method_5858(addon.get(addon.size() - 1))
                    < base.get(base.size() - 1).method_5858(addon.get(0))) Collections.reverse(addon);
            base.addAll(addon);
            return base;
        }
        double normal = left.get(left.size() - 1).method_5858(right.get(0));
        double reverseRight = left.get(left.size() - 1).method_5858(right.get(right.size() - 1));
        double reverseLeft = left.get(0).method_5858(right.get(0));
        double reverseBoth = left.get(0).method_5858(right.get(right.size() - 1));
        double best = Math.min(Math.min(normal, reverseRight), Math.min(reverseLeft, reverseBoth));
        if (best == reverseLeft || best == reverseBoth) Collections.reverse(left);
        if (best == reverseRight || best == reverseBoth) Collections.reverse(right);
        left.addAll(right);
        return left;
    }

    private static int indexOfLocomotive(List<class_1297> group) {
        for (int index = 0; index < group.size(); index++) if (group.get(index) instanceof LocomotiveEntity) return index;
        return -1;
    }

    private static boolean splitBetween(class_1297 first, class_1297 second) {
        List<class_1297> ordered = formation(first);
        int firstIndex = ordered.indexOf(first);
        int secondIndex = ordered.indexOf(second);
        if (firstIndex < 0 || secondIndex < 0 || Math.abs(firstIndex - secondIndex) != 1) return false;
        int splitIndex = Math.max(firstIndex, secondIndex);
        List<class_1297> front = new ArrayList<>(ordered.subList(0, splitIndex));
        List<class_1297> rear = new ArrayList<>(ordered.subList(splitIndex, ordered.size()));
        if (front.isEmpty() || rear.isEmpty()) return false;
        UUID original = ((LinkedTrainCar) first).trainLink().trainId();
        boolean depotGenerated = ((LinkedTrainCar) first).trainLink().depotGenerated();
        ControlMode controlMode=((LinkedTrainCar)first).trainLink().controlMode();
        double speedLimit=((LinkedTrainCar)first).trainLink().configuredSpeedLimitKmh();
        class_2350 formationForward=((LinkedTrainCar)first).trainLink().formationForward().orElse(null);
        boolean frontHasLocomotive = front.stream().anyMatch(LocomotiveEntity.class::isInstance);
        boolean rearHasLocomotive = rear.stream().anyMatch(LocomotiveEntity.class::isInstance);
        ControlMode frontMode = frontHasLocomotive ? controlMode : ControlMode.MANUAL;
        ControlMode rearMode = rearHasLocomotive ? controlMode : ControlMode.MANUAL;
        if (TrainRegistryRules.inheritedSide(frontHasLocomotive, rearHasLocomotive) == 1) {
            assignFormation(rear, original, depotGenerated, rearMode, speedLimit, formationForward);
            assignFormation(front, UUID.randomUUID(), depotGenerated, frontMode, speedLimit, formationForward);
        } else {
            assignFormation(front, original, depotGenerated, frontMode, speedLimit, formationForward);
            assignFormation(rear, UUID.randomUUID(), depotGenerated, rearMode, speedLimit, formationForward);
        }
        TrainControllerManager.resetFormation(((LinkedTrainCar) front.get(0)).trainLink().trainId(), front);
        TrainControllerManager.resetFormation(((LinkedTrainCar) rear.get(0)).trainLink().trainId(), rear);
        first.method_37908().method_8396(null, first.method_24515(), class_3417.field_24065, class_3419.field_15245, 1, 1);
        return true;
    }

    public static List<class_1297> formation(class_1297 seed) {
        if (!(seed instanceof LinkedTrainCar linked)) return List.of();
        UUID trainId = linked.trainLink().trainId();
        ArrayList<class_1297> result = new ArrayList<>();
        for (class_1297 entity : seed.method_37908().method_8333(seed, seed.method_5829().method_1014(160),
                entity -> entity instanceof LinkedTrainCar candidate
                        && ((LinkedTrainCar) candidate).trainLink().trainId().equals(trainId))) result.add(entity);
        if (!result.contains(seed)) result.add(seed);
        result.sort(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()));
        return result;
    }

    public static int dissolve(class_1297 seed) {
        List<class_1297> formation = formation(seed);
        UUID original = ((LinkedTrainCar) seed).trainLink().trainId();
        if (seed.method_37908() instanceof class_3218 level) {
            RailwaySavedData data = RailwayDataManager.state(level);
            var oldManifest = data.trainManifest(original);
            long originDepotNumber = oldManifest == null
                    ? ((LinkedTrainCar) seed).trainLink().originDepotNumber()
                    : oldManifest.originDepotNumber();
            formation.forEach(entity -> {
                TrainLink link = ((LinkedTrainCar) entity).trainLink();
                link.detach(entity.method_5667());
                link.setControlMode(ControlMode.MANUAL);
            });
            data.removeTrainRecord(original);
            formation.forEach(entity -> {
                data.ensureTrain(entity.method_5667(),
                        ((LinkedTrainCar) entity).trainLink().depotGenerated(), 0L,
                        ControlMode.MANUAL);
                TrainRegistryService.replaceFormation(level, entity.method_5667(), List.of(entity), originDepotNumber);
            });
        } else {
            formation.forEach(entity -> ((LinkedTrainCar) entity).trainLink().detach(entity.method_5667()));
        }
        if (!formation.isEmpty())
            seed.method_37908().method_8396(null, seed.method_24515(), class_3417.field_24065, class_3419.field_15245, 1, 1);
        return formation.size();
    }

    public static boolean reorder(class_1297 seed, List<Integer> entityIds) {
        List<class_1297> current = formation(seed);
        if (entityIds.size() != current.size()) return false;
        Map<Integer, class_1297> byId = new HashMap<>();
        current.forEach(entity -> byId.put(entity.method_5628(), entity));
        ArrayList<class_1297> ordered = new ArrayList<>();
        for (int id : entityIds) {
            class_1297 entity = byId.remove(id);
            if (entity == null) return false;
            ordered.add(entity);
        }
        int locomotiveIndex = -1;
        for (int i = 0; i < ordered.size(); i++)
            if (ordered.get(i) instanceof LocomotiveEntity) {
                if (locomotiveIndex >= 0) return false;
                locomotiveIndex = i;
        }
        if (locomotiveIndex > 0 && locomotiveIndex < ordered.size() - 1) return false;
        if (locomotiveIndex == ordered.size() - 1) Collections.reverse(ordered);
        TrainLink seedLink=((LinkedTrainCar)seed).trainLink();
        assignFormation(ordered, seedLink.trainId(), seedLink.depotGenerated(),
                seedLink.controlMode(),seedLink.configuredSpeedLimitKmh(),seedLink.formationForward().orElse(null));
        normalizePositions(ordered);
        return true;
    }

    private static void orientEndpoint(List<class_1297> group, class_1297 selected, boolean selectedFirst) {
        int index = group.indexOf(selected);
        if ((selectedFirst && index == group.size() - 1) || (!selectedFirst && index == 0)) Collections.reverse(group);
    }

    private static void assignFormation(List<class_1297> ordered) {
        UUID trainId = UUID.randomUUID();
        boolean depotGenerated = ordered.stream().anyMatch(entity ->
                ((LinkedTrainCar) entity).trainLink().depotGenerated());
        TrainLink source=((LinkedTrainCar)ordered.get(0)).trainLink();
        assignFormation(ordered, trainId, depotGenerated,source.controlMode(),source.configuredSpeedLimitKmh(),
                source.formationForward().orElse(null));
    }

    private static void assignFormation(List<class_1297> ordered, UUID trainId, boolean depotGenerated,
                                        ControlMode controlMode,double speedLimitKmh,class_2350 formationForward) {
        long originDepotNumber = ordered.stream().map(entity -> ((LinkedTrainCar) entity).trainLink())
                .mapToLong(TrainLink::originDepotNumber).filter(value -> value > 0L).findFirst().orElse(0L);
        LocomotiveEntity locomotive = ordered.stream().filter(LocomotiveEntity.class::isInstance)
                .map(LocomotiveEntity.class::cast).findFirst().orElse(null);
        long lineId = locomotive == null ? 0 : locomotive.trainLink().lineId();
        long locomotiveDestination = locomotive == null ? 0L : locomotive.trainLink().destinationStationId();
        TrainClass trainClass = ordered.stream().anyMatch(CargoCarEntity.class::isInstance)
                ? TrainClass.CARGO : locomotive == null ? TrainClass.PASSENGER : locomotive.trainLink().trainClass();
        for (int i = 0; i < ordered.size(); i++) {
            LinkedTrainCar car = (LinkedTrainCar) ordered.get(i);
            if (locomotive == null) car.trainLink().assignWithoutLocomotive(trainId, i);
            else car.trainLink().assign(trainId, locomotive.method_5667(), i, lineId);
            car.trainLink().setTrainClass(trainClass);
            car.trainLink().setDepotGenerated(depotGenerated);
            car.trainLink().setControlMode(controlMode);
            car.trainLink().setConfiguredSpeedLimitKmh(speedLimitKmh);
            if(locomotive==null)car.trainLink().clearFormationForward();
            else car.trainLink().setFormationForward(formationForward);
            if(car instanceof CargoCarEntity cargo&&locomotive!=null){
                // A zero carriage destination remains an explicit "inherit" marker. The shared
                // TrainLink value carries the locomotive default without overwriting the carriage.
                car.trainLink().setDestinationStationId(locomotiveDestination);
            }
        }
        if (!ordered.isEmpty() && ordered.get(0).method_37908() instanceof class_3218 level) {
            RailwayDataManager.state(level).ensureTrain(trainId, depotGenerated, lineId,controlMode);
            TrainRegistryService.replaceFormation(level, trainId, ordered, originDepotNumber);
        }
    }

    private static void normalizePositions(List<class_1297> ordered) {
        if (ordered.size() < 2) return;
        class_1297 leader = ordered.get(0);
        for (int i = 1; i < ordered.size(); i++) {
            class_1297 car = ordered.get(i);
            car.method_33574(FormationGeometry.anchor(leader.method_19538(), car.method_19538(), i * FormationSpacing.BLOCKS));
            car.method_18799(net.minecraft.class_243.field_1353);
        }
        leader.method_18799(net.minecraft.class_243.field_1353);
    }

    public static int linkNearbyCars(LocomotiveEntity locomotive, long lineId) {
        return 0;
    }

    public static int linkCarGroup(LocomotiveEntity locomotive, class_1297 touchedCar, long lineId) {
        if (!(touchedCar instanceof LinkedTrainCar seed) || seed.trainLink().hasLocomotive()) return 0;
        UUID oldGroup = seed.trainLink().trainId();
        List<class_1297> candidates = new ArrayList<>();
        for (class_1297 entity : locomotive.method_37908().method_8333(locomotive, locomotive.method_5829().method_1014(160.0D),
                entity -> entity instanceof LinkedTrainCar linked && !(entity instanceof LocomotiveEntity)
                        && !linked.trainLink().hasLocomotive())) {
            if (((LinkedTrainCar) entity).trainLink().trainId().equals(oldGroup)) candidates.add(entity);
        }
        if (candidates.isEmpty()) candidates.add(touchedCar);
        List<class_1297> ordered = orderFrom(locomotive, candidates);
        class_2350 formationForward=locomotive.trainLink().formationForward().orElseGet(()->
                FormationDirection.fromPositions(locomotive.method_23317(),locomotive.method_23321(),
                        ordered.get(0).method_23317(),ordered.get(0).method_23321()).orElse(null));
        if(formationForward!=null)locomotive.method_36456(yaw(formationForward));
        UUID trainId = locomotive.trainLink().trainId();
        locomotive.trainLink().assign(trainId, locomotive.method_5667(), 0, lineId);
        locomotive.trainLink().setFormationForward(formationForward);
        for (int index=0;index<ordered.size();index++)
        {
            LinkedTrainCar linked=(LinkedTrainCar)ordered.get(index);
            linked.trainLink().assign(trainId,locomotive.method_5667(),index+1,lineId);
            linked.trainLink().setFormationForward(formationForward);
        }
        boolean cargo=ordered.stream().anyMatch(CargoCarEntity.class::isInstance);
        locomotive.trainLink().setTrainClass(cargo?TrainClass.CARGO:locomotive.trainLink().trainClass());
        ordered.forEach(entity->((LinkedTrainCar)entity).trainLink().setTrainClass(locomotive.trainLink().trainClass()));
        locomotive.method_37908().method_8396(null,locomotive.method_24515(),class_3417.field_24063,class_3419.field_15245,1,1);
        if(lineId>0&&locomotive.method_37908() instanceof class_3218 serverLevel)
            RailwayDataManager.state(serverLevel).registerActiveTrain(trainId,lineId);
        if (locomotive.method_37908() instanceof class_3218 serverLevel) {
            ArrayList<class_1297> formation = new ArrayList<>();
            formation.add(locomotive);
            formation.addAll(ordered);
            TrainRegistryService.replaceFormation(serverLevel, trainId, formation);
            RailwayDataManager.state(serverLevel).removeTrainRecord(oldGroup);
        }
        return ordered.size();
    }

    public static boolean mergeCarOnlyGroups(class_1297 first, class_1297 second) {
        if (!(first instanceof LinkedTrainCar a) || !(second instanceof LinkedTrainCar b)
                || first instanceof LocomotiveEntity || second instanceof LocomotiveEntity
                || a.trainLink().hasLocomotive() || b.trainLink().hasLocomotive()
                || a.trainLink().trainId().equals(b.trainLink().trainId())) return false;
        UUID firstGroup=a.trainLink().trainId(),secondGroup=b.trainLink().trainId();
        List<class_1297> members=new ArrayList<>();
        for(class_1297 entity:first.method_37908().method_8333(first,first.method_5829().method_1014(160),
                entity->entity instanceof LinkedTrainCar linked&&!(entity instanceof LocomotiveEntity)
                        &&!linked.trainLink().hasLocomotive())) {
            UUID id=((LinkedTrainCar)entity).trainLink().trainId();
            if(id.equals(firstGroup)||id.equals(secondGroup))members.add(entity);
        }
        if(!members.contains(first))members.add(first);if(!members.contains(second))members.add(second);
        class_1297 start = members.stream().filter(cn.quit5700.fabrictrain.entity.PassengerCarEntity.class::isInstance)
                .findFirst().orElse(first);
        List<class_1297> ordered=orderFrom(start,members);UUID group=firstGroup;
        for(int i=0;i<ordered.size();i++)((LinkedTrainCar)ordered.get(i)).trainLink().assignWithoutLocomotive(group,i);
        if (first.method_37908() instanceof class_3218 serverLevel) {
            TrainRegistryService.replaceFormation(serverLevel, group, ordered);
            RailwayDataManager.state(serverLevel).removeTrainRecord(secondGroup);
        }
        first.method_37908().method_8396(null,first.method_24515(),class_3417.field_24063,class_3419.field_15245,1,1);
        return true;
    }

    public static boolean hasAttachedCars(LocomotiveEntity locomotive) {
        UUID train=locomotive.trainLink().trainId();
        for(class_1297 entity:locomotive.method_37908().method_8333(locomotive,locomotive.method_5829().method_1014(160),
                entity->entity instanceof LinkedTrainCar&&entity!=locomotive))
            if(((LinkedTrainCar)entity).trainLink().hasLocomotive()
                    &&((LinkedTrainCar)entity).trainLink().trainId().equals(train))return true;
        return false;
    }

    private static List<class_1297> orderFrom(class_1297 start,List<class_1297> values){
        ArrayList<class_1297> remaining=new ArrayList<>(values),result=new ArrayList<>();class_1297 cursor=start;
        while(!remaining.isEmpty()){class_1297 next=nearest(cursor,remaining);result.add(next);remaining.remove(next);cursor=next;}
        return result;
    }

    public static int detachFrom(class_1297 selected){
        return 0;
    }

    private static class_1297 nearest(class_1297 source, List<class_1297> candidates) {
        return candidates.stream().min(Comparator.comparingDouble(source::method_5858)).orElse(null);
    }

    private static float yaw(class_2350 direction){
        return (float)Math.toDegrees(Math.atan2(-direction.method_10148(),direction.method_10165()));
    }
}

