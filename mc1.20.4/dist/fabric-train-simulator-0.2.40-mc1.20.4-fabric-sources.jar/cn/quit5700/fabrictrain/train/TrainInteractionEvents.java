package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.item.LineSetterItem;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.data.*;
import java.util.List;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.TrainClassNetworking;
import cn.quit5700.fabrictrain.network.CargoSettingsNetworking;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;

public final class TrainInteractionEvents {
    private TrainInteractionEvents() {
    }

    public static void register() {
        UseBlockCallback.EVENT.register(DeviceInteractionService::interact);
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) ->
                ConnectorInteractionService.attack(player, hand, entity));
        AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) ->
                player.method_5998(hand).method_31574(ModItems.TRAIN_CONNECTOR)
                        ? class_1269.field_5814 : class_1269.field_5811);
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (entity instanceof LinkedTrainCar linked) TrainControllerManager.noteInteraction(linked);
            if (entity instanceof LinkedTrainCar && player.method_5998(hand).method_31574(ModItems.TRAIN_CONNECTOR))
                return ConnectorInteractionService.rightClick(player, hand, entity);
            if (entity instanceof PassengerCarEntity && !player.method_5715()
                    && !player.method_5998(hand).method_31574(ModItems.LINE_SETTER)) {
                if (!level.method_8608()) player.method_5804(entity);
                return class_1269.field_5812;
            }
            if (entity instanceof CargoCarEntity cargo && player.method_5715() && !player.method_5998(hand).method_31574(ModItems.LINE_SETTER)) {
                if (level instanceof class_3218 serverLevel) {
                    RailwaySavedData data = RailwayDataManager.state(serverLevel);
                    List<CargoSettingsNetworking.Station> stations = StationSelectionService.availableStations(data,cargo.trainLink()).stream()
                            .map(device -> new CargoSettingsNetworking.Station(device.id(), device.name(), estimateEta(cargo, device))).toList();
                    LegacyServerPlayNetworking.send((class_3222) player, new CargoSettingsNetworking.OpenPayload(
                            cargo.method_5628(), cargo.destinationStationId(), stations));
                }
                return class_1269.field_5812;
            }
            if (!(entity instanceof LocomotiveEntity locomotive)) {
                return class_1269.field_5811;
            }
            if (player.method_5715()&&level instanceof class_3218 serverLevel && player instanceof class_3222 serverPlayer) {
                boolean hasCargo = false;
                for (var candidate : serverLevel.method_27909()) {
                    if (candidate instanceof CargoCarEntity cargo
                            && cargo.trainLink().trainId().equals(locomotive.trainLink().trainId())) {
                        hasCargo = true;
                        break;
                    }
                }
                RailwaySavedData speedData = RailwayDataManager.state(serverLevel);
                List<TrainClassNetworking.Station> stationOptions=StationSelectionService.availableStations(speedData,locomotive.trainLink()).stream().map(d->new TrainClassNetworking.Station(d.id(),d.name())).toList();
                LegacyServerPlayNetworking.send(serverPlayer, new TrainClassNetworking.OpenPayload(
                        locomotive.method_5628(), locomotive.trainLink().trainClass().ordinal(), hasCargo,
                        speedData.classSpeedLimit(TrainClass.CARGO), speedData.classSpeedLimit(TrainClass.PASSENGER),
                        speedData.classSpeedLimit(TrainClass.EXPRESS),locomotive.trainLink().destinationStationId(),stationOptions));
            } else if (!level.method_8608()) {
                player.method_5804(locomotive);
            }
            return class_1269.field_5812;
        });
    }

    private static int estimateEta(CargoCarEntity cargo, RailwayDevice station) {
        double distance = Math.sqrt(cargo.method_5707(net.minecraft.class_243.method_24953(
                new net.minecraft.class_2338(station.x(), station.y(), station.z()))));
        double blocksPerSecond = Math.max(1.0D, cargo.method_18798().method_37267() * 20.0D);
        return (int) Math.min(Integer.MAX_VALUE, Math.ceil(distance / blocksPerSecond));
    }

    private static long nextStation(class_3218 level, CargoCarEntity cargo) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(cargo.trainLink().lineId());
        if (line == null) return 0L;
        List<Long> stations = line.nodeIds().stream()
                .filter(id -> data.device(id) != null && data.device(id).type() == DeviceType.STATION).distinct().toList();
        if (stations.isEmpty()) return 0L;
        int current = stations.indexOf(cargo.destinationStationId());
        return stations.get((current + 1) % stations.size());
    }
}


