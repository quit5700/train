package cn.quit5700.fabrictrain.data;


import cn.quit5700.fabrictrain.compat.NbtCompat;
import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Dynamic;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_4284;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.train.SpeedRules;
import cn.quit5700.fabrictrain.train.ControlMode;

public final class RailwaySavedData extends class_18 {
    public static final int CURRENT_SCHEMA_VERSION = 1;
    public static final Codec<RailwaySavedData> CODEC = Codec.PASSTHROUGH.xmap(
            RailwaySavedData::fromDynamic, RailwaySavedData::toDynamic);
    public static final String DATA_ID = FabricTrainMod.MOD_ID + "_railway_data";
    public static final class_18.class_8645<RailwaySavedData> TYPE = new class_18.class_8645<>(
            RailwaySavedData::new, tag -> fromDynamic(new Dynamic<>(class_2509.field_11560, tag)), class_4284.field_19212);

    private final Map<Long, RailwayDevice> devices = new LinkedHashMap<>();
    private final Map<Long, RailwayLine> lines = new LinkedHashMap<>();
    private final Map<UUID, Long> activeTrains = new LinkedHashMap<>();
    private final Map<UUID, TrainRecord> trainRegistry = new LinkedHashMap<>();
    private final Map<UUID, TrainManifest> trainManifests = new LinkedHashMap<>();
    private final java.util.Set<UUID> pendingTrainDeletions = new java.util.LinkedHashSet<>();
    private long nextDeviceId = 1L;
    private long nextLineId = 1L;
    private long nextStationNumber = 1L;
    private long nextSwitchNumber = 1L;
    private long nextDepotNumber = 1L;
    private long nextTrainNumber = 1L;
    private double freightSpeedLimitKmh = SpeedRules.FREIGHT_LIMIT_KMH;
    private double passengerSpeedLimitKmh = SpeedRules.PASSENGER_LIMIT_KMH;
    private double expressSpeedLimitKmh = SpeedRules.EXPRESS_LIMIT_KMH;

    public synchronized RailwayDevice find(String dimension, int x, int y, int z) {
        return devices.values().stream().filter(device ->
                device.dimension().equals(dimension) && device.x() == x && device.y() == y && device.z() == z)
                .findFirst().orElse(null);
    }

    public synchronized RailwayDevice register(DeviceType type, String dimension, int x, int y, int z) {
        RailwayDevice existing = find(dimension, x, y, z);
        if (existing != null) {
            return existing;
        }
        long id = nextDeviceId++;
        RailwayDevice device = new RailwayDevice(id, type, dimension, x, y, z,
                defaultName(type, nextDefaultNumber(type)), 30, 1);
        devices.put(id, device);
        method_80();
        return device;
    }

    public synchronized void remove(String dimension, int x, int y, int z) {
        if (devices.values().removeIf(device -> device.dimension().equals(dimension)
                && device.x() == x && device.y() == y && device.z() == z)) {
            method_80();
        }
    }

    public synchronized Map<Long, RailwayDevice> devices() {
        return Map.copyOf(devices);
    }

    public synchronized RailwayDevice device(long id) {
        return devices.get(id);
    }

    public synchronized RailwayDevice updateDevice(long id, String name, int dwellSeconds, int switchShapeOrdinal) {
        RailwayDevice device = devices.get(id);
        if (device == null) return null;
        String safeName = name == null || name.isBlank() ? device.name()
                : name.strip().substring(0, Math.min(64, name.strip().length()));
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), safeName, cn.quit5700.fabrictrain.compat.MathCompat.clamp(dwellSeconds, 0, 3600), device.cargoDwellSeconds(), Math.max(0, switchShapeOrdinal), device.switchEntryOrdinal(),
                device.announcement(), device.manualUnload());
        devices.put(id, updated);
        method_80();
        return updated;
    }

    public synchronized RailwayDevice updateDevice(long id, String name, int dwellSeconds, int switchShapeOrdinal, String announcement) {
        RailwayDevice updated=updateDevice(id,name,dwellSeconds,switchShapeOrdinal);
        if(updated==null)return null;
        String safe=announcement==null?"":announcement.strip().substring(0,Math.min(128,announcement.strip().length()));
        updated=new RailwayDevice(updated.id(),updated.type(),updated.dimension(),updated.x(),updated.y(),updated.z(),updated.name(),updated.dwellSeconds(),updated.cargoDwellSeconds(),updated.switchShapeOrdinal(),updated.switchEntryOrdinal(),safe,updated.manualUnload());
        devices.put(id,updated);method_80();return updated;
    }

    public synchronized RailwayDevice updateManualUnload(long id, boolean manualUnload) {
        RailwayDevice device = devices.get(id);
        if (device == null) return null;
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), device.name(), device.dwellSeconds(), device.cargoDwellSeconds(), device.switchShapeOrdinal(), device.switchEntryOrdinal(), device.announcement(), manualUnload);
        devices.put(id, updated); method_80(); return updated;
    }

    public synchronized RailwayDevice updateCargoDwell(long id, int cargoDwellSeconds) {
        RailwayDevice device = devices.get(id);
        if (device == null) return null;
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), device.name(), device.dwellSeconds(), cn.quit5700.fabrictrain.compat.MathCompat.clamp(cargoDwellSeconds, 0, 3600),
                device.switchShapeOrdinal(), device.switchEntryOrdinal(), device.announcement(), device.manualUnload());
        devices.put(id, updated); method_80(); return updated;
    }

    public synchronized RailwayDevice updateSwitchEntry(long id, int switchEntryOrdinal) {
        RailwayDevice device = devices.get(id);
        if (device == null || device.type() != DeviceType.SWITCH) return device;
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), device.name(), device.dwellSeconds(), device.cargoDwellSeconds(),
                device.switchShapeOrdinal(), switchEntryOrdinal, device.announcement(), device.manualUnload());
        devices.put(id, updated); method_80(); return updated;
    }

    public synchronized RailwayLine line(long id) {
        return lines.get(id);
    }

    public synchronized Map<Long, RailwayLine> lines() {
        return Map.copyOf(lines);
    }

    public synchronized void registerActiveTrain(UUID trainId, long lineId) {
        Long previous = activeTrains.put(trainId, lineId);
        if (previous == null || previous != lineId) method_80();
    }

    public synchronized void unregisterActiveTrain(UUID trainId) {
        if (activeTrains.remove(trainId) != null) method_80();
    }

    public synchronized long activeTrainCount(long lineId) {
        return activeTrains.values().stream().filter(value -> value == lineId).count();
    }

    public synchronized TrainRecord ensureTrain(UUID trainId, boolean depotGenerated, long lineId) {
        return ensureTrain(trainId, depotGenerated, lineId,
                depotGenerated && lineId > 0L ? ControlMode.ROUTE_AUTOMATIC : ControlMode.MANUAL);
    }

    public synchronized TrainRecord ensureTrain(UUID trainId, boolean depotGenerated, long lineId,
                                                ControlMode controlMode) {
        TrainRecord existing = trainRegistry.get(trainId);
        ControlMode safeMode = controlMode == null ? ControlMode.MANUAL : controlMode;
        if (existing == null) {
            existing = new TrainRecord(trainId, nextTrainNumber++, depotGenerated, Math.max(0L, lineId), safeMode,
                    pendingTrainDeletions.contains(trainId) ? TrainPresence.DESTROYED : TrainPresence.LOADED);
            trainRegistry.put(trainId, existing);
            method_80();
        } else if (pendingTrainDeletions.contains(trainId)) {
            if (existing.present()) {
                existing = new TrainRecord(existing.trainId(), existing.number(), existing.depotGenerated(),
                        existing.lineId(), existing.controlMode(), TrainPresence.DESTROYED);
                trainRegistry.put(trainId, existing);
                method_80();
            }
            return existing;
        } else if ((depotGenerated && !existing.depotGenerated()) || existing.lineId() != lineId
                || existing.controlMode() != safeMode || !existing.present()) {
            existing = new TrainRecord(trainId, existing.number(),
                    existing.depotGenerated() || depotGenerated, Math.max(0L, lineId), safeMode,
                    TrainPresence.LOADED);
            trainRegistry.put(trainId, existing);
            method_80();
        }
        return existing;
    }

    public synchronized TrainRecord trainRecord(UUID trainId) { return trainRegistry.get(trainId); }
    public synchronized Map<UUID, TrainRecord> trainRecords() { return Map.copyOf(trainRegistry); }
    public synchronized Map<UUID, TrainRecord> presentTrainRecords() {
        LinkedHashMap<UUID, TrainRecord> present = new LinkedHashMap<>();
        trainRegistry.forEach((id, record) -> {
            if (record.present() && hasRegisteredMembers(id)) present.put(id, record);
        });
        return Map.copyOf(present);
    }
    public synchronized Map<UUID, TrainRecord> presentAutomaticTrainRecords(long lineId) {
        if (lineId <= 0L) return Map.of();
        LinkedHashMap<UUID, TrainRecord> present = new LinkedHashMap<>();
        trainRegistry.forEach((id, record) -> {
            if (record.present() && hasRegisteredMembers(id) && record.lineId() == lineId
                    && record.controlMode() == ControlMode.ROUTE_AUTOMATIC) {
                present.put(id, record);
            }
        });
        return Map.copyOf(present);
    }
    public synchronized Map<UUID, TrainRecord> presentDepotTrainRecords(long lineId) {
        if (lineId <= 0L) return Map.of();
        LinkedHashMap<UUID, TrainRecord> present = new LinkedHashMap<>();
        trainRegistry.forEach((id, record) -> {
            if (!record.present() || !hasRegisteredMembers(id)) return;
            if (record.controlMode() == ControlMode.MANUAL
                    || record.controlMode() == ControlMode.ROUTE_AUTOMATIC && record.lineId() == lineId)
                present.put(id, record);
        });
        return Map.copyOf(present);
    }
    public synchronized TrainManifest trainManifest(UUID trainId) { return trainManifests.get(trainId); }
    public synchronized void replaceTrainManifest(UUID trainId, long originDepotNumber,
                                                  java.util.List<TrainMember> members) {
        if (trainId == null || pendingTrainDeletions.contains(trainId)) return;
        TrainManifest previous = trainManifests.get(trainId);
        long origin = originDepotNumber > 0L ? originDepotNumber
                : previous == null ? 0L : previous.originDepotNumber();
        TrainManifest manifest = new TrainManifest(origin, members);
        if (manifest.totalVehicles() == 0) trainManifests.remove(trainId);
        else trainManifests.put(trainId, manifest);
        method_80();
    }
    public synchronized void registerTrainMember(UUID trainId, long originDepotNumber, TrainMember member) {
        if (trainId == null || member == null || pendingTrainDeletions.contains(trainId)) return;
        TrainManifest current = trainManifests.get(trainId);
        java.util.ArrayList<TrainMember> members = new java.util.ArrayList<>(
                current == null ? java.util.List.of() : current.members());
        members.removeIf(value -> value.entityId().equals(member.entityId()));
        members.add(member);
        replaceTrainManifest(trainId, originDepotNumber, members);
    }
    public synchronized MemberRemovalResult unregisterTrainMember(UUID trainId, UUID entityId) {
        TrainManifest current = trainManifests.get(trainId);
        if (current == null || entityId == null || !current.contains(entityId)) return MemberRemovalResult.UNKNOWN_MEMBER;
        TrainManifest remaining = current.without(entityId);
        if (remaining.totalVehicles() > 0) {
            trainManifests.put(trainId, remaining);
            method_80();
            return MemberRemovalResult.MEMBERS_REMAIN;
        }
        trainManifests.remove(trainId);
        retireTrain(trainId);
        return MemberRemovalResult.TRAIN_EMPTY;
    }
    public synchronized boolean hasRegisteredMembers(UUID trainId) {
        TrainManifest manifest = trainManifests.get(trainId);
        return manifest != null && manifest.totalVehicles() > 0;
    }
    public enum MemberRemovalResult { UNKNOWN_MEMBER, MEMBERS_REMAIN, TRAIN_EMPTY }
    public synchronized void updateTrainPresence(UUID trainId, TrainPresence presence) {
        TrainRecord existing = trainRegistry.get(trainId);
        if (existing == null || presence == null || existing.presence() == presence) return;
        if (pendingTrainDeletions.contains(trainId) && presence != TrainPresence.DESTROYED) return;
        trainRegistry.put(trainId, new TrainRecord(existing.trainId(), existing.number(),
                existing.depotGenerated(), existing.lineId(), existing.controlMode(), presence));
        method_80();
    }
    public synchronized void retireTrain(UUID trainId) {
        boolean changed = activeTrains.remove(trainId) != null;
        changed |= trainManifests.remove(trainId) != null;
        TrainRecord existing = trainRegistry.get(trainId);
        if (existing != null && existing.present()) {
            trainRegistry.put(trainId, new TrainRecord(existing.trainId(), existing.number(),
                    existing.depotGenerated(), existing.lineId(), existing.controlMode(), TrainPresence.DESTROYED));
            changed = true;
        }
        if (changed) method_80();
    }
    public synchronized void markTrainForDeletion(UUID trainId) {
        if (trainId == null) return;
        retireTrain(trainId);
        if (pendingTrainDeletions.add(trainId)) method_80();
    }
    public synchronized boolean isTrainPendingDeletion(UUID trainId) {
        return trainId != null && pendingTrainDeletions.contains(trainId);
    }
    public synchronized void removeTrainRecord(UUID trainId) {
        retireTrain(trainId);
    }

    public synchronized void clearActiveTrainsForRestart() {
        if (!activeTrains.isEmpty()) { activeTrains.clear(); method_80(); }
    }

    public synchronized void prepareTrainRegistryForRestart() {
        boolean changed = !activeTrains.isEmpty();
        activeTrains.clear();
        for (Map.Entry<UUID, TrainRecord> entry : trainRegistry.entrySet()) {
            TrainRecord record = entry.getValue();
            if (record.presence() != TrainPresence.LOADED) continue;
            entry.setValue(new TrainRecord(record.trainId(), record.number(), record.depotGenerated(),
                    record.lineId(), record.controlMode(), TrainPresence.LEGACY_UNCONFIRMED));
            changed = true;
        }
        if (changed) method_80();
    }

    public synchronized double classSpeedLimit(TrainClass trainClass) {
        return switch (trainClass) {
            case CARGO -> freightSpeedLimitKmh;
            case PASSENGER -> passengerSpeedLimitKmh;
            case EXPRESS -> expressSpeedLimitKmh;
        };
    }

    public synchronized void updateClassSpeedLimits(double freight, double passenger, double express) {
        if (Double.isFinite(freight) && freight >= 0) freightSpeedLimitKmh = freight;
        if (Double.isFinite(passenger) && passenger >= 0) passengerSpeedLimitKmh = passenger;
        if (Double.isFinite(express) && express >= 0) expressSpeedLimitKmh = express;
        method_80();
    }

    public synchronized RailwayLine createLine(long depotId) {
        RailwayDevice depot = devices.get(depotId);
        if (depot == null || depot.type() != DeviceType.DEPOT) {
            throw new IllegalArgumentException("Line must start at an existing depot");
        }
        RailwayLine existing = lines.values().stream().filter(line -> line.depotId() == depotId).findFirst().orElse(null);
        if (existing != null) return existing;
        long id = nextLineId++;
        RailwayLine line = new RailwayLine(id, "line-" + id, depotId, java.util.List.of(),
                30, 80.0D, 1, LineStatus.NEEDS_VALIDATION);
        lines.put(id, line);
        method_80();
        return line;
    }

    public synchronized RailwayLine createEmptyLine(String requestedName) {
        String base = requestedName == null || requestedName.isBlank() ? "线路" + nextLineId : requestedName.strip();
        String safe = base.substring(0, Math.min(64, base.length()));
        if (lines.values().stream().anyMatch(line -> line.name().equalsIgnoreCase(safe))) {
            throw new IllegalArgumentException("Duplicate line name");
        }
        long id = nextLineId++;
        RailwayLine line = new RailwayLine(id, safe, 0L, java.util.List.of(), 30, 80.0D, 1,
                LineStatus.NEEDS_VALIDATION);
        lines.put(id, line);
        method_80();
        return line;
    }

    /**
     * Binds one depot as the dispatcher for one line. The depot stored in the route node list is a
     * separate recovery destination and is intentionally not changed here.
     *
     * @return the previous dispatcher displaced from the target line, or {@code 0}
     */
    public synchronized long bindDispatchDepot(long depotId, long lineId) {
        RailwayDevice depot = devices.get(depotId);
        if (depot == null || depot.type() != DeviceType.DEPOT) {
            throw new IllegalArgumentException("Dispatch depot must be an existing depot");
        }
        RailwayLine target = lineId == 0L ? null : lines.get(lineId);
        if (lineId != 0L && target == null) throw new IllegalArgumentException("Unknown line");
        if (target != null) {
            for (long nodeId : target.nodeIds()) {
                RailwayDevice node = devices.get(nodeId);
                if (node != null && !node.dimension().equals(depot.dimension())) {
                    throw new IllegalArgumentException("A dispatch depot and its line cannot cross dimensions");
                }
            }
        }

        long displacedDepotId = target == null || target.depotId() == depotId ? 0L : target.depotId();
        boolean changed = false;
        for (Map.Entry<Long, RailwayLine> entry : new java.util.ArrayList<>(lines.entrySet())) {
            RailwayLine line = entry.getValue();
            if (line.depotId() == depotId && line.id() != lineId) {
                lines.put(line.id(), withDispatchDepot(line, 0L));
                changed = true;
            }
        }
        if (target != null) {
            target = lines.get(lineId);
            if (target.depotId() != depotId) {
                lines.put(lineId, withDispatchDepot(target, depotId));
                changed = true;
            }
        }
        if (changed) method_80();
        return displacedDepotId;
    }

    public synchronized long dispatchLineIdForDepot(long depotId) {
        return lines.values().stream().filter(line -> line.depotId() == depotId)
                .mapToLong(RailwayLine::id).findFirst().orElse(0L);
    }

    public synchronized long recoveryDepotId(long lineId) {
        RailwayLine line = lines.get(lineId);
        if (line == null) return 0L;
        return line.nodeIds().stream().map(devices::get).filter(java.util.Objects::nonNull)
                .filter(device -> device.type() == DeviceType.DEPOT)
                .mapToLong(RailwayDevice::id).findFirst().orElse(0L);
    }

    private static RailwayLine withDispatchDepot(RailwayLine line, long depotId) {
        return new RailwayLine(line.id(), line.name(), depotId, line.nodeIds(), line.departureIntervalSeconds(),
                line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION, line.switchDirections(),
                line.stationStopTracks());
    }

    public synchronized RailwayLine insertLineNode(long lineId, int index, long deviceId) {
        RailwayLine line = lines.get(lineId);
        RailwayDevice device = devices.get(deviceId);
        if (line == null || device == null) throw new IllegalArgumentException("Unknown line or device");
        RailwayDevice dimensionAnchor = !line.nodeIds().isEmpty()
                ? devices.get(line.nodeIds().get(0)) : devices.get(line.depotId());
        if (dimensionAnchor != null && !dimensionAnchor.dimension().equals(device.dimension()))
            throw new IllegalArgumentException("A line cannot cross dimensions");
        if (device.type() == DeviceType.DEPOT && line.nodeIds().stream().map(devices::get)
                .filter(java.util.Objects::nonNull).anyMatch(existing -> existing.type() == DeviceType.DEPOT))
            throw new IllegalArgumentException("A line can contain only one recovery depot");
        java.util.ArrayList<Long> nodes = new java.util.ArrayList<>(line.nodeIds());
        int insertion = cn.quit5700.fabrictrain.compat.MathCompat.clamp(index, 0, nodes.size());
        nodes.add(insertion, deviceId);
        java.util.HashMap<Integer,Integer> directions = shiftDirections(line.switchDirections(), insertion, 1);
        java.util.HashMap<Integer,StopTrack> stopTracks = shiftIndexed(line.stationStopTracks(), insertion, 1);
        if (device.type() == DeviceType.SWITCH) directions.put(insertion, 1);
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), nodes, line.departureIntervalSeconds(),
                line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION, directions, stopTracks);
        lines.put(lineId, updated); method_80(); return updated;
    }

    public synchronized RailwayLine setSwitchDirection(long lineId, int nodeIndex, int direction) {
        RailwayLine line = lines.get(lineId);
        if (line == null || nodeIndex < 0 || nodeIndex >= line.nodeIds().size()) return line;
        RailwayDevice device = devices.get(line.nodeIds().get(nodeIndex));
        if (device == null || device.type() != DeviceType.SWITCH) return line;
        java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>(line.switchDirections());
        directions.put(nodeIndex, cn.quit5700.fabrictrain.compat.MathCompat.clamp(direction, 0, 2));
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), line.nodeIds(),
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION,
                directions, line.stationStopTracks());
        lines.put(lineId, updated); method_80(); return updated;
    }

    private static java.util.HashMap<Integer,Integer> shiftDirections(java.util.Map<Integer,Integer> source, int from, int amount) {
        java.util.HashMap<Integer,Integer> result = new java.util.HashMap<>();
        source.forEach((index, direction) -> result.put(index >= from ? index + amount : index, direction));
        return result;
    }

    private static <T> java.util.HashMap<Integer,T> shiftIndexed(java.util.Map<Integer,T> source, int from, int amount) {
        java.util.HashMap<Integer,T> result = new java.util.HashMap<>();
        source.forEach((index, value) -> result.put(index >= from ? index + amount : index, value));
        return result;
    }

    public synchronized RailwayLine setStationStopTrack(long lineId, int nodeIndex, StopTrack stopTrack) {
        RailwayLine line = lines.get(lineId);
        if (line == null || nodeIndex < 0 || nodeIndex >= line.nodeIds().size() || stopTrack == null) return line;
        RailwayDevice device = devices.get(line.nodeIds().get(nodeIndex));
        if (device == null || device.type() != DeviceType.STATION) return line;
        java.util.HashMap<Integer,StopTrack> tracks = new java.util.HashMap<>(line.stationStopTracks());
        tracks.put(nodeIndex, stopTrack);
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), line.nodeIds(),
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(),
                LineStatus.NEEDS_VALIDATION, line.switchDirections(), tracks);
        lines.put(lineId, updated);
        method_80();
        return updated;
    }

    public synchronized RailwayLine appendLineNode(long lineId, long deviceId) {
        RailwayLine line = lines.get(lineId);
        if (line == null) throw new IllegalArgumentException("Unknown line or device");
        return insertLineNode(lineId, line.nodeIds().size(), deviceId);
    }

    public synchronized RailwayLine modifyLineNode(long lineId, int index, int action) {
        RailwayLine line = lines.get(lineId);
        if (line == null || index < 0 || index >= line.nodeIds().size()) return line;
        java.util.ArrayList<Long> nodes = new java.util.ArrayList<>(line.nodeIds());
        if (action == 0 && index > 0) java.util.Collections.swap(nodes, index, index - 1);
        else if (action == 1 && index < nodes.size() - 1) java.util.Collections.swap(nodes, index, index + 1);
        else if (action == 2) nodes.remove(index);
        else return line;
        java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>();
        java.util.HashMap<Integer,StopTrack> stopTracks = new java.util.HashMap<>();
        line.switchDirections().forEach((oldIndex, direction) -> {
            int newIndex = oldIndex;
            if (action == 0 && index > 0) { if (oldIndex == index) newIndex = index - 1; else if (oldIndex == index - 1) newIndex = index; }
            else if (action == 1 && index < line.nodeIds().size() - 1) { if (oldIndex == index) newIndex = index + 1; else if (oldIndex == index + 1) newIndex = index; }
            else if (action == 2) { if (oldIndex == index) return; if (oldIndex > index) newIndex = oldIndex - 1; }
            directions.put(newIndex, direction);
        });
        line.stationStopTracks().forEach((oldIndex, stopTrack) -> {
            int newIndex = oldIndex;
            if (action == 0 && index > 0) { if (oldIndex == index) newIndex = index - 1; else if (oldIndex == index - 1) newIndex = index; }
            else if (action == 1 && index < line.nodeIds().size() - 1) { if (oldIndex == index) newIndex = index + 1; else if (oldIndex == index + 1) newIndex = index; }
            else if (action == 2) { if (oldIndex == index) return; if (oldIndex > index) newIndex = oldIndex - 1; }
            stopTracks.put(newIndex, stopTrack);
        });
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), nodes,
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION,
                directions, stopTracks);
        lines.put(lineId, updated);
        method_80();
        return updated;
    }

    public synchronized boolean deleteLine(long lineId) {
        boolean removed = lines.remove(lineId) != null;
        if (removed) method_80();
        return removed;
    }

    public synchronized RailwayLine setLineStatus(long lineId, LineStatus status) {
        RailwayLine line = lines.get(lineId);
        if (line == null) return null;
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), line.nodeIds(),
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), status,
                line.switchDirections(), line.stationStopTracks());
        lines.put(lineId, updated);
        method_80();
        return updated;
    }

    public synchronized RailwayLine updateLineSettings(long lineId, String name, int intervalSeconds, double speedKmh,
                                                        int maximumTrains, LineStatus status) {
        RailwayLine line = lines.get(lineId);
        if (line == null) return null;
        int interval = cn.quit5700.fabrictrain.compat.MathCompat.clamp(intervalSeconds, 0, 3600);
        double speed = Double.isFinite(speedKmh) ? Math.max(0.0D, speedKmh) : line.speedLimitKmh();
        int maximum = cn.quit5700.fabrictrain.compat.MathCompat.clamp(maximumTrains, 1, 1000);
        String safeName = name == null || name.isBlank() ? "line-" + line.id()
                : name.strip().substring(0, Math.min(64, name.strip().length()));
        RailwayLine updated = new RailwayLine(line.id(), safeName, line.depotId(), line.nodeIds(),
                interval, speed, maximum, status, line.switchDirections(), line.stationStopTracks());
        lines.put(lineId, updated);
        method_80();
        return updated;
    }

    private static String defaultName(DeviceType type, long id) {
        return switch (type) {
            case STATION -> "站点" + id;
            case DEPOT -> "车辆段" + id;
            case SWITCH -> "道岔" + id;
        };
    }

    private long nextDefaultNumber(DeviceType type) {
        return switch (type) {
            case STATION -> nextStationNumber++;
            case SWITCH -> nextSwitchNumber++;
            case DEPOT -> nextDepotNumber++;
        };
    }

    private static RailwaySavedData fromDynamic(Dynamic<?> dynamic) {
        class_2487 tag = (class_2487) dynamic.convert(class_2509.field_11560).getValue();
        RailwaySavedData data = new RailwaySavedData();
        int schemaVersion = NbtCompat.getInt(tag, "SchemaVersion", 0);
        int trainPresenceFormat = NbtCompat.getInt(tag, "TrainPresenceFormat", 0);
        data.nextDeviceId = Math.max(1L, NbtCompat.getLong(tag, "NextDeviceId", 1L));
        data.nextLineId = Math.max(1L, NbtCompat.getLong(tag, "NextLineId", 1L));
        data.nextStationNumber = Math.max(1L, NbtCompat.getLong(tag, "NextStationNumber", 1L));
        data.nextSwitchNumber = Math.max(1L, NbtCompat.getLong(tag, "NextSwitchNumber", 1L));
        data.nextDepotNumber = Math.max(1L, NbtCompat.getLong(tag, "NextDepotNumber", 1L));
        data.freightSpeedLimitKmh = validSpeed(NbtCompat.getDouble(tag, "FreightSpeedLimitKmh", SpeedRules.FREIGHT_LIMIT_KMH), SpeedRules.FREIGHT_LIMIT_KMH);
        data.passengerSpeedLimitKmh = validSpeed(NbtCompat.getDouble(tag, "PassengerSpeedLimitKmh", SpeedRules.PASSENGER_LIMIT_KMH), SpeedRules.PASSENGER_LIMIT_KMH);
        data.expressSpeedLimitKmh = validSpeed(NbtCompat.getDouble(tag, "ExpressSpeedLimitKmh", SpeedRules.EXPRESS_LIMIT_KMH), SpeedRules.EXPRESS_LIMIT_KMH);
        class_2499 list = NbtCompat.getList(tag, "Devices");
        for (int i = 0; i < list.size(); i++) {
            class_2487 entry = NbtCompat.getCompound(list, i);
            long id = NbtCompat.getLong(entry, "Id", 0L);
            try {
                DeviceType type = DeviceType.valueOf(NbtCompat.getString(entry, "Type", "STATION"));
                RailwayDevice device = new RailwayDevice(id, type,
                        NbtCompat.getString(entry, "Dimension", "minecraft:overworld"),
                        NbtCompat.getInt(entry, "X", 0), NbtCompat.getInt(entry, "Y", 0), NbtCompat.getInt(entry, "Z", 0),
                        migrateDefaultName(type, id, NbtCompat.getString(entry, "Name", defaultName(type, id))),
                        cn.quit5700.fabrictrain.compat.MathCompat.clamp(NbtCompat.getInt(entry, "DwellSeconds", 30), 0, 3600),
                        cn.quit5700.fabrictrain.compat.MathCompat.clamp(NbtCompat.getInt(entry, "CargoDwellSeconds", 120), 0, 3600),
                        Math.max(0, NbtCompat.getInt(entry, "SwitchShapeOrdinal", 0)), NbtCompat.getInt(entry, "SwitchEntryOrdinal", -1), NbtCompat.getString(entry, "Announcement", ""),
                        NbtCompat.getBoolean(entry, "ManualUnload", false));
                if (id > 0) data.devices.put(id, device);
            } catch (IllegalArgumentException ignored) {
                // Unknown future device types are skipped instead of corrupting the world load.
            }
        }
        if (!tag.method_10545("NextStationNumber")) data.nextStationNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.STATION).count();
        if (!tag.method_10545("NextSwitchNumber")) data.nextSwitchNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.SWITCH).count();
        if (!tag.method_10545("NextDepotNumber")) data.nextDepotNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.DEPOT).count();
        class_2499 lineList = NbtCompat.getList(tag, "Lines");
        for (int i = 0; i < lineList.size(); i++) {
            class_2487 entry = NbtCompat.getCompound(lineList, i);
            java.util.ArrayList<Long> nodes = new java.util.ArrayList<>();
            class_2499 nodeList = NbtCompat.getList(entry, "Nodes");
            for (int j = 0; j < nodeList.size(); j++) {
                nodes.add(NbtCompat.getLong(NbtCompat.getCompound(nodeList, j), "Id", 0L));
            }
            java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>();
            class_2499 directionList = NbtCompat.getList(entry, "SwitchDirections");
            for (int j = 0; j < directionList.size(); j++) {
                class_2487 direction = NbtCompat.getCompound(directionList, j);
                directions.put(NbtCompat.getInt(direction, "Index", -1), NbtCompat.getInt(direction, "Direction", -1));
            }
            java.util.HashMap<Integer,StopTrack> stopTracks = new java.util.HashMap<>();
            class_2499 stopTrackList = NbtCompat.getList(entry, "StationStopTracks");
            for (int j = 0; j < stopTrackList.size(); j++) {
                class_2487 stop = NbtCompat.getCompound(stopTrackList, j);
                int index = NbtCompat.getInt(stop, "Index", -1);
                if (index >= 0) stopTracks.put(index, new StopTrack(NbtCompat.getInt(stop, "X", 0),
                        NbtCompat.getInt(stop, "Y", 0), NbtCompat.getInt(stop, "Z", 0)));
            }
            try {
                RailwayLine line = new RailwayLine(
                        NbtCompat.getLong(entry, "Id", 0L), NbtCompat.getString(entry, "Name", "line"),
                        NbtCompat.getLong(entry, "DepotId", 0L), nodes,
                        NbtCompat.getInt(entry, "DepartureIntervalSeconds", 30),
                        NbtCompat.getDouble(entry, "SpeedLimitKmh", 80.0D),
                        NbtCompat.getInt(entry, "MaximumTrains", 1),
                        LineStatus.valueOf(NbtCompat.getString(entry, "Status", "NEEDS_VALIDATION")), directions, stopTracks);
                data.lines.put(line.id(), line);
            } catch (IllegalArgumentException ignored) {
                // Invalid lines are skipped so one bad record cannot prevent world loading.
            }
        }
        class_2499 trainList = NbtCompat.getList(tag, "ActiveTrains");
        for (int i = 0; i < trainList.size(); i++) {
            class_2487 entry = NbtCompat.getCompound(trainList, i);
            try {
                UUID trainId = UUID.fromString(NbtCompat.getString(entry, "TrainId", ""));
                long lineId = NbtCompat.getLong(entry, "LineId", 0L);
                if (lineId > 0) data.activeTrains.put(trainId, lineId);
            } catch (IllegalArgumentException ignored) { }
        }
        data.nextTrainNumber = Math.max(1L, NbtCompat.getLong(tag, "NextTrainNumber", 1L));
        java.util.HashSet<Long> usedTrainNumbers = new java.util.HashSet<>();
        class_2499 registryList = NbtCompat.getList(tag, "TrainRegistry");
        for (int i = 0; i < registryList.size(); i++) {
            class_2487 entry = NbtCompat.getCompound(registryList, i);
            try {
                UUID trainId = UUID.fromString(NbtCompat.getString(entry, "TrainId", ""));
                long number = Math.max(1L, NbtCompat.getLong(entry, "Number", 1L));
                if (!usedTrainNumbers.add(number)) {
                    while (usedTrainNumbers.contains(data.nextTrainNumber)) data.nextTrainNumber++;
                    number = data.nextTrainNumber++;
                    usedTrainNumbers.add(number);
                }
                boolean depotGenerated=NbtCompat.getBoolean(entry, "DepotGenerated", false);
                long lineId=NbtCompat.getLong(entry, "LineId", 0L);
                ControlMode controlMode;
                try { controlMode=ControlMode.valueOf(NbtCompat.getString(entry, "ControlMode",
                        depotGenerated&&lineId>0?ControlMode.ROUTE_AUTOMATIC.name():ControlMode.MANUAL.name())); }
                catch(IllegalArgumentException ignored){controlMode=depotGenerated&&lineId>0?ControlMode.ROUTE_AUTOMATIC:ControlMode.MANUAL;}
                data.trainRegistry.put(trainId, new TrainRecord(trainId, number,
                        depotGenerated, lineId, controlMode,
                        TrainRecordPresence.readLifecycle(entry, trainPresenceFormat)));
                long originDepotNumber = Math.max(0L, NbtCompat.getLong(entry, "OriginDepotNumber", 0L));
                class_2499 memberList = NbtCompat.getList(entry, "Members");
                java.util.ArrayList<TrainMember> members = new java.util.ArrayList<>();
                for (int memberIndex = 0; memberIndex < memberList.size(); memberIndex++) {
                    class_2487 member = NbtCompat.getCompound(memberList, memberIndex);
                    try {
                        members.add(new TrainMember(
                                UUID.fromString(NbtCompat.getString(member, "EntityId", "")),
                                TrainVehicleKind.valueOf(NbtCompat.getString(member, "Kind", "PASSENGER")),
                                Math.max(1, NbtCompat.getInt(member, "Sequence", memberIndex + 1))));
                    } catch (IllegalArgumentException ignored) { }
                }
                if (!members.isEmpty()) data.trainManifests.put(trainId,
                        new TrainManifest(originDepotNumber, members));
                data.nextTrainNumber = Math.max(data.nextTrainNumber, number + 1L);
            } catch (IllegalArgumentException ignored) { }
        }
        class_2499 deletionList = NbtCompat.getList(tag, "PendingTrainDeletions");
        for (int i = 0; i < deletionList.size(); i++) {
            try {
                data.pendingTrainDeletions.add(UUID.fromString(
                        NbtCompat.getString(NbtCompat.getCompound(deletionList, i), "TrainId", "")));
            } catch (IllegalArgumentException ignored) { }
        }
        for (long id : data.devices.keySet()) data.nextDeviceId = Math.max(data.nextDeviceId, id + 1L);
        for (long id : data.lines.keySet()) data.nextLineId = Math.max(data.nextLineId, id + 1L);
        if (schemaVersion < CURRENT_SCHEMA_VERSION) data.method_80();
        return data;
    }

    private Dynamic<?> toDynamic() {
        class_2487 tag = new class_2487();
        tag.method_10569("SchemaVersion", CURRENT_SCHEMA_VERSION);
        tag.method_10544("NextDeviceId", nextDeviceId);
        tag.method_10544("NextLineId", nextLineId);
        tag.method_10544("NextStationNumber", nextStationNumber);
        tag.method_10544("NextSwitchNumber", nextSwitchNumber);
        tag.method_10544("NextDepotNumber", nextDepotNumber);
        tag.method_10544("NextTrainNumber", nextTrainNumber);
        tag.method_10569("TrainPresenceFormat", TrainRecordPresence.CURRENT_FORMAT);
        tag.method_10549("FreightSpeedLimitKmh", freightSpeedLimitKmh);
        tag.method_10549("PassengerSpeedLimitKmh", passengerSpeedLimitKmh);
        tag.method_10549("ExpressSpeedLimitKmh", expressSpeedLimitKmh);
        class_2499 list = new class_2499();
        devices.values().forEach(device -> {
            class_2487 entry = new class_2487();
            entry.method_10544("Id", device.id());
            entry.method_10582("Type", device.type().name());
            entry.method_10582("Dimension", device.dimension());
            entry.method_10569("X", device.x());
            entry.method_10569("Y", device.y());
            entry.method_10569("Z", device.z());
            entry.method_10582("Name", device.name());
            entry.method_10569("DwellSeconds", device.dwellSeconds());
            entry.method_10569("CargoDwellSeconds", device.cargoDwellSeconds());
            entry.method_10569("SwitchShapeOrdinal", device.switchShapeOrdinal());
            entry.method_10569("SwitchEntryOrdinal", device.switchEntryOrdinal());
            entry.method_10582("Announcement", device.announcement());
            entry.method_10556("ManualUnload", device.manualUnload());
            list.add(entry);
        });
        tag.method_10566("Devices", list);
        class_2499 lineList = new class_2499();
        lines.values().forEach(line -> {
            class_2487 entry = new class_2487();
            entry.method_10544("Id", line.id());
            entry.method_10582("Name", line.name());
            entry.method_10544("DepotId", line.depotId());
            entry.method_10569("DepartureIntervalSeconds", line.departureIntervalSeconds());
            entry.method_10549("SpeedLimitKmh", line.speedLimitKmh());
            entry.method_10569("MaximumTrains", line.maximumTrains());
            entry.method_10582("Status", line.status().name());
            class_2499 nodes = new class_2499();
            line.nodeIds().forEach(nodeId -> {
                class_2487 node = new class_2487();
                node.method_10544("Id", nodeId);
                nodes.add(node);
            });
            entry.method_10566("Nodes", nodes);
            class_2499 directions = new class_2499();
            line.switchDirections().forEach((index, direction) -> {
                class_2487 value = new class_2487();
                value.method_10569("Index", index); value.method_10569("Direction", direction); directions.add(value);
            });
            entry.method_10566("SwitchDirections", directions);
            class_2499 stopTracks = new class_2499();
            line.stationStopTracks().forEach((index, stopTrack) -> {
                class_2487 value = new class_2487();
                value.method_10569("Index", index);
                value.method_10569("X", stopTrack.x());
                value.method_10569("Y", stopTrack.y());
                value.method_10569("Z", stopTrack.z());
                stopTracks.add(value);
            });
            entry.method_10566("StationStopTracks", stopTracks);
            lineList.add(entry);
        });
        tag.method_10566("Lines", lineList);
        class_2499 trainList = new class_2499();
        activeTrains.forEach((trainId, lineId) -> {
            class_2487 entry = new class_2487();
            entry.method_10582("TrainId", trainId.toString());
            entry.method_10544("LineId", lineId);
            trainList.add(entry);
        });
        tag.method_10566("ActiveTrains", trainList);
        class_2499 registryList = new class_2499();
        trainRegistry.values().forEach(record -> {
            class_2487 entry = new class_2487();
            entry.method_10582("TrainId", record.trainId().toString());
            entry.method_10544("Number", record.number());
            entry.method_10556("DepotGenerated", record.depotGenerated());
            entry.method_10544("LineId", record.lineId());
            entry.method_10582("ControlMode", record.controlMode().name());
            entry.method_10556("Present", record.present());
            entry.method_10582("Presence", record.presence().name());
            TrainManifest manifest = trainManifests.get(record.trainId());
            if (manifest != null) {
                entry.method_10544("OriginDepotNumber", manifest.originDepotNumber());
                class_2499 members = new class_2499();
                manifest.members().forEach(member -> {
                    class_2487 memberTag = new class_2487();
                    memberTag.method_10582("EntityId", member.entityId().toString());
                    memberTag.method_10582("Kind", member.kind().name());
                    memberTag.method_10569("Sequence", member.sequence());
                    members.add(memberTag);
                });
                entry.method_10566("Members", members);
            }
            registryList.add(entry);
        });
        tag.method_10566("TrainRegistry", registryList);
        class_2499 deletionList = new class_2499();
        pendingTrainDeletions.forEach(trainId -> {
            class_2487 entry = new class_2487();
            entry.method_10582("TrainId", trainId.toString());
            deletionList.add(entry);
        });
        tag.method_10566("PendingTrainDeletions", deletionList);
        return new Dynamic<>(class_2509.field_11560, tag);
    }

    private static String migrateDefaultName(DeviceType type, long id, String name) {
        if (name.equals("station-" + id) || name.equals("switch-" + id) || name.equals("depot-" + id)) {
            return defaultName(type, id);
        }
        return name;
    }

    private static double validSpeed(double value, double fallback) { return Double.isFinite(value) && value >= 0 ? value : fallback; }

    @Override public class_2487 method_75(class_2487 tag) {
        return (class_2487) toDynamic().getValue();
    }
}

