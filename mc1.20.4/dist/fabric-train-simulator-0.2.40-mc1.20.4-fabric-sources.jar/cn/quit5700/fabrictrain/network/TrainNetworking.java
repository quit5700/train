package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;

public final class TrainNetworking {
    private static final class_2960 DRIVE = FabricTrainMod.id("drive");

    private TrainNetworking() {
    }

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playC2S().register(DrivePayload.ID, DrivePayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(DrivePayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    if (context.player().method_5854() instanceof PassengerCarEntity
                            || context.player().method_5854() instanceof LocomotiveEntity) {
                        TrainControllerManager.drive(context.player(), context.player().method_5854(), payload.forward(), payload.brake());
                    }
                }));
    }

    public record DrivePayload(boolean forward, boolean brake) implements LegacyPayload {
        public static final Type<DrivePayload> ID = new Type<>(DRIVE);
        public static final LegacyPayloadCodec<class_2540, DrivePayload> CODEC = LegacyPayload.codec(
                DrivePayload::write, DrivePayload::read);

        private void write(class_2540 buffer) {
            buffer.method_52964(forward);
            buffer.method_52964(brake);
        }

        private static DrivePayload read(class_2540 buffer) {
            return new DrivePayload(buffer.readBoolean(), buffer.readBoolean());
        }

        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}


