package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;
import net.minecraft.class_1263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import cn.quit5700.fabrictrain.route.SwitchEntryDirectionRules;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import cn.quit5700.fabrictrain.registry.ModBlocks;

public final class DeviceSettingsNetworking {
    private DeviceSettingsNetworking() {}

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(RequestOpenPayload.ID, RequestOpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(RequestOpenPayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    var player = context.player();
                    class_2338 pos = payload.pos();
                    if (player.method_5649(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D) > 64.0D)
                        return;
                    var state = player.method_51469().method_8320(pos);
                    DeviceType type = state.method_27852(ModBlocks.STATION_MARKER) ? DeviceType.STATION
                            : state.method_27852(ModBlocks.SWITCH_RAIL) ? DeviceType.SWITCH : null;
                    if (type == null) return;
                    class_3218 serverLevel = player.method_51469();
                    open(player, RailwayDataManager.register(serverLevel, pos, type));
                }));
        LegacyServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            RailwaySavedData data = RailwayDataManager.state(context.player().method_51469());
            RailwayDevice before = data.device(payload.deviceId());
            if (before == null) return;
            int shape = cn.quit5700.fabrictrain.compat.MathCompat.clamp(payload.switchShapeOrdinal(), 0, 2);
            RailwayDevice updated = data.updateDevice(payload.deviceId(), payload.name(), payload.dwellSeconds(), shape, payload.announcement());
            data.updateCargoDwell(payload.deviceId(), payload.cargoDwellSeconds());
            if (updated != null && before.type() == DeviceType.SWITCH) {
                for (class_3218 level : context.player().method_51469().method_8503().method_3738()) {
                    if (RailwayDataManager.dimension(level).equals(before.dimension())) {
                        class_2338 pos=new class_2338(before.x(),before.y(),before.z());
                        var state=level.method_8320(pos);
                        class_2350 fallback=state.method_28498(DeviceRailBlock.PLACEMENT_ENTRY)
                                ?state.method_11654(DeviceRailBlock.PLACEMENT_ENTRY):class_2350.field_11043;
                        class_2350 entry=SwitchEntryDirectionRules.resolve(payload.switchEntryOrdinal(),fallback);
                        updated=data.updateSwitchEntry(payload.deviceId(),entry.ordinal());
                        SwitchRailRouting.applySettings(level, updated, shape, entry);
                        break;
                    }
                }
            }
        }));
    }

    public static void open(net.minecraft.class_3222 player, RailwayDevice device) {
        boolean connected = false;
        int switchEntryOrdinal=device.switchEntryOrdinal();
        for (class_3218 level : player.method_51469().method_8503().method_3738()) {
            if (!RailwayDataManager.dimension(level).equals(device.dimension())) continue;
            class_2338 pos = new class_2338(device.x(), device.y(), device.z());
            if(device.type()==DeviceType.SWITCH&&level.method_8320(pos).method_28498(DeviceRailBlock.PLACEMENT_ENTRY)){
                class_2350 entry=SwitchRailRouting.entryFor(device,level.method_8320(pos));
                switchEntryOrdinal=entry.ordinal();
                if(device.switchEntryOrdinal()!=switchEntryOrdinal)
                    RailwayDataManager.state(level).updateSwitchEntry(device.id(),switchEntryOrdinal);
            }
            for (class_2350 direction : class_2350.values()) {
                if (level.method_8321(pos.method_10093(direction)) instanceof class_1263) { connected = true; break; }
            }
        }
        LegacyServerPlayNetworking.send(player, new OpenPayload(device.id(), device.type().ordinal(), device.name(),
                device.dwellSeconds(), device.cargoDwellSeconds(), device.switchShapeOrdinal(), switchEntryOrdinal,
                device.announcement(), connected));
    }

    private static double squaredDistance(double x, double y, double z, RailwayDevice d) {
        double dx = x - d.x(), dy = y - d.y(), dz = z - d.z(); return dx * dx + dy * dy + dz * dz;
    }

    public record RequestOpenPayload(class_2338 pos) implements LegacyPayload {
        public static final Type<RequestOpenPayload> ID = new Type<>(FabricTrainMod.id("request_open_device_settings"));
        public static final LegacyPayloadCodec<class_2540, RequestOpenPayload> CODEC =
                LegacyPayload.codec((payload, buffer) -> buffer.method_10807(payload.pos),
                        buffer -> new RequestOpenPayload(buffer.method_10811()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record OpenPayload(long deviceId, int typeOrdinal, String name, int dwellSeconds, int cargoDwellSeconds, int switchShapeOrdinal, int switchEntryOrdinal,
                              String announcement, boolean containerConnected) implements LegacyPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_device_settings"));
        public static final LegacyPayloadCodec<class_2540, OpenPayload> CODEC = LegacyPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(class_2540 b) { b.method_10791(deviceId); b.method_10804(typeOrdinal); b.method_10788(name, 64); b.method_10804(dwellSeconds); b.method_10804(cargoDwellSeconds); b.method_10804(switchShapeOrdinal);b.method_10804(switchEntryOrdinal);b.method_10788(announcement,128);b.method_52964(containerConnected); }
        private static OpenPayload read(class_2540 b) { return new OpenPayload(b.method_10792(), b.method_10816(), b.method_10800(64), b.method_10816(), b.method_10816(), b.method_10816(),b.method_10816(),b.method_10800(128),b.readBoolean()); }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UpdatePayload(long deviceId, String name, int dwellSeconds, int cargoDwellSeconds,
                                int switchShapeOrdinal, int switchEntryOrdinal, String announcement) implements LegacyPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_device_settings"));
        public static final LegacyPayloadCodec<class_2540, UpdatePayload> CODEC = LegacyPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(class_2540 b) { b.method_10791(deviceId); b.method_10788(name, 64); b.method_10804(dwellSeconds); b.method_10804(cargoDwellSeconds); b.method_10804(switchShapeOrdinal);b.method_10804(switchEntryOrdinal);b.method_10788(announcement,128); }
        private static UpdatePayload read(class_2540 b) { return new UpdatePayload(b.method_10792(), b.method_10800(64), b.method_10816(), b.method_10816(), b.method_10816(),b.method_10816(),b.method_10800(128)); }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}



