package cn.quit5700.fabrictrain.network;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public final class LegacyPayloadTypeRegistry {
    private static final LegacyPayloadTypeRegistry INSTANCE = new LegacyPayloadTypeRegistry();
    private static final Map<class_2960, LegacyPayloadCodec<class_2540, ? extends LegacyPayload>> CODECS =
            new ConcurrentHashMap<>();

    private LegacyPayloadTypeRegistry() {}
    public static LegacyPayloadTypeRegistry playC2S() { return INSTANCE; }
    public static LegacyPayloadTypeRegistry playS2C() { return INSTANCE; }

    public <T extends LegacyPayload> void register(LegacyPayload.Type<T> type,
                                                    LegacyPayloadCodec<class_2540, T> codec) {
        CODECS.put(type.id(), codec);
    }

    @SuppressWarnings("unchecked")
    static <T extends LegacyPayload> LegacyPayloadCodec<class_2540, T> codec(LegacyPayload.Type<T> type) {
        return (LegacyPayloadCodec<class_2540, T>) CODECS.get(type.id());
    }
}


