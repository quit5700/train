package cn.quit5700.fabrictrain.network;

import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public interface LegacyPayload {
    Type<? extends LegacyPayload> type();

    record Type<T extends LegacyPayload>(class_2960 id) {}

    static <T extends LegacyPayload> LegacyPayloadCodec<class_2540, T> codec(
            BiConsumer<T, class_2540> writer, Function<class_2540, T> reader) {
        return new LegacyPayloadCodec<>(writer, reader);
    }
}
