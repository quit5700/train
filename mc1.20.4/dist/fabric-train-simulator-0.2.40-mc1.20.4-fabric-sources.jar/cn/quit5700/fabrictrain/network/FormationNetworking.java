package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainFormationService;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_3222;

public final class FormationNetworking {
    private FormationNetworking() {}

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_1297 seed = context.player().method_51469().method_8469(payload.seedEntityId());
                    if (!(seed instanceof LinkedTrainCar) || context.player().method_5858(seed) > 256.0D) return;
                    if (payload.dissolve()) TrainFormationService.dissolve(seed);
                    else TrainFormationService.reorder(seed, payload.entityIds());
                }));
    }

    public static void open(class_3222 player, class_1297 seed) {
        List<Car> cars = TrainFormationService.formation(seed).stream()
                .map(entity -> new Car(entity.method_5628(), entity.method_5864().method_5897().getString())).toList();
        LegacyServerPlayNetworking.send(player, new OpenPayload(seed.method_5628(), cars));
    }

    public record Car(int entityId, String name) {}

    public record OpenPayload(int seedEntityId, List<Car> cars) implements LegacyPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_formation"));
        public static final LegacyPayloadCodec<class_2540, OpenPayload> CODEC =
                LegacyPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(class_2540 b) {
            b.method_10804(seedEntityId); b.method_10804(cars.size());
            for (Car car : cars) { b.method_10804(car.entityId()); b.method_10788(car.name(), 128); }
        }
        private static OpenPayload read(class_2540 b) {
            int seed = b.method_10816(), size = cn.quit5700.fabrictrain.compat.MathCompat.clamp(b.method_10816(), 0, 101);
            ArrayList<Car> cars = new ArrayList<>(size);
            for (int i = 0; i < size; i++) cars.add(new Car(b.method_10816(), b.method_10800(128)));
            return new OpenPayload(seed, List.copyOf(cars));
        }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UpdatePayload(int seedEntityId, boolean dissolve, List<Integer> entityIds)
            implements LegacyPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_formation"));
        public static final LegacyPayloadCodec<class_2540, UpdatePayload> CODEC =
                LegacyPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(class_2540 b) {
            b.method_10804(seedEntityId); b.method_52964(dissolve); b.method_10804(entityIds.size());
            entityIds.forEach(b::method_10804);
        }
        private static UpdatePayload read(class_2540 b) {
            int seed = b.method_10816(); boolean dissolve = b.readBoolean();
            int size = cn.quit5700.fabrictrain.compat.MathCompat.clamp(b.method_10816(), 0, 101); ArrayList<Integer> ids = new ArrayList<>(size);
            for (int i = 0; i < size; i++) ids.add(b.method_10816());
            return new UpdatePayload(seed, dissolve, List.copyOf(ids));
        }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}



