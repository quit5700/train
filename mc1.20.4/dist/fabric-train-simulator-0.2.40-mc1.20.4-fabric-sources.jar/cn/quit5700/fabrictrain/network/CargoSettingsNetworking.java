package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;
import cn.quit5700.fabrictrain.cargo.StationPresenceService;
import cn.quit5700.fabrictrain.cargo.CargoTransferService;

public final class CargoSettingsNetworking {
    private CargoSettingsNetworking() {}

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UnloadAllPayload.ID, UnloadAllPayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof CargoCarEntity cargo) || context.player().method_5858(entity) > 64.0D) return;
            var data=RailwayDataManager.state(context.player().method_51469());
            if(StationSelectionService.canSelect(data,cargo.trainLink(),payload.stationId()))
                cargo.setDestinationStationId(payload.stationId());
        }));
        LegacyServerPlayNetworking.registerGlobalReceiver(UnloadAllPayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof CargoCarEntity cargo) || context.player().method_5858(entity) > 64.0D) return;
            var level = (net.minecraft.class_3218) context.player().method_51469();
            var data = RailwayDataManager.state(level);
            RailwayDevice station = StationPresenceService.findStationAt(level, data, cargo);
            if (station == null) {
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.cargo.not_at_station"));
                return;
            }
            class_2338 stationPos = new class_2338(station.x(), station.y(), station.z());
            if (!CargoTransferService.hasAdjacentContainer(level, stationPos)) {
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43469("message.fabric_train_simulator.cargo.no_container", station.name()));
                return;
            }
            int moved = CargoTransferService.unloadAtStation(level, stationPos, cargo);
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43469(moved > 0
                    ? "message.fabric_train_simulator.cargo.unloaded_all"
                    : "message.fabric_train_simulator.cargo.nothing_unloaded", moved, station.name()));
        }));
    }

    public record Station(long id, String name, int etaSeconds) {}

    public record OpenPayload(int entityId, long selectedStationId, List<Station> stations) implements LegacyPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_cargo_settings"));
        public static final LegacyPayloadCodec<class_2540, OpenPayload> CODEC = LegacyPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(class_2540 b) {
            b.method_10804(entityId); b.method_10791(selectedStationId); b.method_10804(stations.size());
            for (Station station : stations) { b.method_10791(station.id()); b.method_10788(station.name(), 128); b.method_10804(station.etaSeconds()); }
        }
        private static OpenPayload read(class_2540 b) {
            int entityId = b.method_10816(); long selected = b.method_10792(); int size = cn.quit5700.fabrictrain.compat.MathCompat.clamp(b.method_10816(), 0, 1000);
            java.util.ArrayList<Station> stations = new java.util.ArrayList<>(size);
            for (int i = 0; i < size; i++) stations.add(new Station(b.method_10792(), b.method_10800(128), b.method_10816()));
            return new OpenPayload(entityId, selected, List.copyOf(stations));
        }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UpdatePayload(int entityId, long stationId) implements LegacyPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_cargo_settings"));
        public static final LegacyPayloadCodec<class_2540, UpdatePayload> CODEC = LegacyPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(class_2540 b) { b.method_10804(entityId); b.method_10791(stationId); }
        private static UpdatePayload read(class_2540 b) { return new UpdatePayload(b.method_10816(), b.method_10792()); }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UnloadAllPayload(int entityId) implements LegacyPayload {
        public static final Type<UnloadAllPayload> ID = new Type<>(FabricTrainMod.id("unload_all_cargo"));
        public static final LegacyPayloadCodec<class_2540, UnloadAllPayload> CODEC =
                LegacyPayload.codec((payload, buffer) -> buffer.method_10804(payload.entityId),
                        buffer -> new UnloadAllPayload(buffer.method_10816()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}



