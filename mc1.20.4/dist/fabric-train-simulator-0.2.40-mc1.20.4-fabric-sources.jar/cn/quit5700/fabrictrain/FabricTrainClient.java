package cn.quit5700.fabrictrain;

import cn.quit5700.fabrictrain.registry.ModEntities;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5602;
import cn.quit5700.fabrictrain.client.TrainVehicleRenderer;
import cn.quit5700.fabrictrain.client.TrainInputController;
import cn.quit5700.fabrictrain.client.DepotSettingsScreen;
import cn.quit5700.fabrictrain.client.TrainListScreen;
import cn.quit5700.fabrictrain.network.DepotNetworking;
import cn.quit5700.fabrictrain.network.LineSettingsNetworking;
import cn.quit5700.fabrictrain.client.LineSettingsScreen;
import cn.quit5700.fabrictrain.client.TrainClassScreen;
import cn.quit5700.fabrictrain.network.TrainClassNetworking;
import cn.quit5700.fabrictrain.network.CargoSettingsNetworking;
import cn.quit5700.fabrictrain.client.CargoSettingsScreen;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import cn.quit5700.fabrictrain.client.DeviceSettingsScreen;
import cn.quit5700.fabrictrain.network.LegacyClientPlayNetworking;
import cn.quit5700.fabrictrain.network.RailwayManagerNetworking;
import cn.quit5700.fabrictrain.client.RailwayManagerScreen;
import cn.quit5700.fabrictrain.train.DepotSettingsGesture;

public final class FabricTrainClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(),
                ModBlocks.SIGNAL_RAIL, ModBlocks.SWITCH_RAIL);
        EntityRendererRegistry.register(ModEntities.LOCOMOTIVE,
                context -> new TrainVehicleRenderer(context, class_5602.field_27614));
        EntityRendererRegistry.register(ModEntities.PASSENGER_CAR,
                context -> new TrainVehicleRenderer(context, class_5602.field_27614));
        EntityRendererRegistry.register(ModEntities.CARGO_CAR,
                context -> new TrainVehicleRenderer(context, class_5602.field_27614));
        TrainInputController.register();
        DepotSettingsGesture.installClientOpener(pos -> {
            boolean control=class_3675.method_15987(class_310.method_1551().method_22683().method_4490(),class_3675.field_31950)
                    ||class_3675.method_15987(class_310.method_1551().method_22683().method_4490(),class_3675.field_31954);
            if (!control) return false;
            LegacyClientPlayNetworking.send(new DepotNetworking.RequestOpenPayload(pos));
            return true;
        });
        LegacyClientPlayNetworking.registerGlobalReceiver(DepotNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new DepotSettingsScreen(payload))));
        LegacyClientPlayNetworking.registerGlobalReceiver(DepotNetworking.TrainListPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> {
                    if (!TrainListScreen.refreshActive(payload))
                        class_310.method_1551().method_1507(new TrainListScreen(payload));
                }));
        LegacyClientPlayNetworking.registerGlobalReceiver(LineSettingsNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new LineSettingsScreen(payload))));
        LegacyClientPlayNetworking.registerGlobalReceiver(TrainClassNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new TrainClassScreen(payload))));
        LegacyClientPlayNetworking.registerGlobalReceiver(CargoSettingsNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new CargoSettingsScreen(payload))));
        LegacyClientPlayNetworking.registerGlobalReceiver(DeviceSettingsNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new DeviceSettingsScreen(payload))));
        LegacyClientPlayNetworking.registerGlobalReceiver(RailwayManagerNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() -> class_310.method_1551().method_1507(
                        new RailwayManagerScreen(payload))));
    }
}


