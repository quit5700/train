package cn.quit5700.fabrictrain.compat;

import java.util.List;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2768;
import com.mojang.datafixers.util.Pair;

/** Minecraft 1.21.1 minecart helpers whose newer equivalents are not public in this version. */
public final class MinecartCompat {
    private MinecartCompat() {
    }

    public static class_2338 currentRailPos(class_1688 cart) {
        class_2338 current = cart.method_24515();
        if (class_2241.method_9479(cart.method_37908(), current)) return current;
        class_2338 below = current.method_10074();
        if (class_2241.method_9479(cart.method_37908(), below)) return below;
        class_2338 above = current.method_10084();
        if (class_2241.method_9479(cart.method_37908(), above)) return above;
        return current;
    }

    public static Pair<class_2382, class_2382> exits(class_2768 shape) {
        return switch (shape) {
            case field_12665 -> Pair.of(new class_2382(0, 0, -1), new class_2382(0, 0, 1));
            case field_12674 -> Pair.of(new class_2382(-1, 0, 0), new class_2382(1, 0, 0));
            case field_12667 -> Pair.of(new class_2382(-1, 0, 0), new class_2382(1, 1, 0));
            case field_12666 -> Pair.of(new class_2382(-1, 1, 0), new class_2382(1, 0, 0));
            case field_12670 -> Pair.of(new class_2382(0, 1, -1), new class_2382(0, 0, 1));
            case field_12668 -> Pair.of(new class_2382(0, 0, -1), new class_2382(0, 1, 1));
            case field_12664 -> Pair.of(new class_2382(0, 0, 1), new class_2382(1, 0, 0));
            case field_12671 -> Pair.of(new class_2382(0, 0, 1), new class_2382(-1, 0, 0));
            case field_12672 -> Pair.of(new class_2382(0, 0, -1), new class_2382(-1, 0, 0));
            case field_12663 -> Pair.of(new class_2382(0, 0, -1), new class_2382(1, 0, 0));
        };
    }
}
