package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.data.RailwaySavedData;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public final class DestinationUnloadService {
    private DestinationUnloadService() {}

    public static void tick(MinecraftServer server){
        for(class_3218 level:server.method_3738()){
            var data=RailwayDataManager.state(level);
            String dimension=RailwayDataManager.dimension(level);
            for(var entity:level.method_27909()){
                if(!(entity instanceof CargoCarEntity cargo)||cargo.method_5442())continue;
                long destination = CargoUnloadRules.effectiveDestination(cargo.destinationStationId(),
                        cargo.trainLink().destinationStationId());
                if (destination <= 0L) continue;
                var station=data.device(destination);
                if(station==null||station.type()!=DeviceType.STATION||!station.dimension().equals(dimension))continue;
                class_2338 stationPos=new class_2338(station.x(),station.y(),station.z());
                RailwayDevice currentStation = StationPresenceService.findStationAt(level, data, cargo);
                if (currentStation == null || currentStation.id() != station.id()) continue;
                CargoTransferService.unloadAtStation(level,stationPos,cargo);
            }
        }
    }
}
