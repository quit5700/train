package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.List;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;
import cn.quit5700.fabrictrain.cargo.StationPresenceService;
import cn.quit5700.fabrictrain.cargo.CargoTransferService;

public final class CargoSettingsNetworking {
    private CargoSettingsNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UnloadAllPayload.ID, UnloadAllPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof CargoCarEntity cargo) || context.player().method_5858(entity) > 64.0D) return;
            var data=RailwayDataManager.state(context.player().method_51469());
            if(StationSelectionService.canSelect(data,cargo.trainLink(),payload.stationId()))
                cargo.setDestinationStationId(payload.stationId());
        }));
        ServerPlayNetworking.registerGlobalReceiver(UnloadAllPayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof CargoCarEntity cargo) || context.player().method_5858(entity) > 64.0D) return;
            var level = (net.minecraft.class_3218) context.player().method_51469();
            var data = RailwayDataManager.state(level);
            RailwayDevice station = StationPresenceService.findStationAt(level, data, cargo);
            if (station == null) {
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.cargo.not_at_station"));
                return;
            }
            class_2338 stationPos = new class_2338(station.x(), station.y(), station.z());
            if (!CargoTransferService.hasAdjacentContainer(level, stationPos)) {
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43469("message.fabric_train_simulator.cargo.no_container", station.name()));
                return;
            }
            int moved = CargoTransferService.unloadAtStation(level, stationPos, cargo);
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43469(moved > 0
                    ? "message.fabric_train_simulator.cargo.unloaded_all"
                    : "message.fabric_train_simulator.cargo.nothing_unloaded", moved, station.name()));
        }));
    }

    public record Station(long id, String name, int etaSeconds) {}

    public record OpenPayload(int entityId, long selectedStationId, List<Station> stations) implements class_8710 {
        public static final class_9154<OpenPayload> ID = new class_9154<>(FabricTrainMod.id("open_cargo_settings"));
        public static final class_9139<class_9129, OpenPayload> CODEC = class_8710.method_56484(OpenPayload::write, OpenPayload::read);
        private void write(class_9129 b) {
            b.method_10804(entityId); b.method_10791(selectedStationId); b.method_10804(stations.size());
            for (Station station : stations) { b.method_10791(station.id()); b.method_10788(station.name(), 128); b.method_10804(station.etaSeconds()); }
        }
        private static OpenPayload read(class_9129 b) {
            int entityId = b.method_10816(); long selected = b.method_10792(); int size = Math.clamp(b.method_10816(), 0, 1000);
            java.util.ArrayList<Station> stations = new java.util.ArrayList<>(size);
            for (int i = 0; i < size; i++) stations.add(new Station(b.method_10792(), b.method_10800(128), b.method_10816()));
            return new OpenPayload(entityId, selected, List.copyOf(stations));
        }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record UpdatePayload(int entityId, long stationId) implements class_8710 {
        public static final class_9154<UpdatePayload> ID = new class_9154<>(FabricTrainMod.id("update_cargo_settings"));
        public static final class_9139<class_9129, UpdatePayload> CODEC = class_8710.method_56484(UpdatePayload::write, UpdatePayload::read);
        private void write(class_9129 b) { b.method_10804(entityId); b.method_10791(stationId); }
        private static UpdatePayload read(class_9129 b) { return new UpdatePayload(b.method_10816(), b.method_10792()); }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record UnloadAllPayload(int entityId) implements class_8710 {
        public static final class_9154<UnloadAllPayload> ID = new class_9154<>(FabricTrainMod.id("unload_all_cargo"));
        public static final class_9139<class_9129, UnloadAllPayload> CODEC =
                class_8710.method_56484((payload, buffer) -> buffer.method_10804(payload.entityId),
                        buffer -> new UnloadAllPayload(buffer.method_10816()));
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
