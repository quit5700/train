package cn.quit5700.fabrictrain.block;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2443;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

public final class DeviceRailBlock extends SignalRailBlock {
    public static final class_2758 SWITCH_CHOICE = class_2758.method_11867("switch_choice", 0, 2);
    public static final class_2754<class_2350> ENTRY_DIRECTION = class_2754.method_11848(
            "entry_direction", class_2350.class, class_2350.class_2353.field_11062);
    public static final class_2754<class_2350> PLACEMENT_ENTRY = class_2754.method_11848(
            "placement_entry", class_2350.class, class_2350.class_2353.field_11062);
    private final DeviceType type;

    public DeviceRailBlock(class_2251 properties, DeviceType type) {
        super(properties);
        this.type = type;
        method_9590(method_9564().method_11657(SWITCH_CHOICE, 1)
                .method_11657(ENTRY_DIRECTION, class_2350.field_11043).method_11657(PLACEMENT_ENTRY, class_2350.field_11043));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        builder.method_11667(SWITCH_CHOICE, ENTRY_DIRECTION, PLACEMENT_ENTRY);
    }
    @Override public void method_9567(class_1937 level, class_2338 pos, class_2680 state,
                                      net.minecraft.class_1309 placer, net.minecraft.class_1799 stack) {
        super.method_9567(level, pos, state, placer, stack);
        class_2350 entry = placer == null ? class_2350.field_11043 : placer.method_5735().method_10153();
        if (entry.method_10166() == class_2350.class_2351.field_11052) entry = class_2350.field_11043;
        class_2680 current = level.method_8320(pos);
        int choice = current.method_11654(SWITCH_CHOICE);
        level.method_8652(pos, current.method_11657(ENTRY_DIRECTION, entry).method_11657(PLACEMENT_ENTRY, entry)
                .method_11657(class_2443.field_11369, SwitchRailRouting.shapeForEntry(entry, choice)), 3);
        if(level instanceof class_3218 serverLevel) {
            RailwayDevice device=RailwayDataManager.register(serverLevel,pos,type);
            if(type==DeviceType.SWITCH)RailwayDataManager.state(serverLevel).updateSwitchEntry(device.id(),entry.ordinal());
        }
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        return class_1269.field_5811;
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos,
                                          class_1657 player, class_1268 hand, class_3965 hit) {
        return class_9062.field_47731;
    }

    @Override
    public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (level instanceof class_3218 serverLevel) {
            RailwayDataManager.remove(serverLevel, pos);
        }
        return super.method_9576(level, pos, state, player);
    }
}
