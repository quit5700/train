package cn.quit5700.fabrictrain.block.entity;


import cn.quit5700.fabrictrain.compat.NbtCompat;
import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.power.GeneratorFuelState;
import cn.quit5700.fabrictrain.registry.ModBlockEntities;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3917;
import net.minecraft.class_7225;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PowerGeneratorBlockEntity extends class_2624 {
    private static final Logger LOGGER = LoggerFactory.getLogger(PowerGeneratorBlockEntity.class);
    private static final String FUEL_UNTIL_KEY = "FuelUntilGameTime";
    private static final String LEGACY_REMAINING_KEY = "RemainingFuelTicks";
    private static final String RESERVED_FUEL_SLOT_KEY = "ReservedFuelSlot";
    public static final int SIZE = 9;
    public static final long REDSTONE_DUST_TICKS = 72_000L;
    public static final long REDSTONE_BLOCK_TICKS = 504_000L;
    private class_2371<class_1799> items = class_2371.method_10213(SIZE, class_1799.field_8037);
    private GeneratorFuelState fuelState = GeneratorFuelState.empty();
    private long lastObservedGameTime;
    private boolean active;

    public PowerGeneratorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.POWER_GENERATOR, pos, state);
    }

    public static void serverTick(class_3218 level, class_2338 pos, class_2680 state, PowerGeneratorBlockEntity generator) {
        long gameTime = level.method_8510();
        generator.lastObservedGameTime = gameTime;
        boolean before = generator.active;
        boolean migrated = generator.fuelState.migrateLegacyRemaining(gameTime);
        boolean expired = generator.fuelState.settleExpiredFuel(gameTime, generator::consumeReservedFuel);
        generator.active = generator.fuelState.isActive(gameTime);
        boolean activated = !generator.active && generator.activateFuelIfAvailable(level, gameTime);
        generator.active = generator.fuelState.isActive(gameTime);
        RailPowerService.updateGenerator(level, pos, generator.active);
        if (before != generator.active || activated || expired) {
            RailPowerService.refreshNow(level);
            generator.method_5431();
            level.method_8452(pos, state.method_26204());
        } else if (migrated) {
            generator.method_5431();
        }
    }

    private boolean activateFuelIfAvailable(class_3218 serverLevel, long gameTime) {
        for (int slot = 0; slot < items.size(); slot++) {
            class_1799 stack = items.get(slot);
            long fuelTicks = fuelDuration(stack);
            if (fuelTicks <= 0) continue;
            try {
                return fuelState.tryActivate(gameTime, fuelTicks, slot, () -> {
                    RailPowerService.updateGenerator(serverLevel, field_11867, true);
                    RailPowerService.refreshNow(serverLevel);
                    method_5431();
                    return true;
                });
            } catch (RuntimeException | Error failure) {
                RailPowerService.updateGenerator(serverLevel, field_11867, false);
                LOGGER.error("铁路发电机燃料提交失败，燃料未扣除：{}", field_11867, failure);
                return false;
            }
        }
        return false;
    }

    private boolean consumeReservedFuel(int slot) {
        if (slot < 0 || slot >= items.size()) return true;
        class_1799 stack = items.get(slot);
        if (fuelDuration(stack) <= 0L) {
            LOGGER.warn("铁路发电机到期燃料槽位已无有效燃料：{} 槽位 {}", field_11867, slot);
            return true;
        }
        stack.method_7934(1);
        method_5431();
        return true;
    }

    static long fuelDuration(class_1799 stack) {
        if (stack.method_31574(class_1802.field_8793)) return REDSTONE_BLOCK_TICKS;
        if (stack.method_31574(class_1802.field_8725)) return REDSTONE_DUST_TICKS;
        return 0L;
    }

    public boolean active() { return active; }
    public long remainingTicks() { return fuelState.remainingTicks(lastObservedGameTime); }
    @Override public int method_5439() { return SIZE; }
    @Override protected class_2371<class_1799> method_11282() { return items; }
    @Override protected void method_11281(class_2371<class_1799> value) { items = value; }
    @Override public class_1799 method_5434(int slot, int amount) {
        return isFuelSlotLocked(slot) ? class_1799.field_8037 : super.method_5434(slot, amount);
    }
    @Override public class_1799 method_5441(int slot) {
        return isFuelSlotLocked(slot) ? class_1799.field_8037 : super.method_5441(slot);
    }
    private boolean isFuelSlotLocked(int slot) {
        return active && fuelState.reservedFuelSlot() == slot;
    }
    @Override protected class_2561 method_17823() {
        long remainingTicks = remainingTicks();
        class_2561 status = remainingTicks > 0
                ? class_2561.method_43469("container.fabric_train_simulator.power_generator.remaining", formatRemainingTime())
                : class_2561.method_43471("container.fabric_train_simulator.power_generator.offline");
        return class_2561.method_43469("container.fabric_train_simulator.power_generator", status);
    }
    @Override protected class_1703 method_5465(int syncId, class_1661 inventory) {
        return new class_1707(class_3917.field_18664, syncId, inventory, this, 1);
    }
    @Override public boolean method_5437(int slot, class_1799 stack) {
        return stack.method_31574(class_1802.field_8725) || stack.method_31574(class_1802.field_8793);
    }
    @Override public boolean method_49104(class_1263 destination, int slot, class_1799 stack) {
        return !isFuelSlotLocked(slot);
    }

    private String formatRemainingTime() {
        long seconds = remainingTicks() / 20L;
        return String.format(java.util.Locale.ROOT, "%02d:%02d:%02d", seconds / 3600L,
                (seconds % 3600L) / 60L, seconds % 60L);
    }

    @Override protected void method_11007(class_2487 output, class_7225.class_7874 registries) {
        super.method_11007(output, registries);
        class_1262.method_5426(output, items, registries);
        output.method_10544(FUEL_UNTIL_KEY, fuelState.activeUntilGameTime());
        output.method_10544(LEGACY_REMAINING_KEY, remainingTicks());
        output.method_10569(RESERVED_FUEL_SLOT_KEY, fuelState.reservedFuelSlot());
    }

    @Override protected void method_11014(class_2487 input, class_7225.class_7874 registries) {
        super.method_11014(input, registries);
        items = class_2371.method_10213(SIZE, class_1799.field_8037);
        class_1262.method_5429(input, items, registries);
        long activeUntil = NbtCompat.getLong(input, FUEL_UNTIL_KEY, 0L);
        long legacyRemaining = NbtCompat.getLong(input, LEGACY_REMAINING_KEY, 0L);
        int reservedFuelSlot = NbtCompat.getInt(input, RESERVED_FUEL_SLOT_KEY, -1);
        fuelState = GeneratorFuelState.restore(activeUntil, legacyRemaining, reservedFuelSlot);
        lastObservedGameTime = 0L;
        active = activeUntil > 0L || legacyRemaining > 0L;
    }
}
