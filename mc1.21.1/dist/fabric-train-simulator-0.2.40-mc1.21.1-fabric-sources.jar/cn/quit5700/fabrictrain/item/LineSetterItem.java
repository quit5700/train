package cn.quit5700.fabrictrain.item;

import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import cn.quit5700.fabrictrain.network.LineSettingsNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import cn.quit5700.fabrictrain.network.RailwayManagerNetworking;

public final class LineSetterItem extends class_1792 {
    private static final Map<UUID, Long> EDITING_LINES = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> SELECTED_LINES = new ConcurrentHashMap<>();

    public LineSetterItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        if (level instanceof class_3218 serverLevel && player instanceof class_3222 serverPlayer) {
            cn.quit5700.fabrictrain.network.DepotRemoteAccessSessions.authorizeManager(
                    serverPlayer.method_5667(), System.nanoTime());
            RailwayManagerNetworking.open(serverPlayer);
        }
        return class_1271.method_29237(player.method_5998(hand), level.method_8608());
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if(context.method_8045() instanceof class_3218 level&&context.method_8036() instanceof class_3222 player) {
            cn.quit5700.fabrictrain.network.DepotRemoteAccessSessions.authorizeManager(
                    player.method_5667(), System.nanoTime());
            RailwayManagerNetworking.open(player,selectedLine(player.method_5667()));
        }
        return class_1269.field_5812;
    }

    private static DeviceType deviceType(class_2680 state) {
        if (state.method_27852(ModBlocks.TRAIN_DEPOT)) return DeviceType.DEPOT;
        if (state.method_27852(ModBlocks.STATION_MARKER)) return DeviceType.STATION;
        if (state.method_27852(ModBlocks.SWITCH_RAIL)) return DeviceType.SWITCH;
        return null;
    }

    public static void clearSessions() {
        EDITING_LINES.clear();
        SELECTED_LINES.clear();
    }

    public static long selectedLine(UUID playerId) {
        return SELECTED_LINES.getOrDefault(playerId, 0L);
    }

    public static void beginEditing(UUID playerId, long lineId) {
        EDITING_LINES.put(playerId, lineId);
        SELECTED_LINES.put(playerId, lineId);
    }
    public static void select(UUID playerId,long lineId){if(lineId>0)SELECTED_LINES.put(playerId,lineId);}

    private static long nextLineId(RailwaySavedData data, long selected) {
        java.util.List<Long> ids = data.lines().keySet().stream().sorted().toList();
        int current = ids.indexOf(selected);
        return ids.get((current + 1 + ids.size()) % ids.size());
    }
}
