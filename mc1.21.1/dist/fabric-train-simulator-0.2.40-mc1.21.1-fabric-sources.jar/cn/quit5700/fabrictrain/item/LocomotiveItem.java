package cn.quit5700.fabrictrain.item;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2241;
import net.minecraft.class_2680;
import net.minecraft.class_2768;

public final class LocomotiveItem extends class_1792 {
    private final class_1299<? extends class_1688> type;

    public LocomotiveItem(class_1299<? extends class_1688> type, class_1793 properties) {
        super(properties);
        this.type = type;
    }

    @Override public class_1269 method_7884(class_1838 context) {
        class_2680 state = context.method_8045().method_8320(context.method_8037());
        if (!class_2241.method_9476(state)) return class_1269.field_5814;
        if (!context.method_8045().method_8608()) {
            class_1688 minecart = type.method_5883(context.method_8045());
            if (minecart == null) return class_1269.field_5814;
            class_2768 shape = state.method_26204() instanceof class_2241 rail
                    ? state.method_11654(rail.method_9474()) : class_2768.field_12665;
            double yOffset = shape.method_11897() ? 0.5D : 0.0625D;
            minecart.method_5814(context.method_8037().method_10263() + 0.5D,
                    context.method_8037().method_10264() + yOffset,
                    context.method_8037().method_10260() + 0.5D);
            class_1799 stack = context.method_8041();
            context.method_8045().method_8649(minecart);
            stack.method_7934(1);
            if (minecart instanceof LocomotiveEntity locomotive && context.method_8036() != null) {
                locomotive.method_36456(context.method_8036().method_36454());
            }
        }
        return class_1269.method_29236(context.method_8045().method_8608());
    }
}
