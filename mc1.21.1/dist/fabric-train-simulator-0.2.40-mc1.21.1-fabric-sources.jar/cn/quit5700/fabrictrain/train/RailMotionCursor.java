package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.route.TrackPoint;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3218;

final class RailMotionCursor {
    private class_2338 previous;
    private class_2338 current;
    private class_2338 next;
    private double progress;
    private final List<class_2338> route;
    private final boolean loop;
    private final int loopStartIndex;
    private int routeIndex;

    private RailMotionCursor(class_2338 previous, class_2338 current, class_2338 next) {
        this(previous, current, next, List.of(), false, 0, 0);
    }

    private RailMotionCursor(class_2338 previous, class_2338 current, class_2338 next,
                             List<class_2338> route, boolean loop, int loopStartIndex, int routeIndex) {
        this.previous = previous;
        this.current = current;
        this.next = next;
        this.route = route;
        this.loop = loop;
        this.loopStartIndex = loopStartIndex;
        this.routeIndex = routeIndex;
    }

    static RailMotionCursor create(class_3218 level, class_1688 leader, class_243 facing) {
        class_2338 current = railAt(level, cn.quit5700.fabrictrain.compat.MinecartCompat.currentRailPos(leader));
        if (current == null) return null;
        var exits = exits(level, current);
        if (exits == null) return null;
        class_2338 first = railAt(level, current.method_10081(exits.getFirst()));
        class_2338 second = railAt(level, current.method_10081(exits.getSecond()));
        if (first == null && second == null) return null;
        class_2338 next;
        class_2338 previous;
        if (first == null) {
            next = second;
            previous = null;
        } else if (second == null) {
            next = first;
            previous = null;
        } else {
            class_243 firstDirection = class_243.method_24953(first).method_1020(class_243.method_24953(current)).method_1029();
            class_243 secondDirection = class_243.method_24953(second).method_1020(class_243.method_24953(current)).method_1029();
            if (firstDirection.method_1026(facing) >= secondDirection.method_1026(facing)) {
                next = first;
                previous = second;
            } else {
                next = second;
                previous = first;
            }
        }
        return new RailMotionCursor(previous, current, next);
    }

    static RailMotionCursor createRoute(class_3218 level, class_1688 leader, List<TrackPoint> points,
                                        boolean loop, int loopStartIndex) {
        if (points == null || points.size() < 2) return null;
        List<class_2338> route = points.stream().map(point -> new class_2338(point.x(), point.y(), point.z())).toList();
        class_2338 leaderRail = railAt(level, cn.quit5700.fabrictrain.compat.MinecartCompat.currentRailPos(leader));
        if (leaderRail == null) return null;
        int nearest = 0;
        double nearestDistance = Double.MAX_VALUE;
        for (int index = 0; index < route.size(); index++) {
            double distance = leader.method_19538().method_1025(center(route.get(index)));
            if (distance < nearestDistance) {
                nearest = index;
                nearestDistance = distance;
            }
        }
        class_2338 current = route.get(nearest);
        if (!current.equals(leaderRail)) return null;
        int safeLoopStart = Math.clamp(loopStartIndex, 0, route.size() - 2);
        int normalized = normalizeLoopIndex(route, loop, safeLoopStart, nearest);
        current = route.get(normalized);
        class_2338 previous = normalized > 0 ? route.get(normalized - 1) : null;
        class_2338 next = routeNext(route, loop, safeLoopStart, normalized);
        if (next == null) return null;
        RailMotionCursor cursor = new RailMotionCursor(previous, current, next, route, loop, safeLoopStart, normalized);
        cursor.progress = projectedProgress(leader.method_19538(), current, next);
        return cursor;
    }

    Pose advance(class_3218 level, double distance) {
        if (!route.isEmpty()) return advanceRoute(level, distance);
        double remaining = distance;
        int budget = 32;
        while (Math.abs(remaining) > 0.000001D && budget-- > 0) {
            if (remaining > 0) {
                if (next == null) return null;
                double length = center(current).method_1022(center(next));
                double available = Math.max(0, length - progress);
                if (remaining <= available) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining -= available;
                    class_2338 oldCurrent = current;
                    current = next;
                    previous = oldCurrent;
                    next = continuation(level, current, previous);
                    progress = 0;
                }
            } else {
                if (-remaining <= progress) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining += progress;
                    if (previous == null) return null;
                    class_2338 oldCurrent = current;
                    current = previous;
                    next = oldCurrent;
                    previous = continuation(level, current, next);
                    progress = center(current).method_1022(center(next));
                }
            }
        }
        if (next == null) return new Pose(center(current), 0);
        class_243 from = center(current);
        class_243 to = center(next);
        double length = from.method_1022(to);
        double ratio = length < 0.0001D ? 0 : Math.max(0, Math.min(1, progress / length));
        class_243 position = from.method_35590(to, ratio);
        class_243 tangent = to.method_1020(from);
        float yaw = (float) Math.toDegrees(Math.atan2(-tangent.field_1352, tangent.field_1350));
        return new Pose(position, yaw);
    }

    private Pose advanceRoute(class_3218 level, double distance) {
        double remaining = distance;
        int budget = 32;
        while (Math.abs(remaining) > 0.000001D && budget-- > 0) {
            if (!class_2241.method_9479(level, current) || next == null || !class_2241.method_9479(level, next)) return null;
            if (remaining > 0) {
                double length = center(current).method_1022(center(next));
                double available = Math.max(0, length - progress);
                if (remaining <= available) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining -= available;
                    previous = current;
                    current = next;
                    routeIndex = normalizeLoopIndex(route, loop, loopStartIndex, routeIndex + 1);
                    next = routeNext(route, loop, loopStartIndex, routeIndex);
                    progress = 0;
                    if (next == null && remaining > 0.000001D) return null;
                }
            } else {
                if (-remaining <= progress) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining += progress;
                    if (previous == null) return null;
                    next = current;
                    current = previous;
                    routeIndex = Math.max(0, routeIndex - 1);
                    previous = routeIndex > 0 ? route.get(routeIndex - 1) : null;
                    progress = center(current).method_1022(center(next));
                }
            }
        }
        if (next == null) return new Pose(center(current), 0);
        class_243 from = center(current);
        class_243 to = center(next);
        double length = from.method_1022(to);
        double ratio = length < 0.0001D ? 0 : Math.max(0, Math.min(1, progress / length));
        class_243 position = from.method_35590(to, ratio);
        class_243 tangent = to.method_1020(from);
        float yaw = (float) Math.toDegrees(Math.atan2(-tangent.field_1352, tangent.field_1350));
        return new Pose(position, yaw);
    }

    private static int normalizeLoopIndex(List<class_2338> route, boolean loop, int loopStartIndex, int index) {
        if (!loop || index < route.size() - 1) return Math.min(index, route.size() - 1);
        return route.getLast().equals(route.get(loopStartIndex)) ? loopStartIndex : Math.min(index, route.size() - 1);
    }

    private static class_2338 routeNext(List<class_2338> route, boolean loop, int loopStartIndex, int index) {
        if (index + 1 < route.size()) return route.get(index + 1);
        if (!loop || route.size() < 2) return null;
        return route.get(loopStartIndex);
    }

    private static double projectedProgress(class_243 position, class_2338 current, class_2338 next) {
        class_243 from = center(current);
        class_243 segment = center(next).method_1020(from);
        double lengthSquared = segment.method_1027();
        if (lengthSquared < 0.000001D) return 0;
        double ratio = Math.max(0, Math.min(1, position.method_1020(from).method_1026(segment) / lengthSquared));
        return Math.sqrt(lengthSquared) * ratio;
    }

    Optional<class_2350> travelDirection(boolean forward) {
        class_2338 target=forward?next:previous;
        if(target==null)return Optional.empty();
        return FormationDirection.fromPositions(target.method_10263(),target.method_10260(),current.method_10263(),current.method_10260());
    }

    class_2338 currentRail() { return current; }
    class_2338 nextRail() { return next == null ? current : next; }
    int routeIndex() { return routeIndex; }
    double segmentProgress() { return progress; }

    void snapTo(class_2338 stopPos) {
        if (stopPos == null) return;
        if (route.isEmpty()) {
            if (current.equals(stopPos)) progress = 0.0D;
            return;
        }
        int selected = -1;
        for (int index = Math.clamp(routeIndex, 0, route.size() - 1); index < route.size(); index++) {
            if (route.get(index).equals(stopPos)) {
                selected = index;
                break;
            }
        }
        if (selected < 0) {
            for (int index = 0; index < Math.clamp(routeIndex, 0, route.size()); index++) {
                if (route.get(index).equals(stopPos)) {
                    selected = index;
                    break;
                }
            }
        }
        if (selected < 0) return;
        routeIndex = selected;
        current = route.get(selected);
        previous = selected > 0 ? route.get(selected - 1) : null;
        next = routeNext(route, loop, loopStartIndex, selected);
        progress = 0.0D;
    }

    Optional<class_2768> routeShapeAt(class_2338 switchPos) {
        return routeShapeAt(route, loop, loopStartIndex, routeIndex, previous, switchPos);
    }

    static Optional<class_2768> routeShapeAt(List<class_2338> route, boolean loop, int loopStartIndex,
                                            int routeIndex, class_2338 previous, class_2338 switchPos) {
        if (route.isEmpty() || switchPos == null) return Optional.empty();
        int start = Math.clamp(routeIndex, 0, route.size() - 1);
        for (int index = start; index < route.size(); index++) {
            if (!route.get(index).equals(switchPos)) continue;
            class_2338 before = index > 0 ? route.get(index - 1) : previous;
            class_2338 after;
            if (index + 1 < route.size()) {
                after = route.get(index + 1);
            } else if (loop && loopStartIndex + 1 < route.size()) {
                after = route.get(loopStartIndex + 1);
            } else {
                after = null;
            }
            Optional<class_2350> incomingSide = horizontalSide(switchPos, before);
            Optional<class_2350> outgoingSide = horizontalSide(switchPos, after);
            if (incomingSide.isPresent() && outgoingSide.isPresent()
                    && incomingSide.get() != outgoingSide.get()) {
                return Optional.of(cn.quit5700.fabrictrain.route.SwitchRailRouting.shapeBetween(
                        incomingSide.get(), outgoingSide.get()));
            }
        }
        return Optional.empty();
    }

    private static Optional<class_2350> horizontalSide(class_2338 origin, class_2338 neighbour) {
        if (origin == null || neighbour == null) return Optional.empty();
        int dx = neighbour.method_10263() - origin.method_10263();
        int dz = neighbour.method_10260() - origin.method_10260();
        if (dx == 0 && dz == 0) return Optional.empty();
        if (Math.abs(dx) >= Math.abs(dz)) return Optional.of(dx >= 0 ? class_2350.field_11034 : class_2350.field_11039);
        return Optional.of(dz >= 0 ? class_2350.field_11035 : class_2350.field_11043);
    }

    private static class_2338 continuation(class_3218 level, class_2338 at, class_2338 cameFrom) {
        var exits = exits(level, at);
        if (exits == null) return null;
        class_2338 first = railAt(level, at.method_10081(exits.getFirst()));
        class_2338 second = railAt(level, at.method_10081(exits.getSecond()));
        if (first != null && !first.equals(cameFrom)) return first;
        if (second != null && !second.equals(cameFrom)) return second;
        return null;
    }

    private static com.mojang.datafixers.util.Pair<net.minecraft.class_2382, net.minecraft.class_2382> exits(
            class_3218 level, class_2338 pos) {
        var state = level.method_8320(pos);
        if (!state.method_28498(class_2443.field_11369)) return null;
        return cn.quit5700.fabrictrain.compat.MinecartCompat.exits(state.method_11654(class_2443.field_11369));
    }

    private static class_2338 railAt(class_3218 level, class_2338 pos) {
        if (class_2241.method_9479(level, pos)) return pos;
        if (class_2241.method_9479(level, pos.method_10074())) return pos.method_10074();
        if (class_2241.method_9479(level, pos.method_10084())) return pos.method_10084();
        return null;
    }

    private static class_243 center(class_2338 pos) {
        return class_243.method_24955(pos).method_1031(0, 0.1D, 0);
    }

    record Pose(class_243 position, float yaw) {}
}

