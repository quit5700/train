package cn.quit5700.fabrictrain.registry;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModEntities {
    public static final class_1299<LocomotiveEntity> LOCOMOTIVE = register(
            "locomotive", LocomotiveEntity::new);
    public static final class_1299<PassengerCarEntity> PASSENGER_CAR = register(
            "passenger_car", PassengerCarEntity::new);
    public static final class_1299<CargoCarEntity> CARGO_CAR = register(
            "cargo_car", CargoCarEntity::new);

    private ModEntities() {
    }

    private static <T extends class_1297> class_1299<T> register(String path, class_1299.class_4049<T> factory) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, id);
        class_1299<T> type = class_1299.class_1300.method_5903(factory, class_1311.field_17715)
                .method_17687(0.98F, 0.7F)
                .method_27299(10)
                .method_27300(1)
                .method_5905(id.toString());
        return class_2378.method_10230(class_7923.field_41177, id, type);
    }

    public static void initialize() {
    }
}
