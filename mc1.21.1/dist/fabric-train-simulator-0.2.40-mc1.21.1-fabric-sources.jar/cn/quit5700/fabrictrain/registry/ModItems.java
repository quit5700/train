package cn.quit5700.fabrictrain.registry;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.item.LineSetterItem;
import cn.quit5700.fabrictrain.item.TrainConnectorItem;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class ModItems {
    public static final class_1792 SIGNAL_RAIL = registerBlock("signal_rail", ModBlocks.SIGNAL_RAIL);
    public static final class_1792 SWITCH_RAIL = registerBlock("switch_rail", ModBlocks.SWITCH_RAIL);
    public static final class_1792 TRAIN_DEPOT = registerBlock("train_depot", ModBlocks.TRAIN_DEPOT);
    public static final class_1792 STATION_MARKER = registerBlock("station_marker", ModBlocks.STATION_MARKER);
    public static final class_1792 POWER_GENERATOR = registerBlock("power_generator", ModBlocks.POWER_GENERATOR);
    public static final class_1792 LOCOMOTIVE = registerLocomotive("locomotive", ModEntities.LOCOMOTIVE);
    public static final class_1792 PASSENGER_CAR = registerMinecart("passenger_car", ModEntities.PASSENGER_CAR);
    public static final class_1792 CARGO_CAR = registerMinecart("cargo_car", ModEntities.CARGO_CAR);
    public static final class_1792 LINE_SETTER = register("line_setter");
    public static final class_1792 TRAIN_CONNECTOR = register("train_connector");

    private ModItems() {
    }

    private static class_1792 registerBlock(String path, net.minecraft.class_2248 block) {
        class_2960 id = FabricTrainMod.id(path);
        class_1792.class_1793 properties = properties(id);
        return class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, properties));
    }

    private static class_1792 register(String path) {
        class_2960 id = FabricTrainMod.id(path);
        class_1792.class_1793 properties = properties(id);
        if (path.equals("line_setter") || path.equals("train_connector")) {
            properties.method_7889(1);
        } else {
            properties.method_7889(64);
        }
        class_1792 item = path.equals("line_setter") ? new LineSetterItem(properties)
                : path.equals("train_connector") ? new TrainConnectorItem(properties) : new class_1792(properties);
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }

    private static class_1792 registerMinecart(String path, net.minecraft.class_1299<? extends net.minecraft.class_1688> type) {
        class_2960 id = FabricTrainMod.id(path);
        return class_2378.method_10230(class_7923.field_41178, id, new cn.quit5700.fabrictrain.item.LocomotiveItem(type, properties(id).method_7889(64)));
    }
    private static class_1792 registerLocomotive(String path,net.minecraft.class_1299<? extends net.minecraft.class_1688> type){class_2960 id=FabricTrainMod.id(path);return class_2378.method_10230(class_7923.field_41178,id,new cn.quit5700.fabrictrain.item.LocomotiveItem(type,properties(id).method_7889(64)));}

    private static class_1792.class_1793 properties(class_2960 id) {
        return new class_1792.class_1793();
    }

    public static void initialize() {
    }
}
