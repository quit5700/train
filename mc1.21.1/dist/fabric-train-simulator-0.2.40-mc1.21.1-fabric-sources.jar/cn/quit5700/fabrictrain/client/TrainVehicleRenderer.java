package cn.quit5700.fabrictrain.client;

import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_580;
import net.minecraft.class_925;

/**
 * Keeps vanilla minecart positioning and rail rotation while suppressing only
 * the vanilla minecart shell. The entity display block remains visible.
 */
public final class TrainVehicleRenderer extends class_925 {
    public TrainVehicleRenderer(class_5617.class_5618 context, class_5601 layer) {
        super(context, layer);
        ((class_580<?>) field_4747).method_32008().field_3665 = false;
    }
}
