package cn.quit5700.fabrictrain.route;

import net.minecraft.class_2350;

public final class SwitchEntryDirectionRules {
    private SwitchEntryDirectionRules() {}

    public static class_2350 resolve(int savedOrdinal, class_2350 placementEntry) {
        if (placementEntry == null || placementEntry.method_10166() == class_2350.class_2351.field_11052) placementEntry = class_2350.field_11043;
        if (savedOrdinal >= 0 && savedOrdinal < class_2350.values().length) {
            class_2350 saved = class_2350.values()[savedOrdinal];
            if (saved.method_10166() != class_2350.class_2351.field_11052) return saved;
        }
        return placementEntry;
    }
}
