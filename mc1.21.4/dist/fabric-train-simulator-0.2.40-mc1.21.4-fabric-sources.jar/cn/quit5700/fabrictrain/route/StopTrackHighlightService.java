package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.data.RailwayLine;
import cn.quit5700.fabrictrain.item.LineSetterItem;
import cn.quit5700.fabrictrain.registry.ModItems;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

/** Visual-only marker. It never changes the rail state or train physics. */
public final class StopTrackHighlightService {
    private static long ticks;

    private StopTrackHighlightService() {}

    public static void tick(MinecraftServer server) {
        if (++ticks % 10L != 0L) return;
        for (var player : server.method_3760().method_14571()) {
            if (!player.method_6047().method_31574(ModItems.LINE_SETTER)
                    && !player.method_6079().method_31574(ModItems.LINE_SETTER)) continue;
            class_3218 level = (class_3218) player.method_51469();
            long lineId = LineSetterItem.selectedLine(player.method_5667());
            RailwayLine line = RailwayDataManager.state(level).line(lineId);
            if (line == null) continue;
            var data = RailwayDataManager.state(level);
            for (var entry : line.stationStopTracks().entrySet()) {
                int index = entry.getKey();
                if (index < 0 || index >= line.nodeIds().size()) continue;
                RailwayDevice station = data.device(line.nodeIds().get(index));
                if (station == null || !station.dimension().equals(RailwayDataManager.dimension(level))) continue;
                var stop = entry.getValue();
                class_2338 pos = new class_2338(stop.x(), stop.y(), stop.z());
                if (!level.method_22340(pos) || player.method_5649(stop.x() + 0.5D, stop.y() + 0.5D, stop.z() + 0.5D) > 4096.0D)
                    continue;
                level.method_14166(player, class_2398.field_11207, false, true,
                        stop.x() + 0.5D, stop.y() + 0.2D, stop.z() + 0.5D,
                        4, 0.35D, 0.05D, 0.35D, 0.0D);
            }
        }
    }
}
