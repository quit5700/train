package cn.quit5700.fabrictrain.route;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_2382;
import net.minecraft.class_2768;

/** Resolves block-to-block rail connections using the same coordinates as vanilla RailState. */
public final class RailConnectionResolver {
    private RailConnectionResolver() {}

    public static List<class_2382> connectionOffsets(class_2768 shape) {
        return switch (shape) {
            case field_12665 -> List.of(new class_2382(0, 0, -1), new class_2382(0, 0, 1));
            case field_12674 -> List.of(new class_2382(-1, 0, 0), new class_2382(1, 0, 0));
            case field_12667 -> List.of(new class_2382(-1, 0, 0), new class_2382(1, 1, 0));
            case field_12666 -> List.of(new class_2382(-1, 1, 0), new class_2382(1, 0, 0));
            case field_12670 -> List.of(new class_2382(0, 1, -1), new class_2382(0, 0, 1));
            case field_12668 -> List.of(new class_2382(0, 0, -1), new class_2382(0, 1, 1));
            case field_12664 -> List.of(new class_2382(0, 0, 1), new class_2382(1, 0, 0));
            case field_12671 -> List.of(new class_2382(0, 0, 1), new class_2382(-1, 0, 0));
            case field_12672 -> List.of(new class_2382(0, 0, -1), new class_2382(-1, 0, 0));
            case field_12663 -> List.of(new class_2382(0, 0, -1), new class_2382(1, 0, 0));
        };
    }

    /**
     * Returns both shape exits in their stable vanilla order.  RailState first checks the
     * expected position, then the block above it, then the block below it.
     */
    public static List<TrackPoint> connectedCandidates(TrackPoint origin, class_2768 shape,
                                                        Predicate<TrackPoint> isRail) {
        ArrayList<TrackPoint> result = new ArrayList<>(2);
        for (class_2382 offset : connectionOffsets(shape)) {
            TrackPoint expected = new TrackPoint(origin.x() + offset.method_10263(), origin.y() + offset.method_10264(),
                    origin.z() + offset.method_10260());
            result.add(resolveExpected(expected, isRail));
        }
        return List.copyOf(result);
    }

    public static List<TrackPoint> neighbours(TrackPoint origin, class_2768 shape,
                                               Predicate<TrackPoint> isRail) {
        return connectedCandidates(origin, shape, isRail).stream().filter(isRail).distinct().toList();
    }

    private static TrackPoint resolveExpected(TrackPoint expected, Predicate<TrackPoint> isRail) {
        if (isRail.test(expected)) return expected;
        TrackPoint above = new TrackPoint(expected.x(), expected.y() + 1, expected.z());
        if (isRail.test(above)) return above;
        TrackPoint below = new TrackPoint(expected.x(), expected.y() - 1, expected.z());
        return isRail.test(below) ? below : expected;
    }
}
