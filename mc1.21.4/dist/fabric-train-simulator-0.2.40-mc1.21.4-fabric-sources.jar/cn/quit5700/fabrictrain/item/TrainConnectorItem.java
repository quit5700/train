package cn.quit5700.fabrictrain.item;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_9334;

public final class TrainConnectorItem extends class_1792 {
    private static final Map<UUID, UUID> SELECTED = new HashMap<>();

    public TrainConnectorItem(class_1793 properties) {
        super(properties);
    }

    public static UUID selected(class_3222 player) {
        return SELECTED.get(player.method_5667());
    }

    public static void select(class_3222 player, UUID entityId, class_1799 stack) {
        SELECTED.put(player.method_5667(), entityId);
        stack.method_57379(class_9334.field_49641, true);
        player.field_7498.method_7623();
    }

    public static void clear(class_3222 player, class_1799 stack) {
        SELECTED.remove(player.method_5667());
        stack.method_57379(class_9334.field_49641, false);
        player.field_7498.method_7623();
    }

    public static void clearSessions() {
        SELECTED.clear();
    }
}
