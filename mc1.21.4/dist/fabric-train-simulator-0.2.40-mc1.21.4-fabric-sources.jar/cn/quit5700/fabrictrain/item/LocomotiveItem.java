package cn.quit5700.fabrictrain.item;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1688;
import net.minecraft.class_1808;
import net.minecraft.class_1838;
import net.minecraft.class_238;

public final class LocomotiveItem extends class_1808 {
    public LocomotiveItem(class_1299<? extends class_1688> type,class_1793 properties){super(type,properties);}
    @Override public class_1269 method_7884(class_1838 context){
        class_1269 result=super.method_7884(context);
        if(!context.method_8045().method_8608()&&context.method_8036()!=null){class_238 area=new class_238(context.method_8037()).method_1014(1.5);context.method_8045().method_18467(LocomotiveEntity.class,area).stream().filter(l->l.field_6012<3&&l.trainLink().parked()).min(java.util.Comparator.comparingDouble(l->l.method_5858(context.method_8036()))).ifPresent(l->l.method_36456(context.method_8036().method_36454()));}
        return result;
    }
}
