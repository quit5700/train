package cn.quit5700.fabrictrain.block;

import cn.quit5700.fabrictrain.block.entity.PowerGeneratorBlockEntity;
import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.registry.ModBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_9904;

public final class PowerGeneratorBlock extends class_2237 {
    public static final MapCodec<PowerGeneratorBlock> CODEC = method_54094(PowerGeneratorBlock::new);
    public PowerGeneratorBlock(class_2251 properties) { super(properties); }
    @Override protected MapCodec<? extends class_2237> method_53969() { return field_46280; }
    @Override public class_2586 method_10123(class_2338 pos, class_2680 state) { return new PowerGeneratorBlockEntity(pos, state); }
    @Override protected class_2464 method_9604(class_2680 state) { return class_2464.field_11458; }
    @Override protected boolean method_9506(class_2680 state) { return true; }
    @Override protected int method_9524(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
        return level.method_8321(pos) instanceof PowerGeneratorBlockEntity generator && generator.active() ? 15 : 0;
    }

    @Override protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!level.method_8608() && level.method_8321(pos) instanceof PowerGeneratorBlockEntity generator) player.method_17355(generator);
        return class_1269.field_5812;
    }

    @Override public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (level instanceof class_3218 serverLevel) RailPowerService.removeGenerator(serverLevel, pos);
        if (!level.method_8608() && level.method_8321(pos) instanceof PowerGeneratorBlockEntity generator) class_1264.method_5451(level, pos, generator);
        return super.method_9576(level, pos, state, player);
    }

    @Override protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 source,
                                             class_9904 orientation, boolean moved) {
        super.method_9612(state, level, pos, source, orientation, moved);
        if (level instanceof class_3218 serverLevel) RailPowerService.markDirty(serverLevel);
    }

    @Override public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        return level instanceof class_3218 ? method_31618(type, ModBlockEntities.POWER_GENERATOR,
                (tickLevel, pos, tickState, generator) -> {
                    if (tickLevel instanceof class_3218 serverLevel) {
                        PowerGeneratorBlockEntity.serverTick(serverLevel, pos, tickState, generator);
                    }
                }) : null;
    }
}
