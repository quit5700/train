package cn.quit5700.fabrictrain.block;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import com.mojang.serialization.MapCodec;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import cn.quit5700.fabrictrain.network.DepotNetworking;

public final class TrainDepotBlock extends class_2237 {
    public static final MapCodec<TrainDepotBlock> CODEC = method_54094(TrainDepotBlock::new);
    public static final class_2754<class_2350> FACING = class_2741.field_12481;

    public TrainDepotBlock(class_2251 properties) { super(properties); method_9590(field_10647.method_11664().method_11657(FACING, class_2350.field_11043)); }
    @Override public class_2680 method_9605(class_1750 context) { return method_9564().method_11657(FACING, context.method_8042().method_10153()); }
    @Override protected void method_9515(class_2689.class_2690<net.minecraft.class_2248, class_2680> builder) { builder.method_11667(FACING); }
    @Override protected MapCodec<? extends class_2237> method_53969() { return field_46280; }
    @Override public class_2586 method_10123(class_2338 pos, class_2680 state) { return new TrainDepotBlockEntity(pos, state); }
    @Override protected class_2464 method_9604(class_2680 state) { return class_2464.field_11458; }
    @Override public void method_9567(class_1937 level,class_2338 pos,class_2680 state,net.minecraft.class_1309 placer,net.minecraft.class_1799 stack){super.method_9567(level,pos,state,placer,stack);if(level instanceof class_3218 serverLevel)RailwayDataManager.register(serverLevel,pos,DeviceType.DEPOT);}

    @Override protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        if (level instanceof class_3218 serverLevel) {
            RailwayDataManager.register(serverLevel, pos, DeviceType.DEPOT);
            if (player instanceof class_3222 serverPlayer && level.method_8321(pos) instanceof TrainDepotBlockEntity depot) {
                if(player.method_5715())return class_1269.field_5811;
                serverPlayer.method_17355(depot);
            }
        }
        return class_1269.field_5812;
    }

    @Override protected class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos,
                                                     class_1657 player, class_1268 hand, class_3965 hit) {
        return class_1269.field_5811;
    }

    @Override public class_2680 method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (level instanceof class_3218 serverLevel) RailwayDataManager.remove(serverLevel, pos);
        if (!level.method_8608() && level.method_8321(pos) instanceof TrainDepotBlockEntity depot) {
            class_1264.method_5451(level, pos, depot);
        }
        return super.method_9576(level, pos, state, player);
    }
}
