package cn.quit5700.fabrictrain.block;

import cn.quit5700.fabrictrain.power.RailPowerService;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2443;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_9904;

public class SignalRailBlock extends class_2443 {
    public SignalRailBlock(class_4970.class_2251 properties) {
        super(properties);
    }

    @Override protected void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean moved) {
        super.method_9615(state, level, pos, oldState, moved);
        if (level instanceof class_3218 serverLevel) RailPowerService.markDirty(serverLevel);
    }

    @Override protected void method_9536(class_2680 state, class_1937 level, class_2338 pos,
                                      class_2680 replacement, boolean moved) {
        super.method_9536(state, level, pos, replacement, moved);
        if (level instanceof class_3218 serverLevel) RailPowerService.markDirty(serverLevel);
    }

    @Override protected void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 source,
                                             class_9904 orientation, boolean moved) {
        super.method_9612(state, level, pos, source, orientation, moved);
        if (level instanceof class_3218 serverLevel) RailPowerService.markDirty(serverLevel);
    }
}
