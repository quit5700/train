package cn.quit5700.fabrictrain.redstone;

import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2401;
import net.minecraft.class_2440;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.*;
import java.util.*;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;

public final class DeviceRedstoneService {
    private static final Map<Long,SignalKind> LAST=new HashMap<>();
    private DeviceRedstoneService(){}
    public static void tick(MinecraftServer server){
        RailwaySavedData data=RailwayDataManager.state(server.method_30002());
        for(class_3218 level:server.method_3738())for(RailwayDevice device:data.devices().values()){
            if(!device.dimension().equals(RailwayDataManager.dimension(level)))continue;
            SignalKind now=signal(level,new class_2338(device.x(),device.y(),device.z()));SignalKind before=LAST.getOrDefault(device.id(),SignalKind.NONE);LAST.put(device.id(),now);
            if(device.type()==DeviceType.STATION){
                if(now==SignalKind.CONTINUOUS)TrainControllerManager.emergencyStopAt(device.id());
                else if(before==SignalKind.CONTINUOUS)TrainControllerManager.releaseEmergencyAt(device.id());
                else if(now==SignalKind.PULSE&&before!=SignalKind.PULSE)TrainControllerManager.departStation(server,device.id());
            }else if(device.type()==DeviceType.SWITCH&&now==SignalKind.PULSE&&before!=SignalKind.PULSE){
                int direction=(device.switchShapeOrdinal()+1)%3;
                data.updateDevice(device.id(),device.name(),device.dwellSeconds(),direction,device.announcement());
                SwitchRailRouting.applyChoice(level,device,direction);
                class_2561 message=class_2561.method_43471("screen.fabric_train_simulator.switch."+(direction==0?"left":direction==1?"straight":"right"));
                level.method_18456().stream().filter(p->p.method_5649(device.x()+.5,device.y()+.5,device.z()+.5)<=1024).forEach(p->p.method_7353(message, true));
            }
        }
    }
    public static void clear(){LAST.clear();}
    static SignalKind signal(class_3218 level,class_2338 device){
        ArrayDeque<class_2338> queue=new ArrayDeque<>();HashSet<class_2338> seen=new HashSet<>();
        for(class_2350 d:class_2350.values())queue.add(device.method_10093(d));
        int budget=128;
        while(!queue.isEmpty()&&budget-->0){class_2338 pos=queue.removeFirst();if(!seen.add(pos))continue;class_2680 state=level.method_8320(pos);class_2248 block=state.method_26204();
            if(block==class_2246.field_10091){for(class_2350 d:class_2350.values())queue.add(pos.method_10093(d));continue;}
            if(!powered(state,level,pos))continue;
            if(block instanceof class_2269||block instanceof class_2440)return SignalKind.PULSE;
            if(block instanceof class_2401||block==class_2246.field_10002||block==class_2246.field_10523||block==class_2246.field_10301)return SignalKind.CONTINUOUS;
        }
        return SignalKind.NONE;
    }
    private static boolean powered(class_2680 state,class_3218 level,class_2338 pos){
        if(state.method_28498(class_2741.field_12484)&&state.method_11654(class_2741.field_12484))return true;
        if(state.method_26204()==class_2246.field_10002)return true;
        for(class_2350 direction:class_2350.values())if(state.method_26195(level,pos,direction)>0)return true;return false;
    }
    enum SignalKind{NONE,PULSE,CONTINUOUS}
}
