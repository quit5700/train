package cn.quit5700.fabrictrain.depot;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.*;
import cn.quit5700.fabrictrain.registry.ModEntities;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.CarType;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.train.SpeedRules;
import cn.quit5700.fabrictrain.train.ControlMode;
import cn.quit5700.fabrictrain.train.FormationDirection;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import cn.quit5700.fabrictrain.train.TrainRegistryService;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_2768;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.server.MinecraftServer;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import cn.quit5700.fabrictrain.route.TrackPoint;
import cn.quit5700.fabrictrain.route.RuntimePathCache;
import cn.quit5700.fabrictrain.route.LineLoopRules;

import java.util.*;

public final class DepotDispatchService {
    private static final Map<Long, Long> LAST_DISPATCH_TICK = new HashMap<>();
    private static long ticks;

    private DepotDispatchService() {}

    public static void tick(MinecraftServer server) {
        ticks++;
        if (ticks % 20 != 0) return;
        for (class_3218 level : server.method_3738()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            for (RailwayDevice device : data.devices().values()) {
                if (device.type() != DeviceType.DEPOT
                        || !device.dimension().equals(RailwayDataManager.dimension(level))) continue;
                class_2338 pos = new class_2338(device.x(), device.y(), device.z());
                if (level.method_22340(pos) && level.method_8321(pos) instanceof TrainDepotBlockEntity depot)
                    absorbConnectedVehicles(level, pos, depot);
            }
            for (RailwayLine line : data.lines().values()) {
                if (line.status() != LineStatus.RUNNING) continue;
                long last = LAST_DISPATCH_TICK.getOrDefault(line.id(), Long.MIN_VALUE / 2);
                RailwayDevice depot = data.device(line.depotId());
                if (depot == null || !depot.dimension().equals(RailwayDataManager.dimension(level))) continue;
                class_2338 depotPos = new class_2338(depot.x(), depot.y(), depot.z());
                if (!level.method_22340(depotPos) || !(level.method_8321(depotPos) instanceof TrainDepotBlockEntity inventory)) continue;
                if (!AutomaticDispatchSchedule.shouldAttempt(inventory.automaticDispatchEnabled(),
                        inventory.selectedLineId() == line.id(), data.activeTrainCount(line.id()),
                        inventory.maximumTrains(), ticks, last, inventory.dispatchIntervalSeconds())) continue;
                DepotDispatchResult result = dispatch(level, depotPos, line, inventory,
                        DepotDispatchConfig.saved(inventory), !inventory.creativeAutomaticDispatch(),
                        ControlMode.ROUTE_AUTOMATIC).result();
                inventory.setLastAutomaticDispatchResult(result);
                if (result.succeeded()) LAST_DISPATCH_TICK.put(line.id(), ticks);
            }
        }
    }

    public static int absorbConnectedVehicles(class_3218 level, class_2338 pos, TrainDepotBlockEntity depot) {
        int moved = 0;
        for (class_2350 direction : class_2350.values()) {
            if (!(level.method_8321(pos.method_10093(direction)) instanceof class_1263 source) || source == depot) continue;
            for (int slot=0;slot<source.method_5439();slot++) {
                class_1799 stack=source.method_5438(slot);
                if (stack.method_7960() || !(stack.method_31574(ModItems.LOCOMOTIVE)
                        || stack.method_31574(ModItems.PASSENGER_CAR) || stack.method_31574(ModItems.CARGO_CAR))) continue;
                int before=stack.method_7947();
                insertIntoDepot(depot,stack);
                if(before!=stack.method_7947()){moved+=before-stack.method_7947();source.method_5447(slot,stack);source.method_5431();}
            }
        }
        if(moved>0)depot.method_5431();
        return moved;
    }

    private static void insertIntoDepot(TrainDepotBlockEntity depot,class_1799 source) {
        for(int slot=0;slot<depot.method_5439()&&!source.method_7960();slot++){
            class_1799 target=depot.method_5438(slot);
            if(target.method_7960()||!class_1799.method_31577(target,source))continue;
            int amount=Math.min(depot.method_58350(target)-target.method_7947(),source.method_7947());
            if(amount>0){target.method_7933(amount);source.method_7934(amount);depot.method_5447(slot,target);}
        }
        for(int slot=0;slot<depot.method_5439()&&!source.method_7960();slot++){
            if(!depot.method_5438(slot).method_7960()||!depot.method_5437(slot,source))continue;
            int amount=Math.min(depot.method_58350(source),source.method_7947());
            depot.method_5447(slot,source.method_46651(amount));source.method_7934(amount);
        }
    }

    public static boolean dispatchNow(class_3218 level, class_2338 depotPos, RailwayLine line,
                                      TrainDepotBlockEntity inventory, boolean consumeItems) {
        return dispatchNowDetailed(level, depotPos, line, inventory, consumeItems).succeeded();
    }

    public static DepotDispatchResult dispatchNowDetailed(class_3218 level, class_2338 depotPos, RailwayLine line,
                                                          TrainDepotBlockEntity inventory, boolean consumeItems) {
        return dispatch(level, depotPos, line, inventory, DepotDispatchConfig.saved(inventory), consumeItems,
                ControlMode.ROUTE_AUTOMATIC).result();
    }

    public static DepotDispatchResult dispatchConfigured(class_3218 level, class_2338 depotPos, RailwayLine line,
                                                         TrainDepotBlockEntity inventory, DepotDispatchConfig config,
                                                         boolean consumeItems, ControlMode controlMode) {
        return dispatch(level, depotPos, line, inventory, config, consumeItems, controlMode).result();
    }

    public static DispatchOutcome dispatchConfiguredOutcome(class_3218 level, class_2338 depotPos, RailwayLine line,
                                                            TrainDepotBlockEntity inventory, DepotDispatchConfig config,
                                                            boolean consumeItems, ControlMode controlMode) {
        return dispatch(level, depotPos, line, inventory, config, consumeItems, controlMode);
    }

    public static void resetAutomaticTimer(long lineId) { LAST_DISPATCH_TICK.put(lineId, ticks); }

    private static DispatchOutcome dispatch(class_3218 level, class_2338 depotPos, RailwayLine line,
                                            TrainDepotBlockEntity inventory, DepotDispatchConfig config, boolean consumeItems,
                                            ControlMode controlMode) {
        if(config.template().cars().isEmpty())return DispatchOutcome.failure(DepotDispatchResult.EMPTY_TEMPLATE);
        if(controlMode==ControlMode.ROUTE_AUTOMATIC&&line==null)return DispatchOutcome.failure(DepotDispatchResult.DIRECTION_UNRESOLVED);
        class_2338 railPos = depotPos.method_10084();
        if (!class_2241.method_9479(level, railPos)) return DispatchOutcome.failure(DepotDispatchResult.NO_RAIL);
        RailPowerService.refreshNow(level);
        if (!RailPowerService.isPowered(level, railPos)) return DispatchOutcome.failure(DepotDispatchResult.UNPOWERED);
        class_243 forward;
        List<TrackPoint> automaticPath = List.of();
        boolean loop = false;
        int loopStartIndex = 0;
        if (line != null) {
            RailwaySavedData data = RailwayDataManager.state(level);
            if (RuntimePathCache.get(line.id()).isEmpty() && !WorldLineValidator.validate(level, line, data))
                return DispatchOutcome.failure(DepotDispatchResult.DIRECTION_UNRESOLVED);
            WorldLineValidator.DispatchAccess access = WorldLineValidator.validateDispatchAccess(
                    level, depotPos, line, data);
            if (access.status() == WorldLineValidator.DispatchAccessStatus.UNPOWERED)
                return DispatchOutcome.failure(DepotDispatchResult.UNPOWERED);
            if (access.status() != WorldLineValidator.DispatchAccessStatus.READY)
                return DispatchOutcome.failure(DepotDispatchResult.DIRECTION_UNRESOLVED);
            TrackPoint start = access.path().get(0);
            TrackPoint next = access.path().get(1);
            forward = new class_243(next.x() - start.x(), next.y() - start.y(), next.z() - start.z()).method_1029();
            ArrayList<TrackPoint> combined = new ArrayList<>(access.path());
            List<TrackPoint> linePath = RuntimePathCache.get(line.id());
            if (!combined.isEmpty() && !linePath.isEmpty() && combined.getLast().equals(linePath.getFirst()))
                combined.removeLast();
            loopStartIndex = combined.size();
            combined.addAll(linePath);
            automaticPath = List.copyOf(combined);
            loop = LineLoopRules.isLoop(line.nodeIds(), id -> {
                RailwayDevice device = data.device(id);
                return device == null ? null : device.type();
            });
        } else {
            class_2768 railShape = level.method_8320(railPos).method_11654(class_2443.field_11369);
            var exits = class_1688.method_22864(railShape);
            boolean firstHasNode = reachesNode(level, railPos, exits.getFirst());
            boolean secondHasNode = reachesNode(level, railPos, exits.getSecond());
            int frontIndex = DepotDirectionRules.frontIndex(firstHasNode, secondHasNode);
            if (frontIndex < 0) return DispatchOutcome.failure(DepotDispatchResult.DIRECTION_UNRESOLVED);
            class_2382 exit = frontIndex == 0 ? exits.getFirst() : exits.getSecond();
            forward = new class_243(exit.method_10263(), exit.method_10264(), exit.method_10260()).method_1029();
        }
        List<class_1263> containers = connectedContainers(level, depotPos, inventory);
        if (consumeItems && (!has(containers, ModItems.LOCOMOTIVE, 1)
                || !has(containers, ModItems.PASSENGER_CAR,
                (int) config.template().cars().stream().filter(type -> type == CarType.PASSENGER).count())
                || !has(containers, ModItems.CARGO_CAR,
                (int) config.template().cars().stream().filter(type -> type == CarType.CARGO).count()))) {
            return DispatchOutcome.failure(DepotDispatchResult.MISSING_VEHICLE_ITEMS);
        }

        UUID trainId = UUID.randomUUID();
        class_243 center = class_243.method_24953(railPos);
        List<class_1297> spawned = new ArrayList<>();
        LocomotiveEntity locomotive = ModEntities.LOCOMOTIVE.method_5883(level, class_3730.field_16461);
        if (locomotive == null) return DispatchOutcome.failure(DepotDispatchResult.SPAWN_FAILED);
        long lineId=controlMode==ControlMode.ROUTE_AUTOMATIC&&line!=null?line.id():0L;
        locomotive.trainLink().assign(trainId, locomotive.method_5667(), 0, lineId);
        locomotive.trainLink().setDepotGenerated(true);
        locomotive.trainLink().setControlMode(controlMode);
        TrainClass trainClass = config.effectiveClass();
        locomotive.trainLink().setTrainClass(trainClass);
        locomotive.trainLink().setConfiguredSpeedLimitKmh(config.speedLimitKmh(trainClass));
        class_2350 formationForward=FormationDirection.fromPositions(center.field_1352+forward.field_1352,center.field_1350+forward.field_1350,
                center.field_1352,center.field_1350).orElse(class_2350.field_11043);
        locomotive.trainLink().setFormationForward(formationForward);
        locomotive.trainLink().setAutomaticRunning(controlMode==ControlMode.ROUTE_AUTOMATIC);
        locomotive.method_33574(center);
        float yaw = (float) Math.toDegrees(Math.atan2(-forward.field_1352, forward.field_1350));
        locomotive.method_36456(yaw);
        spawned.add(locomotive);
        for (int index = 0; index < config.template().cars().size(); index++) {
            CarType carType = config.template().cars().get(index);
            class_1297 car = carType == CarType.CARGO
                    ? ModEntities.CARGO_CAR.method_5883(level, class_3730.field_16461)
                    : ModEntities.PASSENGER_CAR.method_5883(level, class_3730.field_16461);
            if (!(car instanceof LinkedTrainCar linked)) return DispatchOutcome.failure(DepotDispatchResult.SPAWN_FAILED);
            if (car instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
            if (car instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            linked.trainLink().assign(trainId, locomotive.method_5667(), index + 1, lineId);
            linked.trainLink().setDepotGenerated(true);
            linked.trainLink().setControlMode(controlMode);
            linked.trainLink().setTrainClass(trainClass);
            linked.trainLink().setConfiguredSpeedLimitKmh(config.speedLimitKmh(trainClass));
            linked.trainLink().setFormationForward(formationForward);
            car.method_33574(center.method_1020(forward.method_1021((index + 1) * 1.25D)));
            car.method_36456(yaw);
            spawned.add(car);
        }
        for (class_1297 entity : spawned) {
            class_2338 occupiedRail = class_2338.method_49638(entity.method_19538());
            var occupiedState = level.method_8320(occupiedRail);
            if (!(occupiedState.method_27852(ModBlocks.SIGNAL_RAIL) || occupiedState.method_27852(ModBlocks.SWITCH_RAIL))
                    || !level.method_17892(entity)) return DispatchOutcome.failure(DepotDispatchResult.TRACK_SPACE_INVALID);
        }
        List<class_1297> added = new ArrayList<>();
        for (class_1297 entity : spawned) {
            if (!level.method_8649(entity)) {
                added.forEach(class_1297::method_31472);
                return DispatchOutcome.failure(DepotDispatchResult.SPAWN_FAILED);
            }
            added.add(entity);
        }
        if (consumeItems) {
            take(containers, ModItems.LOCOMOTIVE, 1);
            take(containers, ModItems.PASSENGER_CAR, (int) config.template().cars().stream().filter(type -> type == CarType.PASSENGER).count());
            take(containers, ModItems.CARGO_CAR, (int) config.template().cars().stream().filter(type -> type == CarType.CARGO).count());
            containers.forEach(class_1263::method_5431);
        }
        if(controlMode==ControlMode.ROUTE_AUTOMATIC){
            RailwayDataManager.state(level).registerActiveTrain(trainId, lineId);
            TrainControllerManager.registerAutomaticPath(trainId, automaticPath, loop, loopStartIndex);
        }
        RailwaySavedData savedData = RailwayDataManager.state(level);
        savedData.ensureTrain(trainId, true, lineId,controlMode);
        RailwayDevice originDepot = savedData.find(RailwayDataManager.dimension(level),
                depotPos.method_10263(), depotPos.method_10264(), depotPos.method_10260());
        TrainRegistryService.replaceFormation(level, trainId, spawned,
                originDepot == null ? 0L : originDepot.id());
        if(controlMode==ControlMode.ROUTE_AUTOMATIC)locomotive.method_18799(forward.method_1021(SpeedRules.blocksPerTick(
                SpeedRules.actualSpeed(line.speedLimitKmh(), RailwayDataManager.state(level).classSpeedLimit(trainClass),
                        config.speedLimitKmh(trainClass)))));
        else locomotive.method_18799(class_243.field_1353);
        return new DispatchOutcome(DepotDispatchResult.SUCCESS, trainId);
    }

    public record DispatchOutcome(DepotDispatchResult result, UUID trainId) {
        public static DispatchOutcome failure(DepotDispatchResult result) {
            return new DispatchOutcome(result, null);
        }

        public boolean succeeded() {
            return result.succeeded() && trainId != null;
        }
    }

    private static boolean reachesNode(class_3218 level, class_2338 origin, class_2382 initialStep) {
        class_2338 previous = origin;
        class_2338 current = origin.method_10081(initialStep);
        for (int distance = 0; distance < WorldLineValidator.MAXIMUM_VISITED_TRACKS_PER_SEGMENT; distance++) {
            if (!level.method_22340(current)) return false;
            var state = level.method_8320(current);
            if (state.method_27852(ModBlocks.SWITCH_RAIL)) return true;
            for (class_2350 direction : class_2350.values())
                if (level.method_8320(current.method_10093(direction)).method_27852(ModBlocks.STATION_MARKER)) return true;
            if (!class_2241.method_9479(level, current) || !state.method_28498(class_2443.field_11369)) return false;
            var exits = class_1688.method_22864(state.method_11654(class_2443.field_11369));
            class_2338 first = current.method_10081(exits.getFirst());
            class_2338 second = current.method_10081(exits.getSecond());
            class_2338 next = first.equals(previous) ? second : first;
            previous = current;
            current = next;
        }
        return false;
    }

    private static List<class_1263> connectedContainers(class_3218 level, class_2338 pos, TrainDepotBlockEntity depot) {
        ArrayList<class_1263> result = new ArrayList<>(); result.add(depot);
        for (class_2350 direction : class_2350.values())
            if (level.method_8321(pos.method_10093(direction)) instanceof class_1263 container) result.add(container);
        return result;
    }

    private static boolean has(List<class_1263> containers, class_1792 item, int amount) {
        if (amount <= 0) return true; int found = 0;
        for (class_1263 container : containers) for (int slot=0;slot<container.method_5439();slot++)
            if (container.method_5438(slot).method_31574(item) && (found += container.method_5438(slot).method_7947()) >= amount) return true;
        return false;
    }

    private static void take(List<class_1263> containers, class_1792 item, int amount) {
        for (class_1263 container : containers) for (int slot=0;slot<container.method_5439()&&amount>0;slot++) {
            class_1799 stack=container.method_5438(slot); if(!stack.method_31574(item))continue;
            int moved=Math.min(amount,stack.method_7947());stack.method_7934(moved);amount-=moved;container.method_5447(slot,stack);
        }
    }

    private static int find(TrainDepotBlockEntity inventory, class_1792 item, int start) {
        for (int slot = start; slot < inventory.method_5439(); slot++) if (inventory.method_5438(slot).method_31574(item)) return slot;
        return -1;
    }

    private static List<Integer> reserveTemplate(TrainDepotBlockEntity inventory) {
        int[] reserved = new int[inventory.method_5439()];
        ArrayList<Integer> slots = new ArrayList<>();
        for (CarType type : inventory.template().cars()) {
            class_1792 required = type == CarType.CARGO ? ModItems.CARGO_CAR : ModItems.PASSENGER_CAR;
            int selected = -1;
            for (int slot = 0; slot < inventory.method_5439(); slot++) {
                if (inventory.method_5438(slot).method_31574(required) && inventory.method_5438(slot).method_7947() > reserved[slot]) {
                    selected = slot;
                    break;
                }
            }
            if (selected < 0) return null;
            reserved[selected]++;
            slots.add(selected);
        }
        return slots;
    }

    public static void clear() { LAST_DISPATCH_TICK.clear(); ticks = 0; }
}
