package cn.quit5700.fabrictrain;

import cn.quit5700.fabrictrain.client.FormationScreen;
import cn.quit5700.fabrictrain.network.FormationNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

public final class FormationClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(FormationNetworking.OpenPayload.ID, (payload, context) ->
                class_310.method_1551().execute(() ->
                        class_310.method_1551().method_1507(new FormationScreen(payload))));
    }
}
