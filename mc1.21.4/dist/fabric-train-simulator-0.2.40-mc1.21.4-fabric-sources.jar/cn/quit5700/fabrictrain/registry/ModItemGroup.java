package cn.quit5700.fabrictrain.registry;

import cn.quit5700.fabrictrain.FabricTrainMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class ModItemGroup {
    public static final class_1761 TRAINS = class_2378.method_10230(
            class_7923.field_44687,
            FabricTrainMod.id("trains"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.fabric_train_simulator.trains"))
                    .method_47320(() -> new class_1799(ModItems.LOCOMOTIVE))
                    .method_47317((context, entries) -> {
                        entries.method_45421(ModItems.SIGNAL_RAIL);
                        entries.method_45421(ModItems.SWITCH_RAIL);
                        entries.method_45421(ModItems.POWER_GENERATOR);
                        entries.method_45421(ModItems.TRAIN_DEPOT);
                        entries.method_45421(ModItems.STATION_MARKER);
                        entries.method_45421(ModItems.LOCOMOTIVE);
                        entries.method_45421(ModItems.PASSENGER_CAR);
                        entries.method_45421(ModItems.CARGO_CAR);
                        entries.method_45421(ModItems.LINE_SETTER);
                        entries.method_45421(ModItems.TRAIN_CONNECTOR);
                    })
                    .method_47324()
    );

    private ModItemGroup() {
    }

    public static void initialize() {
    }
}
