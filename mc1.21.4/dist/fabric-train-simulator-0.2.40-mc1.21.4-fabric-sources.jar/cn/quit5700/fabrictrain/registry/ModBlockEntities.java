package cn.quit5700.fabrictrain.registry;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.block.entity.PowerGeneratorBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ModBlockEntities {
    public static final class_2591<TrainDepotBlockEntity> TRAIN_DEPOT = class_2378.method_10230(
            class_7923.field_41181,
            FabricTrainMod.id("train_depot"),
            FabricBlockEntityTypeBuilder.create(TrainDepotBlockEntity::new, ModBlocks.TRAIN_DEPOT).build());
    public static final class_2591<PowerGeneratorBlockEntity> POWER_GENERATOR = class_2378.method_10230(
            class_7923.field_41181,
            FabricTrainMod.id("power_generator"),
            FabricBlockEntityTypeBuilder.create(PowerGeneratorBlockEntity::new, ModBlocks.POWER_GENERATOR).build());

    private ModBlockEntities() {}
    public static void initialize() {}
}
