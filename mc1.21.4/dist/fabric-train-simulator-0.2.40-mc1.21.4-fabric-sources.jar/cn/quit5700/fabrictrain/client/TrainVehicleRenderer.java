package cn.quit5700.fabrictrain.client;

import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_9992;

/**
 * Keeps vanilla minecart positioning and rail rotation while suppressing only
 * the vanilla minecart shell. The entity display block remains visible.
 */
public final class TrainVehicleRenderer extends class_9992 {
    public TrainVehicleRenderer(class_5617.class_5618 context, class_5601 layer) {
        super(context, layer);
        field_4747.method_63512().field_3665 = false;
    }
}
