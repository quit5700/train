package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.item.TrainConnectorItem;
import cn.quit5700.fabrictrain.network.FormationNetworking;
import cn.quit5700.fabrictrain.registry.ModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class ConnectorInteractionService {
    private ConnectorInteractionService() {}

    public static class_1269 rightClick(class_1657 player, class_1268 hand, class_1297 entity) {
        if (!player.method_5998(hand).method_31574(ModItems.TRAIN_CONNECTOR)) return class_1269.field_5811;
        if (entity.method_37908().method_8608()) return class_1269.field_5812;
        if (player.method_5715()) {
            FormationNetworking.open((class_3222) player, entity);
        }
        return class_1269.field_5812;
    }

    public static class_1269 attack(class_1657 player, class_1268 hand, class_1297 entity) {
        if (!player.method_5998(hand).method_31574(ModItems.TRAIN_CONNECTOR)
                || !(entity instanceof LinkedTrainCar)) return class_1269.field_5811;
        if (entity.method_37908().method_8608()) return class_1269.field_5812;
        class_3222 serverPlayer = (class_3222) player;
        var stack = player.method_5998(hand);
        var selectedId = TrainConnectorItem.selected(serverPlayer);
        if (selectedId == null) {
            TrainConnectorItem.select(serverPlayer, entity.method_5667(), stack);
            player.method_7353(class_2561.method_43471("message.fabric_train_simulator.connector.selected"), false);
            return class_1269.field_5812;
        }
        class_1297 selected = ((class_3218) entity.method_37908()).method_14190(selectedId);
        if (selected == null) {
            TrainConnectorItem.clear(serverPlayer, stack);
            player.method_7353(class_2561.method_43471("message.fabric_train_simulator.connector.missing"), false);
            return class_1269.field_5812;
        }
        TrainFormationService.PairResult result = TrainFormationService.operatePair(selected, entity);
        TrainConnectorItem.clear(serverPlayer, stack);
        String message = switch (result) {
            case CONNECTED -> "message.fabric_train_simulator.connector.connected";
            case DISCONNECTED -> "message.fabric_train_simulator.connector.detached";
            case CANCELLED -> "message.fabric_train_simulator.connector.cancelled";
            case NOT_ADJACENT -> "message.fabric_train_simulator.connector.not_adjacent";
            case TOO_FAR -> "message.fabric_train_simulator.connector.too_far";
            case TOO_LONG -> "message.fabric_train_simulator.connector.too_long";
            case TWO_LOCOMOTIVES -> "message.fabric_train_simulator.connector.two_locomotives";
            case MIXED_ORIGIN -> "message.fabric_train_simulator.connector.mixed_origin";
            case NO_CONTINUOUS_TRACK -> "message.fabric_train_simulator.connector.no_continuous_track";
            case FAILED -> "message.fabric_train_simulator.connector.failed";
        };
        player.method_7353(class_2561.method_43471(message), false);
        return class_1269.field_5812;
    }
}
