package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.registry.ModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;

public final class DeviceInteractionService {
    private DeviceInteractionService() {}

    public static class_1269 interact(class_1657 player, class_1937 level, class_1268 hand, class_3965 hit) {
        if (hand != class_1268.field_5808 || player.method_5998(hand).method_31574(ModItems.LINE_SETTER)) {
            return class_1269.field_5811;
        }
        var state = level.method_8320(hit.method_17777());
        if (!state.method_27852(ModBlocks.TRAIN_DEPOT)) return class_1269.field_5811;
        if (level.method_8608()) {
            if (DepotSettingsGesture.tryOpen(hit.method_17777())) {
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        }
        class_3218 serverLevel = (class_3218) level;
        class_3222 serverPlayer = (class_3222) player;
        RailwayDataManager.register(serverLevel, hit.method_17777(), DeviceType.DEPOT);
        if (level.method_8321(hit.method_17777()) instanceof TrainDepotBlockEntity depot) {
            if(player.method_5715())return class_1269.field_5811;
            serverPlayer.method_17355(depot);
        }
        return class_1269.field_5812;
    }
}
