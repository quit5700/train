package cn.quit5700.fabrictrain.train;

import net.minecraft.class_2382;
import net.minecraft.class_243;

public final class RailStartDirection {
    private RailStartDirection() {}

    static class_243 choose(class_2382 first, class_2382 second, class_243 facing) {
        class_243 firstDirection = horizontal(first);
        class_243 secondDirection = horizontal(second);
        return firstDirection.method_1026(facing) >= secondDirection.method_1026(facing)
                ? firstDirection : secondDirection;
    }

    private static class_243 horizontal(class_2382 step) {
        class_243 direction = new class_243(step.method_10263(), 0, step.method_10260());
        double length = direction.method_37267();
        return length < 0.0001D ? class_243.field_1353 : direction.method_1021(1.0D / length);
    }
}
