package cn.quit5700.fabrictrain.train;

import java.util.Optional;
import net.minecraft.class_2350;

public final class FormationDirection {
    private FormationDirection() {}

    public static Optional<class_2350> fromPositions(double locomotiveX, double locomotiveZ,
                                                    double carriageX, double carriageZ) {
        double x = locomotiveX - carriageX;
        double z = locomotiveZ - carriageZ;
        if (x * x + z * z < 0.000001D) return Optional.empty();
        if (Math.abs(x) >= Math.abs(z)) return Optional.of(x >= 0 ? class_2350.field_11034 : class_2350.field_11039);
        return Optional.of(z >= 0 ? class_2350.field_11035 : class_2350.field_11043);
    }
}
