package cn.quit5700.fabrictrain.train;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_1799;

public record OfflineCarState(CarType type, long destinationStationId, List<class_1799> items) {
    public static final Codec<OfflineCarState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.xmap(CarType::valueOf, CarType::name).fieldOf("type").forGetter(OfflineCarState::type),
            Codec.LONG.optionalFieldOf("destination_station_id", 0L).forGetter(OfflineCarState::destinationStationId),
            class_1799.field_24671.listOf().optionalFieldOf("items", List.of()).forGetter(OfflineCarState::items)
    ).apply(instance, OfflineCarState::new));

    public OfflineCarState {
        destinationStationId = Math.max(0L, destinationStationId);
        items = items.stream().map(class_1799::method_7972).toList();
    }
}
