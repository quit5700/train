package cn.quit5700.fabrictrain.train;

import net.minecraft.class_243;

public final class FormationGeometry {
    private static final double CONTACT_DISTANCE_SQUARED = 2.0D;
    private FormationGeometry() {}
    public static boolean isContact(double distanceSquared) { return distanceSquared <= CONTACT_DISTANCE_SQUARED; }
    public static class_243 anchor(class_243 leader, class_243 follower, double spacing) {
        class_243 offset = follower.method_1020(leader);
        if (offset.method_37268() < 0.0001D) offset = new class_243(0, 0, 1);
        class_243 horizontal = new class_243(offset.field_1352, 0, offset.field_1350).method_1029().method_1021(spacing);
        return new class_243(leader.field_1352 + horizontal.field_1352, leader.field_1351, leader.field_1350 + horizontal.field_1350);
    }
}
