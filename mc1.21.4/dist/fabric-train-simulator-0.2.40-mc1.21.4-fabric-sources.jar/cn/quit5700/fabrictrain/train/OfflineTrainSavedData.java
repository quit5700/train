package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_4284;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

public final class OfflineTrainSavedData extends class_18 {
    public static final Codec<OfflineTrainSavedData> CODEC = OfflineTrainState.CODEC.listOf()
            .optionalFieldOf("trains", List.of()).codec()
            .xmap(OfflineTrainSavedData::new, data -> List.copyOf(data.trains.values()));
    public static final String DATA_ID = FabricTrainMod.MOD_ID + "_offline_trains";
    public static final class_18.class_8645<OfflineTrainSavedData> TYPE = new class_18.class_8645<>(
            OfflineTrainSavedData::new, OfflineTrainSavedData::load, class_4284.field_19212);

    private final Map<UUID, OfflineTrainState> trains = new LinkedHashMap<>();
    public OfflineTrainSavedData() {}
    private OfflineTrainSavedData(List<OfflineTrainState> values) {
        values.forEach(value -> trains.put(value.trainId(), value));
    }
    public synchronized void put(OfflineTrainState state) { trains.put(state.trainId(), state); method_80(); }
    public synchronized void remove(UUID trainId) { if (trains.remove(trainId) != null) method_80(); }
    public synchronized List<OfflineTrainState> trains() { return List.copyOf(trains.values()); }
    public synchronized OfflineTrainState get(UUID trainId) { return trains.get(trainId); }

    private static OfflineTrainSavedData load(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.parse(class_6903.method_46632(class_2509.field_11560, registries), tag)
                .result().orElseGet(OfflineTrainSavedData::new);
    }

    @Override public class_2487 method_75(class_2487 tag, class_7225.class_7874 registries) {
        return CODEC.encodeStart(class_6903.method_46632(class_2509.field_11560, registries), this)
                .result().filter(class_2487.class::isInstance).map(class_2487.class::cast).orElse(tag);
    }
}
