package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_3218;

public final class RailFormationPlacer {
    private static final double SPACING = FormationSpacing.BLOCKS;
    private RailFormationPlacer() {}

    public static boolean place(class_3218 level, List<class_1297> ordered, class_1297 firstSelected, class_1297 secondSelected) {
        if (ordered.isEmpty() || !(ordered.getFirst() instanceof class_1688 leader)
                || !(firstSelected instanceof class_1688 firstCart)
                || !(secondSelected instanceof class_1688 secondCart)) return false;
        class_2338 firstRail = firstCart.method_62825();
        class_2338 secondRail = secondCart.method_62825();
        if (!sameRailNetwork(level, firstRail, secondRail, 128)) return false;
        class_2338 start = leader.method_62825();
        List<class_243> path = backwardPath(level, leader, start, ordered.size() * SPACING + 2.0D);
        if (path.isEmpty()) return false;
        ArrayList<class_243> targets = new ArrayList<>();
        targets.add(leader.method_19538());
        for (int index = 1; index < ordered.size(); index++) {
            class_243 target = sample(path, index * SPACING);
            if (target == null) return false;
            targets.add(target);
        }
        for (int index = 0; index < ordered.size(); index++) {
            class_1297 entity = ordered.get(index);
            if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
            if (entity instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            entity.method_18799(class_243.field_1353);
            if (index > 0) entity.method_33574(targets.get(index));
            entity.method_43391(entity.method_23317(), entity.method_23318(), entity.method_23321());
        }
        return true;
    }

    static class_243 sample(List<class_243> path, double distance) {
        if (path.isEmpty()) return null;
        double walked = 0;
        for (int i = 1; i < path.size(); i++) {
            class_243 from = path.get(i - 1);
            class_243 to = path.get(i);
            double segment = from.method_1022(to);
            if (segment > 0 && walked + segment >= distance) {
                return from.method_35590(to, (distance - walked) / segment);
            }
            walked += segment;
        }
        return null;
    }

    private static List<class_243> backwardPath(class_3218 level, class_1688 leader, class_2338 start, double needed) {
        if (!class_2241.method_9479(level, start)) return List.of();
        ArrayList<class_243> points = new ArrayList<>();
        points.add(leader.method_19538());
        class_243 facing = facing(leader);
        class_2338 previous = null;
        class_2338 current = start;
        Set<class_2338> visited = new HashSet<>();
        double length = 0;
        for (int step = 0; step < 256 && length < needed; step++) {
            if (!visited.add(current)) break;
            var state = level.method_8320(current);
            if (!state.method_28498(class_2443.field_11369)) break;
            var exits = class_1688.method_22864(state.method_11654(class_2443.field_11369));
            class_2338 first = railAt(level, current.method_10081(exits.getFirst()));
            class_2338 second = railAt(level, current.method_10081(exits.getSecond()));
            class_2338 next;
            if (previous == null) {
                double firstDot = dot(exits.getFirst(), facing);
                double secondDot = dot(exits.getSecond(), facing);
                next = firstDot <= secondDot ? first : second;
            } else if (first != null && !first.equals(previous)) next = first;
            else if (second != null && !second.equals(previous)) next = second;
            else break;
            if (next == null) break;
            class_243 point = class_243.method_24955(next).method_1031(0, 0.1D, 0);
            length += points.getLast().method_1022(point);
            points.add(point);
            previous = current;
            current = next;
        }
        return points;
    }

    private static boolean sameRailNetwork(class_3218 level, class_2338 start, class_2338 target, int budget) {
        start = railAt(level, start);
        target = railAt(level, target);
        if (start == null || target == null) return false;
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        HashSet<class_2338> seen = new HashSet<>();
        queue.add(start);
        while (!queue.isEmpty() && budget-- > 0) {
            class_2338 pos = queue.removeFirst();
            if (!seen.add(pos)) continue;
            if (pos.equals(target)) return true;
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (Math.abs(dx) + Math.abs(dz) != 1 || Math.abs(dy) > 1) continue;
                class_2338 candidate = pos.method_10069(dx, dy, dz);
                if (class_2241.method_9479(level, candidate) && !seen.contains(candidate)) queue.add(candidate);
            }
        }
        return false;
    }

    private static class_2338 railAt(class_3218 level, class_2338 pos) {
        if (class_2241.method_9479(level, pos)) return pos;
        if (class_2241.method_9479(level, pos.method_10074())) return pos.method_10074();
        if (class_2241.method_9479(level, pos.method_10084())) return pos.method_10084();
        return null;
    }

    private static class_243 facing(class_1297 entity) {
        double radians = Math.toRadians(entity.method_36454());
        return new class_243(-Math.sin(radians), 0, Math.cos(radians));
    }

    private static double dot(class_2382 step, class_243 facing) {
        return step.method_10263() * facing.field_1352 + step.method_10260() * facing.field_1350;
    }
}
