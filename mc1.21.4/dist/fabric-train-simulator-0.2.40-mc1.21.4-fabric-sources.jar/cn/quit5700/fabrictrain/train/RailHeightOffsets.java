package cn.quit5700.fabrictrain.train;

import java.util.List;
import net.minecraft.class_2338;

public final class RailHeightOffsets {
    private RailHeightOffsets() {}

    public static List<class_2338> candidates(class_2338 position) {
        return List.of(position, position.method_10074(), position.method_10084());
    }
}
