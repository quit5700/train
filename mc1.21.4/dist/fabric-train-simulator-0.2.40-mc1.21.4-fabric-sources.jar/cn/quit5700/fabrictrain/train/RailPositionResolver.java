package cn.quit5700.fabrictrain.train;

import java.util.List;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * Resolves the actual rail under a logically moved train.  A slope interpolation can place the
 * entity block position one block below the upper rail, so vanilla's current/below lookup is only
 * a recovery hint and must also consider the block above.
 */
public final class RailPositionResolver {
    private RailPositionResolver() {}

    public static List<class_2338> candidates(class_2338 origin) {
        return List.of(origin, origin.method_10074(), origin.method_10084());
    }

    public static class_2338 resolve(class_3218 level, class_1688 minecart) {
        if (level == null || minecart == null) return null;
        return resolve(level, minecart.method_62825());
    }

    public static class_2338 resolve(class_3218 level, class_2338 origin) {
        if (level == null || origin == null) return null;
        return candidates(origin).stream().filter(candidate -> class_2241.method_9479(level, candidate))
                .findFirst().orElse(null);
    }
}
