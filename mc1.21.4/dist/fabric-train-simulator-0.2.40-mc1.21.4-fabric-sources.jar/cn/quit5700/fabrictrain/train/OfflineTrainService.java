package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.cargo.CargoLedgerService;
import cn.quit5700.fabrictrain.cargo.CargoUnloadRules;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.power.PowerSectionCache;
import cn.quit5700.fabrictrain.registry.ModEntities;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.depot.DepotRecoveryService;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.route.TrackPoint;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.server.MinecraftServer;
import java.util.*;

/** Simulates depot-generated automatic trains while their current route chunk is unloaded. */
public final class OfflineTrainService {
    private static final Set<UUID> STARTUP_RECOVERY = new HashSet<>();
    private OfflineTrainService() {}

    public static OfflineTrainSavedData state(MinecraftServer server) {
        return server.method_30002().method_17983().method_17924(OfflineTrainSavedData.TYPE, OfflineTrainSavedData.DATA_ID);
    }

    public static boolean transition(class_3218 level, LocomotiveEntity locomotive, List<class_1297> formation,
                                     List<TrackPoint> path, boolean loop, int loopStartIndex,
                                     int pathIndex, double segmentProgress, double speed) {
        if (locomotive.trainLink().controlMode() != ControlMode.ROUTE_AUTOMATIC || path.size() < 2) return false;
        ArrayList<OfflineCarState> cars = new ArrayList<>();
        formation.stream().sorted(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()))
                .filter(entity -> !(entity instanceof LocomotiveEntity)).forEach(entity -> {
                    if (entity instanceof CargoCarEntity cargo) {
                        ArrayList<class_1799> items = new ArrayList<>();
                        for (int slot = 0; slot < cargo.method_5439(); slot++)
                            if (!cargo.method_5438(slot).method_7960()) items.add(cargo.method_5438(slot).method_7972());
                        cars.add(new OfflineCarState(CarType.CARGO, cargo.destinationStationId(), items));
                    } else cars.add(new OfflineCarState(CarType.PASSENGER, 0L, List.of()));
                });
        OfflineTrainState offline = new OfflineTrainState(locomotive.trainLink().trainId(),
                locomotive.trainLink().lineId(), locomotive.trainLink().trainClass(),
                locomotive.trainLink().configuredSpeedLimitKmh(), pathIndex, segmentProgress,
                Math.max(0D, speed), loop, loopStartIndex, locomotive.trainLink().nextNodeIndex(),
                locomotive.trainLink().lastDeviceId(), locomotive.trainLink().destinationStationId(),
                0L, level.method_8510(), path, cars);
        state(level.method_8503()).put(offline);
        RailwaySavedData data = RailwayDataManager.state(level);
        data.updateTrainPresence(offline.trainId(), TrainPresence.OFFLINE);
        data.registerActiveTrain(offline.trainId(), offline.lineId());
        TrainControllerManager.beginOfflineRemoval(offline.trainId());
        formation.forEach(entity -> { entity.method_5772(); entity.method_31472(); });
        TrainControllerManager.finishOfflineRemoval(level, offline.trainId());
        return true;
    }

    public static void beginServerRecovery(MinecraftServer server) {
        STARTUP_RECOVERY.clear();
    }

    public static void tick(MinecraftServer server) {
        if (server.method_3780() % 20 != 0) return;
        OfflineTrainSavedData saved = state(server);
        for (OfflineTrainState original : saved.trains()) {
            class_3218 level = levelFor(server, original.lineId());
            if (level == null) continue;
            if (STARTUP_RECOVERY.contains(original.trainId())) {
                if (recoverAfterRestart(level, original)) {
                    STARTUP_RECOVERY.remove(original.trainId());
                    saved.remove(original.trainId());
                    TrainControllerManager.retireTrainResources(level, original.trainId());
                }
                continue;
            }
            OfflineTrainState advanced = advance(level, original);
            if (advanced == null) {
                saved.remove(original.trainId());
                TrainControllerManager.retireTrainResources(level, original.trainId());
                continue;
            }
            saved.put(advanced);
            if (currentChunkLoaded(level, advanced)) materialize(level, advanced, saved);
        }
    }

    private static boolean recoverAfterRestart(class_3218 level, OfflineTrainState state) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayDevice depotDevice = data.device(data.recoveryDepotId(state.lineId()));
        if (depotDevice == null || depotDevice.type() != DeviceType.DEPOT
                || !depotDevice.dimension().equals(RailwayDataManager.dimension(level))) return false;
        class_2338 depotPos = new class_2338(depotDevice.x(), depotDevice.y(), depotDevice.z());
        if (!level.method_22340(depotPos) || !(level.method_8321(depotPos) instanceof TrainDepotBlockEntity depot))
            return false;
        ArrayList<class_1799> returning = new ArrayList<>();
        returning.add(new class_1799(ModItems.LOCOMOTIVE));
        for (OfflineCarState car : state.cars()) {
            car.items().stream().filter(stack -> !stack.method_7960()).map(class_1799::method_7972).forEach(returning::add);
            returning.add(new class_1799(car.type() == CarType.CARGO ? ModItems.CARGO_CAR : ModItems.PASSENGER_CAR));
        }
        return DepotRecoveryService.recoverItems(level, depot, returning);
    }

    public static void clearRuntime() { STARTUP_RECOVERY.clear(); }

    private static OfflineTrainState advance(class_3218 level, OfflineTrainState state) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(state.lineId());
        if (line == null) return null;
        if (line.status() == LineStatus.CLOSED || line.status() == LineStatus.MAINTENANCE
                || line.status() == LineStatus.NEEDS_VALIDATION)
            return copy(state, state.pathIndex(), state.segmentProgress(), state.nextNodeIndex(),
                    state.lastDeviceId(), 0L, level.method_8510(), state.cars());
        long now = level.method_8510();
        long elapsed = Math.max(0L, now - state.lastGameTime());
        if (state.dwellUntilGameTime() == Long.MAX_VALUE && line.status() == LineStatus.RUNNING)
            return copy(state, state.pathIndex(), state.segmentProgress(), state.nextNodeIndex(),
                    state.lastDeviceId(), 0L, now, state.cars());
        if (state.dwellUntilGameTime() == Long.MAX_VALUE)
            return copy(state, state.pathIndex(), state.segmentProgress(), state.nextNodeIndex(),
                    state.lastDeviceId(), Long.MAX_VALUE, now, state.cars());
        if (now < state.dwellUntilGameTime()) return copy(state, state.pathIndex(), state.segmentProgress(),
                state.nextNodeIndex(), state.lastDeviceId(), state.dwellUntilGameTime(), now, state.cars());
        int section = Math.max(0, state.pathIndex() - state.loopStartIndex()) / PowerSectionCache.SECTION_LENGTH;
        if (PowerSectionCache.sectionStatus(state.lineId(), section) == cn.quit5700.fabrictrain.power.PowerSectionStatus.UNPOWERED)
            return copy(state, state.pathIndex(), state.segmentProgress(), state.nextNodeIndex(),
                    state.lastDeviceId(), 0L, now, state.cars());
        double remaining = state.speed() * elapsed;
        int pathIndex = state.pathIndex();
        double progress = state.segmentProgress();
        int nextNode = state.nextNodeIndex();
        long lastDevice = progress > 0.01D ? 0L : state.lastDeviceId();
        ArrayList<OfflineCarState> cars = new ArrayList<>(state.cars());
        int budget = Math.max(4, line.nodeIds().size() + 1);
        while (remaining > 0.000001D && budget-- > 0) {
            int expected = Math.min(nextNode, line.nodeIds().size() - 1);
            RailwayDevice device = data.device(line.nodeIds().get(expected));
            int target = device == null ? -1 : nextRouteIndex(state.path(), line, expected, device,
                    pathIndex, state.loop(), state.loopStartIndex());
            double toTarget = target < 0 ? Double.POSITIVE_INFINITY : distanceToIndex(state.path(),
                    state.loop(), state.loopStartIndex(), pathIndex, progress, target);
            if (remaining + 0.000001D < toTarget) {
                OfflineRouteMath.Position moved = OfflineRouteMath.advance(state.path(), state.loop(),
                        state.loopStartIndex(), pathIndex, progress, remaining);
                if (moved.ended() && !state.loop()) return null;
                return copy(state, moved.pathIndex(), moved.progress(), nextNode, 0L, 0L, now, cars);
            }
            if (target < 0 || !Double.isFinite(toTarget)) break;
            remaining = Math.max(0D, remaining - toTarget);
            pathIndex = target;
            progress = 0D;
            lastDevice = device.id();
            if (device.type() == DeviceType.STATION) {
                cars = unloadOfflineCargo(level, state, cars, device.id());
                long dwellUntil = line.status() == LineStatus.PAUSED ? Long.MAX_VALUE
                        : now + (long) StationDwellRules.automaticSeconds(device, state.trainClass()) * 20L;
                nextNode = nextNode(line, state.loop(), nextNode);
                return copy(state, pathIndex, 0D, nextNode, lastDevice, dwellUntil, now, cars);
            }
            if (device.type() == DeviceType.DEPOT && expected == line.nodeIds().size() - 1 && !state.loop())
                return null;
            nextNode = nextNode(line, state.loop(), nextNode);
        }
        OfflineRouteMath.Position moved = OfflineRouteMath.advance(state.path(), state.loop(),
                state.loopStartIndex(), pathIndex, progress, remaining);
        return moved.ended() && !state.loop() ? null : copy(state, moved.pathIndex(), moved.progress(),
                nextNode, lastDevice, 0L, now, cars);
    }

    private static ArrayList<OfflineCarState> unloadOfflineCargo(class_3218 level, OfflineTrainState train,
                                                                  List<OfflineCarState> cars, long stationId) {
        ArrayList<OfflineCarState> result = new ArrayList<>();
        for (int index = 0; index < cars.size(); index++) {
            OfflineCarState car = cars.get(index);
            if (car.type() != CarType.CARGO || !CargoUnloadRules.shouldUnloadAt(stationId,
                    car.destinationStationId(), train.destinationStationId())) { result.add(car); continue; }
            CargoLedgerService.depositArrived(level, UUID.nameUUIDFromBytes(
                    (train.trainId() + ":" + index).getBytes(java.nio.charset.StandardCharsets.UTF_8)),
                    stationId, car.items());
            result.add(new OfflineCarState(CarType.CARGO, car.destinationStationId(), List.of()));
        }
        return result;
    }

    private static int nextRouteIndex(List<TrackPoint> path, RailwayLine line, int nodeIndex, RailwayDevice device,
                                      int currentIndex, boolean loop, int loopStart) {
        StopTrack stop = line.stationStopTrack(nodeIndex);
        int x = stop != null ? stop.x() : device.x();
        int y = stop != null ? stop.y() : device.type() == DeviceType.DEPOT ? device.y() + 1 : device.y();
        int z = stop != null ? stop.z() : device.z();
        for (int index = Math.max(0, currentIndex); index < path.size(); index++) {
            TrackPoint point = path.get(index);
            if (point.x() == x && point.y() == y && point.z() == z) return index;
        }
        if (loop) for (int index = Math.clamp(loopStart, 0, path.size() - 1); index < currentIndex; index++) {
            TrackPoint point = path.get(index);
            if (point.x() == x && point.y() == y && point.z() == z) return index;
        }
        return -1;
    }

    private static double distanceToIndex(List<TrackPoint> path, boolean loop, int loopStart,
                                          int currentIndex, double progress, int targetIndex) {
        if (targetIndex == currentIndex && progress < 0.01D) return 0D;
        double distance = 0D;
        int index = currentIndex;
        double used = progress;
        int budget = path.size() + 1;
        while (budget-- > 0) {
            int next = OfflineRouteMath.nextIndex(path, loop, loopStart, index);
            if (next < 0) return Double.POSITIVE_INFINITY;
            distance += Math.max(0D, OfflineRouteMath.distance(path.get(index), path.get(next)) - used);
            index = next; used = 0D;
            if (index == targetIndex) return distance;
        }
        return Double.POSITIVE_INFINITY;
    }

    private static int nextNode(RailwayLine line, boolean loop, int current) {
        int next = current + 1;
        return next >= line.nodeIds().size() ? (loop ? 1 : line.nodeIds().size() - 1) : next;
    }

    private static boolean currentChunkLoaded(class_3218 level, OfflineTrainState state) {
        int current = Math.clamp(state.pathIndex(), 0, state.path().size() - 1);
        int next = OfflineRouteMath.nextIndex(state.path(), state.loop(), state.loopStartIndex(), current);
        if (next < 0) return false;
        TrackPoint currentPoint = state.path().get(current), nextPoint = state.path().get(next);
        return level.method_22340(new class_2338(currentPoint.x(), currentPoint.y(), currentPoint.z()))
                && level.method_22340(new class_2338(nextPoint.x(), nextPoint.y(), nextPoint.z()));
    }

    private static void materialize(class_3218 level, OfflineTrainState state, OfflineTrainSavedData saved) {
        int nextIndex = OfflineRouteMath.nextIndex(state.path(), state.loop(), state.loopStartIndex(), state.pathIndex());
        if (nextIndex < 0) return;
        TrackPoint fromPoint = state.path().get(state.pathIndex()), toPoint = state.path().get(nextIndex);
        class_243 from = class_243.method_24955(new class_2338(fromPoint.x(), fromPoint.y(), fromPoint.z())).method_1031(0, .1D, 0);
        class_243 to = class_243.method_24955(new class_2338(toPoint.x(), toPoint.y(), toPoint.z())).method_1031(0, .1D, 0);
        double length = from.method_1022(to);
        class_243 position = length < .0001D ? from : from.method_35590(to, Math.clamp(state.segmentProgress() / length, 0D, 1D));
        class_243 tangent = to.method_1020(from).method_1029();
        LocomotiveEntity locomotive = ModEntities.LOCOMOTIVE.method_5883(level, class_3730.field_16461);
        if (locomotive == null) return;
        locomotive.trainLink().assign(state.trainId(), locomotive.method_5667(), 0, state.lineId());
        applyLink(locomotive.trainLink(), state);
        locomotive.method_33574(position);
        locomotive.method_36456((float) Math.toDegrees(Math.atan2(-tangent.field_1352, tangent.field_1350)));
        ArrayList<class_1297> spawned = new ArrayList<>(); spawned.add(locomotive);
        for (int index = 0; index < state.cars().size(); index++) {
            OfflineCarState carState = state.cars().get(index);
            class_1297 entity = carState.type() == CarType.CARGO ? ModEntities.CARGO_CAR.method_5883(level,
                    class_3730.field_16461) : ModEntities.PASSENGER_CAR.method_5883(level, class_3730.field_16461);
            if (!(entity instanceof LinkedTrainCar linked)) return;
            linked.trainLink().assign(state.trainId(), locomotive.method_5667(), index + 1, state.lineId());
            applyLink(linked.trainLink(), state);
            entity.method_33574(position.method_1020(tangent.method_1021((index + 1) * FormationSpacing.BLOCKS)));
            entity.method_36456(locomotive.method_36454());
            if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
            if (entity instanceof CargoCarEntity cargo) {
                cargo.releasePlacementBrake(); cargo.setDestinationStationId(carState.destinationStationId());
                for (int slot = 0; slot < Math.min(cargo.method_5439(), carState.items().size()); slot++)
                    cargo.method_5447(slot, carState.items().get(slot).method_7972());
            }
            spawned.add(entity);
        }
        if (spawned.stream().anyMatch(entity -> !level.method_22340(entity.method_24515()))) return;
        ArrayList<class_1297> added = new ArrayList<>();
        for (class_1297 entity : spawned) {
            if (!level.method_8649(entity)) {
                TrainControllerManager.beginOfflineRemoval(state.trainId());
                added.forEach(class_1297::method_31472);
                TrainControllerManager.finishOfflineRemoval(level, state.trainId());
                return;
            }
            added.add(entity);
        }
        saved.remove(state.trainId());
        RailwayDataManager.state(level).updateTrainPresence(state.trainId(), TrainPresence.LOADED);
        TrainRegistryService.replaceFormation(level, state.trainId(), spawned);
        TrainControllerManager.restoreOfflinePath(state, locomotive);
    }

    private static void applyLink(TrainLink link, OfflineTrainState state) {
        link.setDepotGenerated(true); link.setControlMode(ControlMode.ROUTE_AUTOMATIC);
        link.setTrainClass(state.trainClass()); link.setConfiguredSpeedLimitKmh(state.configuredSpeedLimitKmh());
        link.setDestinationStationId(state.destinationStationId());
        link.updateRouteProgress(state.nextNodeIndex(), state.lastDeviceId(), 0L);
        link.setAutomaticRunning(true);
    }

    private static class_3218 levelFor(MinecraftServer server, long lineId) {
        for (class_3218 level : server.method_3738()) if (RailwayDataManager.state(level).line(lineId) != null) return level;
        return null;
    }

    private static OfflineTrainState copy(OfflineTrainState state, int index, double progress, int nextNode,
                                          long lastDevice, long dwellUntil, long now, List<OfflineCarState> cars) {
        return new OfflineTrainState(state.trainId(), state.lineId(), state.trainClass(),
                state.configuredSpeedLimitKmh(), index, progress, state.speed(), state.loop(),
                state.loopStartIndex(), nextNode, lastDevice, state.destinationStationId(), dwellUntil,
                now, state.path(), cars);
    }

}
