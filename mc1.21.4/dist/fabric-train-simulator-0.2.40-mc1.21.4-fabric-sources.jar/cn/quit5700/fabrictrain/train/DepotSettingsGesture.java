package cn.quit5700.fabrictrain.train;

import java.util.Objects;
import java.util.function.Predicate;
import net.minecraft.class_2338;

public final class DepotSettingsGesture {
    private static volatile Predicate<class_2338> clientOpener = ignored -> false;

    private DepotSettingsGesture() {}

    public static void installClientOpener(Predicate<class_2338> opener) {
        clientOpener = Objects.requireNonNull(opener, "opener");
    }

    public static boolean tryOpen(class_2338 pos) {
        return clientOpener.test(pos);
    }
}
