package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.data.RailwayDataManager;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public final class TrainDiagnosticLabel {
    private TrainDiagnosticLabel() {}

    public static class_2561 of(class_3218 level, TrainLink link) {
        var record=RailwayDataManager.state(level).ensureTrain(link.trainId(),link.depotGenerated(),
                link.lineId(),link.controlMode());
        String key=record.controlMode()==ControlMode.MANUAL
                ?"message.fabric_train_simulator.train.label.manual"
                :"message.fabric_train_simulator.train.label.route_automatic";
        return class_2561.method_43469(key,record.number(),record.trainId().toString().substring(0,8));
    }

    public static class_2561 of(class_3218 level, UUID trainId) {
        var data=RailwayDataManager.state(level);
        var record=data.trainRecord(trainId);
        if(record==null){
            for(var entity:level.method_27909())if(entity instanceof LinkedTrainCar linked
                    &&linked.trainLink().trainId().equals(trainId))return of(level,linked.trainLink());
            record=data.ensureTrain(trainId,false,0L,ControlMode.MANUAL);
        }
        String key=record.controlMode()==ControlMode.MANUAL
                ?"message.fabric_train_simulator.train.label.manual"
                :"message.fabric_train_simulator.train.label.route_automatic";
        return class_2561.method_43469(key,record.number(),record.trainId().toString().substring(0,8));
    }
}
