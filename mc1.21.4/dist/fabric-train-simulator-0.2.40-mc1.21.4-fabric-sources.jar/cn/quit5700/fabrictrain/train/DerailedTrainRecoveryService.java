package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.depot.DepotRecoveryService;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import java.util.*;
import net.minecraft.class_1264;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.registry.ModItems;

public final class DerailedTrainRecoveryService {
    private DerailedTrainRecoveryService() {}

    public static int recoverLoaded(class_3218 level, RailwayLine line, RailwaySavedData data) {
        RailwayDevice depotDevice = data.device(data.recoveryDepotId(line.id()));
        if (depotDevice == null || !depotDevice.dimension().equals(RailwayDataManager.dimension(level))) return 0;
        class_2338 depotPos = new class_2338(depotDevice.x(), depotDevice.y(), depotDevice.z());
        if (!level.method_22340(depotPos) || !(level.method_8321(depotPos) instanceof TrainDepotBlockEntity depot)) return 0;
        Map<UUID, List<class_1297>> trains = new LinkedHashMap<>();
        for (class_1297 entity : level.method_27909()) {
            if (entity instanceof LinkedTrainCar linked && linked.trainLink().lineId() == line.id()) {
                trains.computeIfAbsent(linked.trainLink().trainId(), ignored -> new ArrayList<>()).add(entity);
            }
        }
        int recovered = 0;
        for (List<class_1297> cars : trains.values()) {
            LocomotiveEntity locomotive = cars.stream().filter(LocomotiveEntity.class::isInstance)
                    .map(LocomotiveEntity.class::cast).findFirst().orElse(null);
            if (locomotive == null || isValidTrack(level.method_8320(locomotive.method_62825()))) continue;
            if (DepotRecoveryService.recover(cars, depot)) recovered++;
        }
        return recovered;
    }

    private static boolean isValidTrack(class_2680 state) {
        return state.method_27852(ModBlocks.SIGNAL_RAIL) || state.method_27852(ModBlocks.SWITCH_RAIL);
    }

    public static void dropAsItems(class_3218 level, List<class_1297> cars) {
        UUID trainId = null;
        for (class_1297 entity : cars) {
            if (entity instanceof LinkedTrainCar linked) trainId = linked.trainLink().trainId();
            entity.method_5772();
            if (entity instanceof CargoCarEntity cargo) {
                class_1264.method_5451(level, cargo.method_24515(), cargo);
                entity.method_5775(level, new class_1799(ModItems.CARGO_CAR));
            } else if (entity instanceof PassengerCarEntity) {
                entity.method_5775(level, new class_1799(ModItems.PASSENGER_CAR));
            } else if (entity instanceof LocomotiveEntity) {
                entity.method_5775(level, new class_1799(ModItems.LOCOMOTIVE));
            }
            entity.method_31472();
        }
        if (trainId != null) {
            TrainControllerManager.retireTrainResources(level, trainId);
        }
    }
}
