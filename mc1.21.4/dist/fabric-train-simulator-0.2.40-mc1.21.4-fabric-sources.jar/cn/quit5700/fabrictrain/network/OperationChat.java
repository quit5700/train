package cn.quit5700.fabrictrain.network;

import net.minecraft.class_2561;

/** Keeps operation results in their UI instead of sending chat messages. */
public final class OperationChat {
    private OperationChat() {}

    public static void suppress(class_2561 ignored) {
    }
}
