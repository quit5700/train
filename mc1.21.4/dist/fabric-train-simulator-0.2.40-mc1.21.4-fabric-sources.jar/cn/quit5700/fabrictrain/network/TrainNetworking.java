package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class TrainNetworking {
    private static final class_2960 DRIVE = FabricTrainMod.id("drive");

    private TrainNetworking() {
    }

    public static void registerServer() {
        PayloadTypeRegistry.playC2S().register(DrivePayload.ID, DrivePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(DrivePayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    if (context.player().method_5854() instanceof PassengerCarEntity
                            || context.player().method_5854() instanceof LocomotiveEntity) {
                        TrainControllerManager.drive(context.player(), context.player().method_5854(), payload.forward(), payload.brake());
                    }
                }));
    }

    public record DrivePayload(boolean forward, boolean brake) implements class_8710 {
        public static final class_9154<DrivePayload> ID = new class_9154<>(DRIVE);
        public static final class_9139<class_9129, DrivePayload> CODEC = class_8710.method_56484(
                DrivePayload::write, DrivePayload::read);

        private void write(class_9129 buffer) {
            buffer.method_52964(forward);
            buffer.method_52964(brake);
        }

        private static DrivePayload read(class_9129 buffer) {
            return new DrivePayload(buffer.readBoolean(), buffer.readBoolean());
        }

        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
