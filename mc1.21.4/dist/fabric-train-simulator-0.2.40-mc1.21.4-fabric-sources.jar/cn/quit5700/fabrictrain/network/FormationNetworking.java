package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainFormationService;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;

public final class FormationNetworking {
    private FormationNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) ->
                context.server().execute(() -> {
                    class_1297 seed = context.player().method_51469().method_8469(payload.seedEntityId());
                    if (!(seed instanceof LinkedTrainCar) || context.player().method_5858(seed) > 256.0D) return;
                    if (payload.dissolve()) TrainFormationService.dissolve(seed);
                    else TrainFormationService.reorder(seed, payload.entityIds());
                }));
    }

    public static void open(class_3222 player, class_1297 seed) {
        List<Car> cars = TrainFormationService.formation(seed).stream()
                .map(entity -> new Car(entity.method_5628(), entity.method_5864().method_5897().getString())).toList();
        ServerPlayNetworking.send(player, new OpenPayload(seed.method_5628(), cars));
    }

    public record Car(int entityId, String name) {}

    public record OpenPayload(int seedEntityId, List<Car> cars) implements class_8710 {
        public static final class_9154<OpenPayload> ID = new class_9154<>(FabricTrainMod.id("open_formation"));
        public static final class_9139<class_9129, OpenPayload> CODEC =
                class_8710.method_56484(OpenPayload::write, OpenPayload::read);
        private void write(class_9129 b) {
            b.method_10804(seedEntityId); b.method_10804(cars.size());
            for (Car car : cars) { b.method_10804(car.entityId()); b.method_10788(car.name(), 128); }
        }
        private static OpenPayload read(class_9129 b) {
            int seed = b.method_10816(), size = Math.clamp(b.method_10816(), 0, 101);
            ArrayList<Car> cars = new ArrayList<>(size);
            for (int i = 0; i < size; i++) cars.add(new Car(b.method_10816(), b.method_10800(128)));
            return new OpenPayload(seed, List.copyOf(cars));
        }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record UpdatePayload(int seedEntityId, boolean dissolve, List<Integer> entityIds)
            implements class_8710 {
        public static final class_9154<UpdatePayload> ID = new class_9154<>(FabricTrainMod.id("update_formation"));
        public static final class_9139<class_9129, UpdatePayload> CODEC =
                class_8710.method_56484(UpdatePayload::write, UpdatePayload::read);
        private void write(class_9129 b) {
            b.method_10804(seedEntityId); b.method_52964(dissolve); b.method_10804(entityIds.size());
            entityIds.forEach(b::method_10804);
        }
        private static UpdatePayload read(class_9129 b) {
            int seed = b.method_10816(); boolean dissolve = b.readBoolean();
            int size = Math.clamp(b.method_10816(), 0, 101); ArrayList<Integer> ids = new ArrayList<>(size);
            for (int i = 0; i < size; i++) ids.add(b.method_10816());
            return new UpdatePayload(seed, dissolve, List.copyOf(ids));
        }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
