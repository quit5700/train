package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.List;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;

public final class TrainClassNetworking {
    private TrainClassNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof LocomotiveEntity locomotive) || context.player().method_5858(entity) > 64.0D) return;
            boolean hasCargo = hasCargo(context.player().method_51469().method_27909(), locomotive);
            TrainClass requested = TrainClass.values()[Math.clamp(payload.trainClassOrdinal(), 0, TrainClass.values().length - 1)];
            TrainClass selected = hasCargo ? TrainClass.CARGO : requested;
            long destination=payload.destinationStationId();
            var data=cn.quit5700.fabrictrain.data.RailwayDataManager.state(context.player().method_51469());
            if(!StationSelectionService.canSelect(data,locomotive.trainLink(),destination))destination=0;
            boolean destinationChanged = locomotive.trainLink().destinationStationId() != destination;
            locomotive.trainLink().setDestinationStationId(destination);
            data.updateClassSpeedLimits(
                    payload.freightSpeedKmh(), payload.passengerSpeedKmh(), payload.expressSpeedKmh());
            for (class_1297 candidate : context.player().method_51469().method_27909()) {
                if (candidate instanceof LinkedTrainCar linked
                        && linked.trainLink().trainId().equals(locomotive.trainLink().trainId())) {
                    linked.trainLink().setTrainClass(selected);
                    linked.trainLink().setDestinationStationId(destination);
                    linked.trainLink().setConfiguredSpeedLimitKmh(data.classSpeedLimit(selected));
                    if(destinationChanged && linked instanceof CargoCarEntity cargo) cargo.setDestinationStationId(0L);
                }
            }
        }));
    }

    private static boolean hasCargo(Iterable<class_1297> entities, LocomotiveEntity locomotive) {
        for (class_1297 candidate : entities) {
            if (candidate instanceof CargoCarEntity cargo
                    && cargo.trainLink().trainId().equals(locomotive.trainLink().trainId())) return true;
        }
        return false;
    }

    public record Station(long id,String name){}
    public record OpenPayload(int entityId, int trainClassOrdinal, boolean hasCargo, double freightSpeedKmh,
                              double passengerSpeedKmh, double expressSpeedKmh,long destinationStationId,List<Station> stations) implements class_8710 {
        public static final class_9154<OpenPayload> ID = new class_9154<>(FabricTrainMod.id("open_train_class"));
        public static final class_9139<class_9129, OpenPayload> CODEC = class_8710.method_56484(OpenPayload::write, OpenPayload::read);
        private void write(class_9129 b) { b.method_10804(entityId); b.method_10804(trainClassOrdinal); b.method_52964(hasCargo); b.method_52940(freightSpeedKmh); b.method_52940(passengerSpeedKmh); b.method_52940(expressSpeedKmh);b.method_10791(destinationStationId);b.method_10804(stations.size());for(Station s:stations){b.method_10791(s.id());b.method_10788(s.name(),64);} }
        private static OpenPayload read(class_9129 b) {int entity=b.method_10816(),type=b.method_10816();boolean cargo=b.readBoolean();double freight=b.readDouble(),passenger=b.readDouble(),express=b.readDouble();long destination=b.method_10792();int size=Math.clamp(b.method_10816(),0,1000);java.util.ArrayList<Station> stations=new java.util.ArrayList<>();for(int i=0;i<size;i++)stations.add(new Station(b.method_10792(),b.method_10800(64)));return new OpenPayload(entity,type,cargo,freight,passenger,express,destination,List.copyOf(stations)); }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record UpdatePayload(int entityId, int trainClassOrdinal, double freightSpeedKmh,
                                double passengerSpeedKmh, double expressSpeedKmh,long destinationStationId) implements class_8710 {
        public static final class_9154<UpdatePayload> ID = new class_9154<>(FabricTrainMod.id("update_train_class"));
        public static final class_9139<class_9129, UpdatePayload> CODEC = class_8710.method_56484(UpdatePayload::write, UpdatePayload::read);
        private void write(class_9129 b) { b.method_10804(entityId); b.method_10804(trainClassOrdinal); b.method_52940(freightSpeedKmh); b.method_52940(passengerSpeedKmh); b.method_52940(expressSpeedKmh);b.method_10791(destinationStationId); }
        private static UpdatePayload read(class_9129 b) { return new UpdatePayload(b.method_10816(), b.method_10816(), b.readDouble(), b.readDouble(), b.readDouble(),b.method_10792()); }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
