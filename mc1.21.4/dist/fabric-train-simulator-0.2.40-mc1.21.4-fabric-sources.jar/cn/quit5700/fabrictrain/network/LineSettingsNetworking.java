package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import cn.quit5700.fabrictrain.item.LineSetterItem;
import java.util.List;
import cn.quit5700.fabrictrain.train.DerailedTrainRecoveryService;
import cn.quit5700.fabrictrain.train.TrainControllerManager;

public final class LineSettingsNetworking {
    private LineSettingsNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            RailwaySavedData data = RailwayDataManager.state(context.player().method_51469());
            RailwayLine line = data.line(payload.lineId());
            if (line == null) return;
            if (payload.delete()) {
                LineDeletionService.delete(context.server(), (net.minecraft.class_3218) context.player().method_51469(), payload.lineId());
                return;
            }
            boolean structuralChange = payload.nodeAction() >= 0;
            if (structuralChange) data.modifyLineNode(payload.lineId(), payload.nodeIndex(), payload.nodeAction());
            if (payload.editNodes()) LineSetterItem.beginEditing(context.player().method_5667(), payload.lineId());
            LineStatus status = LineStatus.values()[Math.clamp(payload.statusOrdinal(), 0, LineStatus.values().length - 1)];
            data.updateLineSettings(payload.lineId(), payload.name(), payload.intervalSeconds(), payload.speedKmh(), payload.maximumTrains(),
                    structuralChange ? LineStatus.NEEDS_VALIDATION : status);
            if (payload.refresh()) {
                RailwayLine updated = data.line(payload.lineId());
                boolean valid = WorldLineValidator.validate(context.player().method_51469(), updated, data);
                data.setLineStatus(payload.lineId(), valid ? LineStatus.RUNNING : LineStatus.NEEDS_VALIDATION);
                DerailedTrainRecoveryService.recoverLoaded(context.player().method_51469(), updated, data);
                if(valid)TrainControllerManager.startLine(context.server(),payload.lineId());
            }
        }));
    }

    public record OpenPayload(long lineId, String name, int statusOrdinal, int intervalSeconds, double speedKmh,
                              int maximumTrains, List<Long> nodeIds) implements class_8710 {
        public static final class_9154<OpenPayload> ID = new class_9154<>(FabricTrainMod.id("open_line_settings"));
        public static final class_9139<class_9129, OpenPayload> CODEC = class_8710.method_56484(OpenPayload::write, OpenPayload::read);
        private void write(class_9129 b) { b.method_10791(lineId); b.method_10788(name,64); b.method_10804(statusOrdinal); b.method_10804(intervalSeconds); b.method_52940(speedKmh); b.method_10804(maximumTrains); b.method_10804(nodeIds.size()); for (long id : nodeIds) b.method_10791(id); }
        private static OpenPayload read(class_9129 b) { long id=b.method_10792(); String name=b.method_10800(64); int status=b.method_10816(); int interval=b.method_10816(); double speed=b.readDouble(); int maximum=b.method_10816(); int size=Math.clamp(b.method_10816(),0,10000); java.util.ArrayList<Long> nodes=new java.util.ArrayList<>(size); for(int i=0;i<size;i++) nodes.add(b.method_10792()); return new OpenPayload(id,name,status,interval,speed,maximum,List.copyOf(nodes)); }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }

    public record UpdatePayload(long lineId, String name, int statusOrdinal, int intervalSeconds, double speedKmh,
                                int maximumTrains, boolean refresh, boolean delete, int nodeIndex,
                                int nodeAction, boolean editNodes) implements class_8710 {
        public static final class_9154<UpdatePayload> ID = new class_9154<>(FabricTrainMod.id("update_line_settings"));
        public static final class_9139<class_9129, UpdatePayload> CODEC = class_8710.method_56484(UpdatePayload::write, UpdatePayload::read);
        private void write(class_9129 b) { b.method_10791(lineId); b.method_10788(name,64); b.method_10804(statusOrdinal); b.method_10804(intervalSeconds); b.method_52940(speedKmh); b.method_10804(maximumTrains); b.method_52964(refresh); b.method_52964(delete); b.method_10804(nodeIndex); b.method_10804(nodeAction); b.method_52964(editNodes); }
        private static UpdatePayload read(class_9129 b) { return new UpdatePayload(b.method_10792(), b.method_10800(64), b.method_10816(), b.method_10816(), b.readDouble(), b.method_10816(), b.readBoolean(), b.readBoolean(), b.method_10816(), b.method_10816(), b.readBoolean()); }
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}
