package cn.quit5700.fabrictrain.entity;

import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainLink;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1695;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.train.ConnectorInteractionService;
import cn.quit5700.fabrictrain.train.LogicallyControlledVehicle;

public final class LocomotiveEntity extends class_1695 implements LinkedTrainCar, LogicallyControlledVehicle {
    private static final class_2940<Boolean> LOGICALLY_CONTROLLED =
            class_2945.method_12791(LocomotiveEntity.class, class_2943.field_13323);
    private final TrainLink trainLink = new TrainLink();
    private net.minecraft.class_243 parkedPosition;
    public LocomotiveEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
        trainLink.assign(method_5667(), method_5667(), 0);
    }

    @Override
    public boolean method_64272() {
        return true;
    }

    @Override
    protected class_1792 method_7557() {
        return ModItems.LOCOMOTIVE;
    }

    @Override
    public class_1799 method_31480() {
        return new class_1799(ModItems.LOCOMOTIVE);
    }

    @Override public class_2680 method_7517() { return ModBlocks.LOCOMOTIVE_DISPLAY.method_9564(); }
    @Override public int method_7526() { return 6; }

    @Override public TrainLink trainLink() { return trainLink; }
    @Override protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(LOGICALLY_CONTROLLED, false);
    }
    @Override public boolean fabricTrain$isLogicallyControlled() { return field_6011.method_12789(LOGICALLY_CONTROLLED); }
    @Override public void fabricTrain$setLogicallyControlled(boolean controlled) { field_6011.method_12778(LOGICALLY_CONTROLLED, controlled); }
    @Override public class_1269 method_5688(class_1657 player, class_1268 hand) {
        class_1269 result = ConnectorInteractionService.rightClick(player, hand, this);
        return result != class_1269.field_5811 ? result : super.method_5688(player, hand);
    }
    @Override public void method_5697(net.minecraft.class_1297 entity) {
        if (fabricTrain$isLogicallyControlled()) return;
        if (entity instanceof CargoCarEntity cargo) {
            cargo.beginAuthorizedPush();
            try { super.method_5697(entity); } finally { cargo.endAuthorizedPush(); }
        } else super.method_5697(entity);
    }
    @Override public void method_5773(){
        class_243 before = method_19538();
        boolean controlled = fabricTrain$isLogicallyControlled();
        boolean clientSide = method_37908().method_8608();
        if(!clientSide && trainLink.parked()&&parkedPosition==null)parkedPosition=method_19538();
        if(!clientSide && !trainLink.parked())parkedPosition=null;
        super.method_5773();
        if (LogicallyControlledVehicle.shouldRestorePosition(clientSide, controlled, false)) {
            method_33574(before);
            method_18799(class_243.field_1353);
        } else if(!clientSide && trainLink.parked()){
            method_18799(class_243.field_1353);
            if(parkedPosition!=null)method_33574(parkedPosition);
        }
    }
    @Override public void method_5650(class_5529 reason) {
        if (method_37908() instanceof class_3218 serverLevel)
            cn.quit5700.fabrictrain.train.TrainControllerManager.noteVehicleRemoved(
                    serverLevel, trainLink.trainId(), method_5667(), reason);
        super.method_5650(reason);
    }
    @Override protected void method_5749(class_2487 input) { super.method_5749(input); trainLink.load(input); }
    @Override protected void method_5652(class_2487 output) { super.method_5652(output); trainLink.save(output); }
}
