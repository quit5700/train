package cn.quit5700.fabrictrain.data;

import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public final class RailwayDataManager {
    private RailwayDataManager() {
    }

    public static RailwaySavedData state(class_3218 level) {
        MinecraftServer server = level.method_8503();
        return server.method_30002().method_17983().method_17924(RailwaySavedData.TYPE, RailwaySavedData.DATA_ID);
    }

    public static String dimension(class_3218 level) {
        return level.method_27983().method_29177().toString();
    }

    public static RailwayDevice register(class_3218 level, class_2338 pos, DeviceType type) {
        return state(level).register(type, dimension(level), pos.method_10263(), pos.method_10264(), pos.method_10260());
    }

    public static void remove(class_3218 level, class_2338 pos) {
        state(level).remove(dimension(level), pos.method_10263(), pos.method_10264(), pos.method_10260());
    }
}
