package cn.quit5700.fabrictrain.data;

import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Recovers missing device records from the authoritative blocks stored in region files. */
public final class DeviceRecoveryService {
    private static final Logger LOGGER = LoggerFactory.getLogger(DeviceRecoveryService.class);
    private static final ConcurrentLinkedQueue<Long> PENDING = new ConcurrentLinkedQueue<>();
    private static final Set<Long> QUEUED = ConcurrentHashMap.newKeySet();
    private static volatile boolean scanning;

    private DeviceRecoveryService() { }

    public static void begin(MinecraftServer server) {
        clear();
        scanning = true;
        Thread scanner = new Thread(() -> {
            try {
                RegionDeviceChunkScanner.scanWorld(server.method_27050(class_5218.field_24188), packed -> {
                    if (QUEUED.add(packed)) PENDING.add(packed);
                });
            } catch (IOException exception) {
                LOGGER.error("扫描旧铁路设备区块失败", exception);
            } finally {
                scanning = false;
            }
        }, "fabric-train-device-recovery");
        scanner.setDaemon(true);
        scanner.start();
    }

    public static void tick(MinecraftServer server) {
        recoverPending(server.method_30002(), 1);
    }

    public static void recoverPending(class_3218 level, int maximumChunks) {
        for (int i = 0; i < maximumChunks; i++) {
            Long packed = PENDING.poll();
            if (packed == null) return;
            QUEUED.remove(packed);
            recoverChunk(level, RegionDeviceChunkScanner.unpackX(packed), RegionDeviceChunkScanner.unpackZ(packed));
        }
    }

    private static void recoverChunk(class_3218 level, int chunkX, int chunkZ) {
        int minimumX = chunkX << 4;
        int minimumZ = chunkZ << 4;
        class_2338.class_2339 cursor = new class_2338.class_2339();
        int recovered = 0;
        for (int y = level.method_31607(); y < level.method_31600(); y++) {
            for (int localZ = 0; localZ < 16; localZ++) {
                for (int localX = 0; localX < 16; localX++) {
                    cursor.method_10103(minimumX + localX, y, minimumZ + localZ);
                    var block = level.method_8320(cursor).method_26204();
                    DeviceType type = block == ModBlocks.STATION_MARKER ? DeviceType.STATION
                            : block == ModBlocks.SWITCH_RAIL ? DeviceType.SWITCH
                            : block == ModBlocks.TRAIN_DEPOT ? DeviceType.DEPOT : null;
                    if (type != null && RailwayDataManager.state(level).find(RailwayDataManager.dimension(level),
                            cursor.method_10263(), cursor.method_10264(), cursor.method_10260()) == null) {
                        RailwayDataManager.register(level, cursor.method_10062(), type);
                        recovered++;
                    }
                }
            }
        }
        if (recovered > 0) LOGGER.info("已从区块 ({}, {}) 恢复 {} 个铁路设备记录", chunkX, chunkZ, recovered);
    }

    public static boolean isScanning() { return scanning; }

    public static void clear() {
        PENDING.clear();
        QUEUED.clear();
        scanning = false;
    }
}
