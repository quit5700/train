package cn.quit5700.fabrictrain.data;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.route.RuntimePathCache;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public final class LineDeletionService {
    private LineDeletionService() {}

    public static boolean delete(MinecraftServer server, class_3218 sourceLevel, long lineId) {
        RailwaySavedData data = RailwayDataManager.state(sourceLevel);
        RailwayLine line = data.line(lineId);
        if (line == null) return false;
        TrainControllerManager.handleDeletedLine(server, lineId, data.recoveryDepotId(lineId));
        for (RailwayDevice device : data.devices().values()) {
            if (device.type() != DeviceType.DEPOT) continue;
            for (class_3218 level : server.method_3738()) {
                if (!device.dimension().equals(RailwayDataManager.dimension(level))) continue;
                class_2338 pos = new class_2338(device.x(), device.y(), device.z());
                if (level.method_22340(pos) && level.method_8321(pos) instanceof TrainDepotBlockEntity depot
                        && depot.selectedLineId() == lineId) {
                    depot.setSelectedLineId(0L);
                    depot.setAutomaticDispatchEnabled(false);
                }
            }
        }
        RuntimePathCache.remove(lineId);
        return data.deleteLine(lineId);
    }
}
