package cn.quit5700.fabrictrain.compat;

import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/** Preserves the post-1.21.5 optional NBT read semantics on older game versions. */
public final class NbtCompat {
    private NbtCompat() {}

    public static int getInt(class_2487 tag, String key, int fallback) {
        return tag.method_10573(key, class_2520.field_33263) ? tag.method_10550(key) : fallback;
    }
    public static long getLong(class_2487 tag, String key, long fallback) {
        return tag.method_10573(key, class_2520.field_33263) ? tag.method_10537(key) : fallback;
    }
    public static double getDouble(class_2487 tag, String key, double fallback) {
        return tag.method_10573(key, class_2520.field_33263) ? tag.method_10574(key) : fallback;
    }
    public static boolean getBoolean(class_2487 tag, String key, boolean fallback) {
        return tag.method_10573(key, class_2520.field_33251) ? tag.method_10577(key) : fallback;
    }
    public static String getString(class_2487 tag, String key, String fallback) {
        return tag.method_10573(key, class_2520.field_33258) ? tag.method_10558(key) : fallback;
    }
    public static class_2499 getList(class_2487 tag, String key) {
        return tag.method_10554(key, class_2520.field_33260);
    }
    public static class_2487 getCompound(class_2499 list, int index) {
        return list.method_10602(index);
    }
}
