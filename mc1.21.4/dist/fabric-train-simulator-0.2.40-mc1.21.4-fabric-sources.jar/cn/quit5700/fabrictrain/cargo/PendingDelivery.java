package cn.quit5700.fabrictrain.cargo;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1799;

public record PendingDelivery(UUID shipmentId, UUID sourceCarId, long stationId, long dueGameTime,
                              List<class_1799> stacks) {
    private static final Codec<UUID> UUID_CODEC = Codec.STRING.xmap(UUID::fromString, UUID::toString);
    public static final Codec<PendingDelivery> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            UUID_CODEC.fieldOf("shipment_id").forGetter(PendingDelivery::shipmentId),
            UUID_CODEC.fieldOf("source_car_id").forGetter(PendingDelivery::sourceCarId),
            Codec.LONG.fieldOf("station_id").forGetter(PendingDelivery::stationId),
            Codec.LONG.fieldOf("due_game_time").forGetter(PendingDelivery::dueGameTime),
            class_1799.field_24671.listOf().fieldOf("stacks").forGetter(PendingDelivery::stacks)
    ).apply(instance, PendingDelivery::new));

    public PendingDelivery {
        stacks = stacks.stream().filter(stack -> !stack.method_7960()).map(class_1799::method_7972).toList();
    }
}
