package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;

public final class CargoTransferService {
    private CargoTransferService() {
    }

    public static int unloadAtStation(class_3218 level, class_2338 stationPos, CargoCarEntity cargo) {
        List<class_1263> destinations = adjacentContainers(level, stationPos);
        if (destinations.isEmpty()) return 0;
        int moved = 0;
        for (int sourceSlot = 0; sourceSlot < cargo.method_5439(); sourceSlot++) {
            class_1799 source = cargo.method_5438(sourceSlot);
            if (source.method_7960()) continue;
            int before = source.method_7947();
            for (class_1263 destination : destinations) insert(destination, source);
            moved += before - source.method_7947();
            cargo.method_5447(sourceSlot, source);
        }
        if (moved > 0) {
            cargo.method_5431();
            destinations.forEach(class_1263::method_5431);
        }
        return moved;
    }

    public static boolean hasAdjacentContainer(class_3218 level, class_2338 stationPos) {
        return !adjacentContainers(level, stationPos).isEmpty();
    }

    public static int manualUnloadAtStation(class_3218 level, class_2338 stationPos, CargoCarEntity cargo) {
        List<class_1263> destinations = adjacentContainers(level, stationPos);
        return manualUnload(destinations, cargo);
    }

    public static int manualUnload(List<? extends class_1263> destinations, class_1263 cargo) {
        if (destinations.isEmpty()) return 0;
        int moved = 0;
        for (int sourceSlot = 0; sourceSlot < cargo.method_5439(); sourceSlot++) {
            class_1799 source = cargo.method_5438(sourceSlot);
            if (source.method_7960()) continue;
            int before = source.method_7947();
            for (class_1263 destination : destinations) insert(destination, source);
            moved += before - source.method_7947();
            cargo.method_5447(sourceSlot, source);
        }
        if (moved > 0) { cargo.method_5431(); destinations.forEach(class_1263::method_5431); }
        return moved;
    }

    public static List<class_1799> deliverStacks(class_3218 level, class_2338 stationPos, List<class_1799> stacks) {
        List<class_1263> destinations = adjacentContainers(level, stationPos);
        if (destinations.isEmpty()) return stacks.stream().map(class_1799::method_7972).toList();
        ArrayList<class_1799> remaining = new ArrayList<>();
        for (class_1799 original : stacks) {
            class_1799 source = original.method_7972();
            for (class_1263 destination : destinations) insert(destination, source);
            if (!source.method_7960()) remaining.add(source);
        }
        destinations.forEach(class_1263::method_5431);
        return remaining;
    }

    public static List<class_1263> adjacentContainers(class_3218 level, class_2338 stationPos) {
        ArrayList<class_1263> containers = new ArrayList<>();
        for (class_2350 direction : class_2350.values()) {
            if (level.method_8321(stationPos.method_10093(direction)) instanceof class_1263 container) containers.add(container);
        }
        return containers;
    }

    private static void insert(class_1263 destination, class_1799 source) {
        for (int slot = 0; slot < destination.method_5439() && !source.method_7960(); slot++) {
            class_1799 target = destination.method_5438(slot);
            if (target.method_7960()) continue;
            int capacity = destination.method_58350(target) - target.method_7947();
            int amount = CargoSlotRules.movable(false,
                    class_1799.method_31577(source, target), true, source.method_7947(), capacity);
            if (amount <= 0) continue;
            target.method_7933(amount);
            source.method_7934(amount);
            destination.method_5447(slot, target);
        }
        for (int slot = 0; slot < destination.method_5439() && !source.method_7960(); slot++) {
            if (!destination.method_5438(slot).method_7960()) continue;
            int amount = CargoSlotRules.movable(true, false, destination.method_5437(slot, source),
                    source.method_7947(), destination.method_58350(source));
            if (amount <= 0) continue;
            destination.method_5447(slot, source.method_46651(amount));
            source.method_7934(amount);
        }
    }
}
