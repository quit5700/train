package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;

public final class StationPresenceService {
    private StationPresenceService() {}

    public static RailwayDevice findStationAt(class_3218 level, RailwaySavedData data, CargoCarEntity cargo) {
        class_2338 railPos = cargo.method_62825();
        for (RailwayLine line : data.lines().values()) {
            for (int index = 0; index < line.nodeIds().size(); index++) {
                RailwayDevice station = data.device(line.nodeIds().get(index));
                if (station == null || station.type() != DeviceType.STATION
                        || !station.dimension().equals(RailwayDataManager.dimension(level))) continue;
                // Presence checks must not mutate line data or auto-bind old stations. Migration is
                // performed only by line validation; here we consume an already persisted stop.
                StopTrack stop = line.stationStopTrack(index);
                if (stop != null && railPos.method_10263() == stop.x() && railPos.method_10264() == stop.y() && railPos.method_10260() == stop.z())
                    return station;
            }
        }
        String dimension = RailwayDataManager.dimension(level);
        for (RailwayDevice station : data.devices().values()) {
            if (station.type() != DeviceType.STATION || !station.dimension().equals(dimension)) continue;
            class_243 center = class_243.method_24953(new class_2338(station.x(), station.y(), station.z()));
            if (CargoDestinationRules.atStation(cargo.method_23317(), cargo.method_23318(), cargo.method_23321(), center.field_1352, center.field_1351, center.field_1350))
                return station;
        }
        return null;
    }
}
