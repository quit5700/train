package cn.quit5700.fabrictrain.power;

import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public final class RailPowerService {
    private static final int MAX_WIRE_BLOCKS = 20_000;
    private static final int MAX_RAIL_BLOCKS = 100_000;
    private static final Map<class_3218, Map<class_2338, GeneratorState>> GENERATORS = new WeakHashMap<>();
    private static final Map<class_3218, Set<class_2338>> POWERED_RAILS = new WeakHashMap<>();
    private static final Set<class_3218> DIRTY_LEVELS = Collections.newSetFromMap(new WeakHashMap<>());

    private RailPowerService() {}

    public static synchronized void updateGenerator(class_3218 level, class_2338 pos, boolean active) {
        Map<class_2338, GeneratorState> generators = GENERATORS.computeIfAbsent(level, ignored -> new HashMap<>());
        GeneratorState previous = generators.put(pos.method_10062(), new GeneratorState(active,
                level.method_8503().method_3780()));
        if (previous == null || previous.active != active) DIRTY_LEVELS.add(level);
    }

    public static synchronized void removeGenerator(class_3218 level, class_2338 pos) {
        Map<class_2338, GeneratorState> states = GENERATORS.get(level);
        if (states != null && states.remove(pos) != null) DIRTY_LEVELS.add(level);
    }

    public static synchronized boolean isPowered(class_3218 level, class_2338 pos) {
        Set<class_2338> powered = POWERED_RAILS.getOrDefault(level, Set.of());
        return powered.contains(pos);
    }

    public static void tick(MinecraftServer server) {
        synchronized (RailPowerService.class) {
            if (DIRTY_LEVELS.isEmpty()) return;
            for (class_3218 level : List.copyOf(DIRTY_LEVELS)) rebuild(level, server.method_3780());
            DIRTY_LEVELS.clear();
        }
    }

    public static synchronized void refreshNow(class_3218 level) {
        rebuild(level, level.method_8503().method_3780());
        DIRTY_LEVELS.remove(level);
    }

    public static synchronized void markDirty(class_3218 level) { DIRTY_LEVELS.add(level); }

    private static void rebuild(class_3218 level, int tick) {
        Map<class_2338, GeneratorState> states = GENERATORS.computeIfAbsent(level, ignored -> new HashMap<>());
        states.entrySet().removeIf(entry -> tick - entry.getValue().lastSeenTick > 40);
        Set<class_2338> oldPowered = POWERED_RAILS.getOrDefault(level, Set.of());
        HashSet<class_2338> powered = new HashSet<>();
        for (class_2338 old : oldPowered) if (!level.method_22340(old)) powered.add(old);
        for (Map.Entry<class_2338, GeneratorState> entry : states.entrySet()) {
            if (!entry.getValue().active) continue;
            traceWires(level, entry.getKey(), powered);
        }
        POWERED_RAILS.put(level, Set.copyOf(powered));
        HashSet<class_2338> changed = new HashSet<>(oldPowered);
        changed.addAll(powered);
        changed.removeIf(pos -> oldPowered.contains(pos) == powered.contains(pos));
        if (!changed.isEmpty()) PowerSectionCache.refreshChanged(level, changed);
    }

    private static void traceWires(class_3218 level, class_2338 generator, Set<class_2338> poweredRails) {
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        HashSet<class_2338> visited = new HashSet<>();
        for (class_2350 direction : class_2350.values()) {
            class_2338 next = generator.method_10093(direction);
            if (isWire(level.method_8320(next))) queue.add(next);
        }
        while (!queue.isEmpty() && visited.size() < MAX_WIRE_BLOCKS) {
            class_2338 wire = queue.removeFirst();
            if (!visited.add(wire) || !level.method_22340(wire)) continue;
            for (class_2350 direction : class_2350.values()) {
                class_2338 next = wire.method_10093(direction);
                class_2680 state = level.method_8320(next);
                if (isWire(state) && !visited.contains(next)) queue.add(next);
                else if (isRail(state)) floodRails(level, next, poweredRails);
            }
        }
    }

    private static void floodRails(class_3218 level, class_2338 start, Set<class_2338> powered) {
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        queue.add(start);
        while (!queue.isEmpty() && powered.size() < MAX_RAIL_BLOCKS) {
            class_2338 rail = queue.removeFirst();
            if (powered.contains(rail) || !level.method_22340(rail) || !isRail(level.method_8320(rail))) continue;
            powered.add(rail.method_10062());
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                class_2338 beside = rail.method_10093(direction);
                for (int dy = -1; dy <= 1; dy++) {
                    class_2338 candidate = beside.method_10069(0, dy, 0);
                    if (!powered.contains(candidate) && isRail(level.method_8320(candidate))) queue.add(candidate);
                }
            }
        }
    }

    private static boolean isWire(class_2680 state) { return state.method_27852(class_2246.field_10091); }
    private static boolean isRail(class_2680 state) { return state.method_27852(ModBlocks.SIGNAL_RAIL) || state.method_27852(ModBlocks.SWITCH_RAIL); }
    public static synchronized void clear() { GENERATORS.clear(); POWERED_RAILS.clear(); DIRTY_LEVELS.clear(); }
    private record GeneratorState(boolean active, int lastSeenTick) {}
}
