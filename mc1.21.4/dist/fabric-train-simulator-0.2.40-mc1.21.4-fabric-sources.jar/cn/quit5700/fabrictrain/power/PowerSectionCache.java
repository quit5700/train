package cn.quit5700.fabrictrain.power;

import cn.quit5700.fabrictrain.route.TrackPoint;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/** Runtime-only power cache. A route is divided into fixed 64-track sections. */
public final class PowerSectionCache {
    public static final int SECTION_LENGTH = 64;
    private static final Map<Long, PowerSectionSnapshot> SNAPSHOTS = new ConcurrentHashMap<>();
    private static final Map<class_2338, Set<RoutePoint>> ROUTES_BY_RAIL = new ConcurrentHashMap<>();

    private PowerSectionCache() {}

    public static synchronized void put(class_3218 level, long lineId, List<TrackPoint> path) {
        remove(lineId);
        PowerSectionSnapshot snapshot = PowerSectionSnapshot.create(path, SECTION_LENGTH, point ->
                status(level, new class_2338(point.x(), point.y(), point.z()), null));
        SNAPSHOTS.put(lineId, snapshot);
        for (int index = 0; index < path.size(); index++) {
            TrackPoint point = path.get(index);
            class_2338 pos = new class_2338(point.x(), point.y(), point.z());
            ROUTES_BY_RAIL.computeIfAbsent(pos, ignored -> ConcurrentHashMap.newKeySet())
                    .add(new RoutePoint(lineId, index));
        }
    }

    /** Refreshes only route points whose rail power actually changed. */
    public static synchronized void refreshChanged(class_3218 level, Collection<class_2338> changed) {
        for (class_2338 pos : changed) {
            Set<RoutePoint> references = ROUTES_BY_RAIL.get(pos);
            if (references == null) continue;
            PowerSectionStatus state = status(level, pos, null);
            for (RoutePoint reference : references) {
                PowerSectionSnapshot snapshot = SNAPSHOTS.get(reference.lineId());
                if (snapshot != null) SNAPSHOTS.put(reference.lineId(),
                        snapshot.withPointState(reference.pathIndex(), state));
            }
        }
    }

    /** Keeps the last validated value for unloaded chunks. */
    public static synchronized void refreshLoaded(class_3218 level, long lineId) {
        PowerSectionSnapshot previous = SNAPSHOTS.get(lineId);
        if (previous == null) return;
        PowerSectionSnapshot refreshed = PowerSectionSnapshot.createIndexed(previous.path(), SECTION_LENGTH, (index, point) -> {
            class_2338 pos = new class_2338(point.x(), point.y(), point.z());
            if (!level.method_22340(pos)) return previous.pointStatus(index);
            return status(level, pos, null);
        });
        SNAPSHOTS.put(lineId, refreshed);
    }

    public static boolean allPowered(long lineId) {
        PowerSectionSnapshot snapshot = SNAPSHOTS.get(lineId);
        return snapshot != null && snapshot.allPowered();
    }

    public static boolean canProceed(long lineId, int pathIndex) {
        PowerSectionSnapshot snapshot = SNAPSHOTS.get(lineId);
        return snapshot != null && snapshot.canProceedFrom(pathIndex);
    }

    public static PowerSectionStatus sectionStatus(long lineId, int sectionIndex) {
        PowerSectionSnapshot snapshot = SNAPSHOTS.get(lineId);
        return snapshot == null ? PowerSectionStatus.UNKNOWN : snapshot.sectionStatus(sectionIndex);
    }

    public static synchronized void remove(long lineId) {
        PowerSectionSnapshot removed = SNAPSHOTS.remove(lineId);
        if (removed == null) return;
        for (TrackPoint point : removed.path()) {
            class_2338 pos = new class_2338(point.x(), point.y(), point.z());
            Set<RoutePoint> references = ROUTES_BY_RAIL.get(pos);
            if (references == null) continue;
            references.removeIf(reference -> reference.lineId() == lineId);
            if (references.isEmpty()) ROUTES_BY_RAIL.remove(pos);
        }
    }

    public static synchronized void clear() {
        SNAPSHOTS.clear();
        ROUTES_BY_RAIL.clear();
    }

    private static PowerSectionStatus status(class_3218 level, class_2338 pos, PowerSectionStatus unloadedFallback) {
        if (!level.method_22340(pos)) return unloadedFallback == null ? PowerSectionStatus.UNKNOWN : unloadedFallback;
        return RailPowerService.isPowered(level, pos) ? PowerSectionStatus.POWERED : PowerSectionStatus.UNPOWERED;
    }

    private record RoutePoint(long lineId, int pathIndex) {}
}
