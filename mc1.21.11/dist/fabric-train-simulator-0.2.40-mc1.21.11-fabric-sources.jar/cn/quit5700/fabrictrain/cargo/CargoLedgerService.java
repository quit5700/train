package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class CargoLedgerService {
    private CargoLedgerService() {}

    public static CargoLedgerSavedData state(class_3218 level) {
        return level.method_8503().method_30002().method_17983().method_17924(CargoLedgerSavedData.TYPE);
    }

    public static boolean escrow(class_3218 level, CargoCarEntity cargo, long stationId, long dueGameTime) {
        CargoLedgerSavedData ledger = state(level);
        if (cargo.method_5442() || ledger.containsSource(cargo.method_5667())) return false;
        ArrayList<class_1799> stacks = new ArrayList<>();
        for (int slot = 0; slot < cargo.method_5439(); slot++) {
            class_1799 stack = cargo.method_5438(slot);
            if (!stack.method_7960()) stacks.add(stack.method_7972());
        }
        if (stacks.isEmpty()) return false;
        ledger.add(new PendingDelivery(UUID.randomUUID(), cargo.method_5667(), stationId, dueGameTime, stacks));
        for (int slot = 0; slot < cargo.method_5439(); slot++) cargo.method_5447(slot, class_1799.field_8037);
        cargo.method_5431();
        return true;
    }

    /** Records cargo that reached an unloaded station; delivery to containers happens when it loads. */
    public static void depositArrived(class_3218 level, UUID sourceCarId, long stationId, List<class_1799> stacks) {
        List<class_1799> cargo = stacks.stream().filter(stack -> !stack.method_7960()).map(class_1799::method_7972).toList();
        if (stationId <= 0L || cargo.isEmpty()) return;
        state(level).add(new PendingDelivery(UUID.randomUUID(), sourceCarId, stationId,
                level.method_75260(), cargo));
    }

    public static void tick(MinecraftServer server) {
        if (server.method_3780() % 20 != 0) return;
        CargoLedgerSavedData ledger = state(server.method_30002());
        for (PendingDelivery delivery : ledger.deliveries()) {
            if (server.method_30002().method_75260() < delivery.dueGameTime()) continue;
            RailwayDevice station = RailwayDataManager.state(server.method_30002()).device(delivery.stationId());
            if (station == null) continue;
            class_3218 destinationLevel = null;
            for (class_3218 candidate : server.method_3738()) {
                if (RailwayDataManager.dimension(candidate).equals(station.dimension())) { destinationLevel = candidate; break; }
            }
            if (destinationLevel == null) continue;
            class_2338 stationPos = new class_2338(station.x(), station.y(), station.z());
            if (!destinationLevel.method_22340(stationPos)) continue;
            List<class_1799> remaining = CargoTransferService.deliverStacks(destinationLevel, stationPos, delivery.stacks());
            ledger.replace(delivery, new PendingDelivery(delivery.shipmentId(), delivery.sourceCarId(),
                    delivery.stationId(), delivery.dueGameTime(), remaining));
        }
    }
}
