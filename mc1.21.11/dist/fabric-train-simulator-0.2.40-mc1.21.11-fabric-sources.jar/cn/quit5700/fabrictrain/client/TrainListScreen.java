package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.DepotNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.List;
import java.util.ArrayList;

public final class TrainListScreen extends class_437 {
    private static TrainListScreen active;
    private static final int PANEL_WIDTH = 300;
    private static final int ROW_HEIGHT = 22;
    private List<DepotNetworking.TrainListEntry> trains;
    private final class_2338 depotPos;
    private int scrollOffset;
    private int refreshTicks;
    private final List<class_4185> deleteButtons = new ArrayList<>();

    public TrainListScreen(DepotNetworking.TrainListPayload payload) {
        super(class_310.method_1551(), class_310.method_1551().field_1772,
                class_2561.method_43471("screen.fabric_train_simulator.train_list.title"));
        trains = payload.trains();
        depotPos = payload.depotPos();
        active = this;
    }

    public static boolean refreshActive(DepotNetworking.TrainListPayload payload) {
        if (active == null || !active.accepts(payload)) return false;
        active.applyPayload(payload);
        return true;
    }

    public boolean accepts(DepotNetworking.TrainListPayload payload) {
        return depotPos.equals(payload.depotPos());
    }

    public void applyPayload(DepotNetworking.TrainListPayload payload) {
        if (!accepts(payload)) return;
        if (trains.equals(payload.trains())) return;
        trains = payload.trains();
        scrollOffset = Math.min(scrollOffset, Math.max(0, trains.size() * ROW_HEIGHT));
        method_41843();
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (++refreshTicks >= 20) {
            refreshTicks = 0;
            ClientPlayNetworking.send(new DepotNetworking.RequestTrainListPayload(depotPos));
        }
    }

    private ResponsiveScreenLayout layout() {
        int desiredHeight = Math.max(110, 74 + trains.size() * ROW_HEIGHT);
        return ResponsiveScreenLayout.of(field_22789, field_22790, PANEL_WIDTH, desiredHeight, 20);
    }

    @Override
    protected void method_25426() {
        ResponsiveScreenLayout layout = layout();
        deleteButtons.clear();
        for (DepotNetworking.TrainListEntry train : trains) {
            class_4185 delete = class_4185.method_46430(class_2561.method_43471(
                            "screen.fabric_train_simulator.train_list.delete"),
                    button -> ClientPlayNetworking.send(new DepotNetworking.DeleteTrainPayload(
                            depotPos, train.trainId())))
                    .method_46434(0, 0, 52, 18).method_46431();
            deleteButtons.add(method_37063(delete));
        }
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.train_list.back"),
                button -> ClientPlayNetworking.send(new DepotNetworking.RequestOpenPayload(depotPos)))
                .method_46434(layout.left() + 10, layout.footerY(), layout.panelWidth() - 20, 20).method_46431());
        positionDeleteButtons(layout);
    }

    @Override
    public void method_25419() {
        if (active == this) active = null;
        ClientPlayNetworking.send(new DepotNetworking.ClosePayload(depotPos));
        super.method_25419();
    }

    @Override
    public void method_25432() {
        if (active == this) active = null;
        super.method_25432();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        ResponsiveScreenLayout layout = layout();
        int visibleHeight = Math.max(ROW_HEIGHT, layout.scrollBottom() - layout.scrollTop());
        int contentHeight = Math.max(ROW_HEIGHT, trains.size() * ROW_HEIGHT);
        int maximumOffset = Math.max(0, contentHeight - visibleHeight);
        int next = Math.clamp(scrollOffset - (int) Math.signum(vertical) * ROW_HEIGHT, 0, maximumOffset);
        if (next == scrollOffset) return super.method_25401(mouseX, mouseY, horizontal, vertical);
        scrollOffset = next;
        positionDeleteButtons(layout);
        return true;
    }

    private void positionDeleteButtons(ResponsiveScreenLayout layout) {
        for (int index = 0; index < deleteButtons.size(); index++) {
            int y = layout.scrollTop() + index * ROW_HEIGHT - scrollOffset;
            class_4185 button = deleteButtons.get(index);
            button.method_48229(layout.right() - 66, y + 1);
            button.field_22764 = y >= layout.scrollTop() && y + ROW_HEIGHT <= layout.scrollBottom();
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = layout();
        graphics.method_25294(layout.left(), layout.top(), layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_73198(layout.left(), layout.top(), layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, layout.top() + 9, 0xFFFFFFFF);
        if (trains.isEmpty()) {
            graphics.method_27534(field_22793, class_2561.method_43471("screen.fabric_train_simulator.train_list.empty"),
                    field_22789 / 2, layout.scrollTop() + 12, 0xFFB8B8B8);
        } else {
            int y = layout.scrollTop() - scrollOffset;
            for (DepotNetworking.TrainListEntry train : trains) {
                if (y >= layout.scrollTop() && y + ROW_HEIGHT <= layout.scrollBottom()) {
                    class_2561 mode = class_2561.method_43471(train.automatic()
                            ? "screen.fabric_train_simulator.train_list.automatic"
                            : "screen.fabric_train_simulator.train_list.manual");
                    graphics.method_27535(field_22793, class_2561.method_43469("screen.fabric_train_simulator.train_list.item",
                            train.number(), mode), layout.left() + 16, y + 6, 0xFFE6E6E6);
                }
                y += ROW_HEIGHT;
            }
        }
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }
}
