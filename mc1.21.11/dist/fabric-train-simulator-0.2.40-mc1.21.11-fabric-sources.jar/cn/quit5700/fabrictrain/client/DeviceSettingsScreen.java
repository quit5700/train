package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class DeviceSettingsScreen extends class_437 {
    private final long deviceId;
    private final DeviceType type;
    private int dwellSeconds;
    private int cargoDwellSeconds;
    private int switchShape;
    private int switchEntryOrdinal;
    private class_342 name;
    private class_342 announcement;
    private final boolean containerConnected;
    private int scrollOffset;

    public DeviceSettingsScreen(DeviceSettingsNetworking.OpenPayload payload) {
        super(class_310.method_1551(), class_310.method_1551().field_1772,
                titleFor(payload));
        deviceId = payload.deviceId();
        type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        dwellSeconds = payload.dwellSeconds();
        cargoDwellSeconds = payload.cargoDwellSeconds();
        switchShape = Math.clamp(payload.switchShapeOrdinal(), 0, 2);
        switchEntryOrdinal = payload.switchEntryOrdinal();
        name = new class_342(field_22793, 190, 20, class_2561.method_43471("screen.fabric_train_simulator.device.name"));
        name.method_1880(64);
        name.method_1852(payload.name());
        announcement = new class_342(field_22793, 190, 20, class_2561.method_43471("screen.fabric_train_simulator.station.announcement"));
        announcement.method_1880(128); announcement.method_1852(payload.announcement());
        containerConnected = payload.containerConnected();
    }

    @Override protected void method_25426() {
        boolean compact = field_22790 < 304;
        int desiredHeight = type == DeviceType.SWITCH ? 180 : compact ? 242 : 304;
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 220, desiredHeight, 20);
        int left = layout.left();
        int top = layout.top();
        int nameY = top + (compact ? 38 : 48) - scrollOffset;
        name.method_46421(left + 15); name.method_46419(nameY); method_37063(name);
        name.field_22764 = insideContent(nameY, layout, type == DeviceType.STATION ? layout.footerY() - 28 : layout.footerY());
        if(type==DeviceType.STATION){
            int announcementY=top+(compact?142:192)-scrollOffset;
            announcement.method_46421(left+15);announcement.method_46419(announcementY);method_37063(announcement);
            announcement.field_22764=insideContent(announcementY,layout,layout.footerY()-28);
        }
        if (type == DeviceType.STATION) {
            int dwellY=top+(compact?76:102)-scrollOffset,cargoY=top+(compact?110:146)-scrollOffset;
            addContentButton(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.minus_five"), b -> dwellSeconds = Math.max(0, dwellSeconds - 5)).method_46434(left + 15, dwellY, 70, 20).method_46431(),layout,layout.footerY()-28);
            addContentButton(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.plus_five"), b -> dwellSeconds = Math.min(3600, dwellSeconds + 5)).method_46434(left + 135, dwellY, 70, 20).method_46431(),layout,layout.footerY()-28);
            addContentButton(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.minus_five"), b -> cargoDwellSeconds = Math.max(0, cargoDwellSeconds - 5)).method_46434(left + 15, cargoY, 70, 20).method_46431(),layout,layout.footerY()-28);
            addContentButton(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.plus_five"), b -> cargoDwellSeconds = Math.min(3600, cargoDwellSeconds + 5)).method_46434(left + 135, cargoY, 70, 20).method_46431(),layout,layout.footerY()-28);
        }
        if (type == DeviceType.SWITCH) {
            method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.switch.left"), b -> switchShape = 0).method_46434(left + 10, top + 90, 62, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.switch.straight"), b -> switchShape = 1).method_46434(left + 79, top + 90, 62, 20).method_46431());
            method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.switch.right"), b -> switchShape = 2).method_46434(left + 148, top + 90, 62, 20).method_46431());
        }
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.device.save"), b -> save()).method_46434(left + 75, layout.footerY(), 70, 20).method_46431());
    }

    private void addContentButton(class_4185 button, ResponsiveScreenLayout layout, int bottom) {
        button.field_22764 = insideContent(button.method_46427(), layout, bottom);
        method_37063(button);
    }

    private static boolean insideContent(int y, ResponsiveScreenLayout layout, int bottom) {
        return y >= layout.scrollTop() && y + 20 <= bottom;
    }

    @Override public boolean method_25401(double mouseX,double mouseY,double horizontal,double vertical) {
        boolean compact=field_22790<304;int desiredHeight=type==DeviceType.SWITCH?180:compact?242:304;
        ResponsiveScreenLayout layout=ResponsiveScreenLayout.of(field_22789,field_22790,220,desiredHeight,20);
        if(!layout.scrollRequired())return super.method_25401(mouseX,mouseY,horizontal,vertical);
        int maximum=Math.max(0,desiredHeight-layout.panelHeight());
        int next=Math.clamp(scrollOffset-(int)Math.signum(vertical)*20,0,maximum);
        if(next==scrollOffset)return false;scrollOffset=next;method_41843();return true;
    }

    private static class_2561 titleFor(DeviceSettingsNetworking.OpenPayload payload) {
        DeviceType type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        return class_2561.method_43469(type == DeviceType.STATION
                ? "screen.fabric_train_simulator.station.named_title"
                : "screen.fabric_train_simulator.switch.named_title", payload.name());
    }
    private void save() {
        ClientPlayNetworking.send(new DeviceSettingsNetworking.UpdatePayload(deviceId, name.method_1882(), dwellSeconds,
                cargoDwellSeconds, switchShape, switchEntryOrdinal, announcement.method_1882()));
        method_25419();
    }

    @Override public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        boolean compact=field_22790<304;int desiredHeight=type==DeviceType.SWITCH?180:compact?242:304;
        ResponsiveScreenLayout layout=ResponsiveScreenLayout.of(field_22789,field_22790,220,desiredHeight,20);
        int left = layout.left();
        int top = layout.top();
        graphics.method_25294(left, top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_73198(left, top, layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 10, 0xFFFFFFFF);
        int nameLabelY=top+(compact?26:35)-scrollOffset;
        if(insideContent(nameLabelY,layout,type==DeviceType.STATION?layout.footerY()-28:layout.footerY()))graphics.method_27535(field_22793, class_2561.method_43471("screen.fabric_train_simulator.device.name"), left + 15, nameLabelY, 0xFFCCCCCC);
        int dwellLabelY=top+(compact?62:87)-scrollOffset;
        if (type == DeviceType.STATION&&insideContent(dwellLabelY,layout,layout.footerY()-28)) graphics.method_27534(field_22793,
                class_2561.method_43469("screen.fabric_train_simulator.device.dwell", dwellSeconds), field_22789 / 2, dwellLabelY, 0xFFE6E6E6);
        if(type==DeviceType.STATION) {
            int cargoLabelY=top+(compact?96:131)-scrollOffset,announcementLabelY=top+(compact?130:179)-scrollOffset,containerY=top+(compact?166:218)-scrollOffset;
            if(insideContent(cargoLabelY,layout,layout.footerY()-28))graphics.method_27534(field_22793, class_2561.method_43469("screen.fabric_train_simulator.station.cargo_dwell", cargoDwellSeconds), field_22789 / 2, cargoLabelY, 0xFFE6E6E6);
            if(insideContent(announcementLabelY,layout,layout.footerY()-28))graphics.method_27535(field_22793,class_2561.method_43471("screen.fabric_train_simulator.station.announcement"),left+15,announcementLabelY,0xFFCCCCCC);
            if(insideContent(containerY,layout,layout.footerY()-28))graphics.method_27534(field_22793, class_2561.method_43471(containerConnected
                    ? "screen.fabric_train_simulator.station.container_connected"
                    : "screen.fabric_train_simulator.station.container_disconnected"), field_22789 / 2, containerY, 0xFFE6E6E6);
        }
        if (type == DeviceType.SWITCH) graphics.method_27534(field_22793,
                class_2561.method_43469("screen.fabric_train_simulator.device.shape",
                        class_2561.method_43471("screen.fabric_train_simulator.switch." + switchName())), field_22789 / 2, top + 120, 0xFFE6E6E6);
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }

    private String switchName() { return switch (switchShape) { case 0 -> "left"; case 2 -> "right"; default -> "straight"; }; }
}
