package cn.quit5700.fabrictrain.depot;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.cargo.CargoTransferService;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

public final class DepotRecoveryService {
    private DepotRecoveryService() {}

    public static boolean recover(List<class_1297> cars, TrainDepotBlockEntity depot) {
        List<class_1263> containers = new ArrayList<>(); containers.add(depot);
        if (depot.method_10997() instanceof class_3218 level)
            containers.addAll(CargoTransferService.adjacentContainers(level, depot.method_11016()));
        List<class_1799> simulated = new ArrayList<>();
        for (class_1263 container : containers) for (int slot=0;slot<container.method_5439();slot++)
            simulated.add(container.method_5438(slot).method_7972());
        List<class_1799> returning = new ArrayList<>();
        for (class_1297 entity : cars) {
            if (entity instanceof CargoCarEntity cargo) {
                for (int slot = 0; slot < cargo.method_5439(); slot++) {
                    if (!cargo.method_5438(slot).method_7960()) returning.add(cargo.method_5438(slot).method_7972());
                }
                returning.add(new class_1799(ModItems.CARGO_CAR));
            } else if (entity instanceof PassengerCarEntity) {
                returning.add(new class_1799(ModItems.PASSENGER_CAR));
            } else if (entity instanceof LocomotiveEntity) {
                returning.add(new class_1799(ModItems.LOCOMOTIVE));
            }
        }
        for (class_1799 stack : returning) if (!insert(simulated, stack)) return false;
        int flat=0;for(class_1263 container:containers){for(int slot=0;slot<container.method_5439();slot++)container.method_5447(slot,simulated.get(flat++));container.method_5431();}
        cars.stream().filter(LocomotiveEntity.class::isInstance).map(LocomotiveEntity.class::cast)
                .findFirst().ifPresent(locomotive -> {
                    if (locomotive.method_73183() instanceof class_3218 level) {
                        cn.quit5700.fabrictrain.train.TrainControllerManager.retireTrainResources(
                                level, locomotive.trainLink().trainId());
                    }
                });
        cars.forEach(class_1297::method_31472);
        return true;
    }

    public static boolean recoverItems(class_3218 level, TrainDepotBlockEntity depot, List<class_1799> returning) {
        List<class_1263> containers = new ArrayList<>(); containers.add(depot);
        containers.addAll(CargoTransferService.adjacentContainers(level, depot.method_11016()));
        List<class_1799> simulated = new ArrayList<>();
        for (class_1263 container : containers) for (int slot = 0; slot < container.method_5439(); slot++)
            simulated.add(container.method_5438(slot).method_7972());
        for (class_1799 stack : returning) if (!insert(simulated, stack.method_7972())) return false;
        int flat = 0;
        for (class_1263 container : containers) {
            for (int slot = 0; slot < container.method_5439(); slot++) container.method_5447(slot, simulated.get(flat++));
            container.method_5431();
        }
        return true;
    }

    private static boolean insert(List<class_1799> inventory, class_1799 source) {
        for (class_1799 target : inventory) {
            if (source.method_7960()) return true;
            if (target.method_7960() || !class_1799.method_31577(source, target)) continue;
            int room = target.method_7909().method_7882() - target.method_7947();
            int moved = Math.min(room, source.method_7947());
            target.method_7933(moved);
            source.method_7934(moved);
        }
        for (int slot = 0; slot < inventory.size() && !source.method_7960(); slot++) {
            if (!inventory.get(slot).method_7960()) continue;
            int moved = Math.min(source.method_7909().method_7882(), source.method_7947());
            inventory.set(slot, source.method_46651(moved));
            source.method_7934(moved);
        }
        return source.method_7960();
    }
}
