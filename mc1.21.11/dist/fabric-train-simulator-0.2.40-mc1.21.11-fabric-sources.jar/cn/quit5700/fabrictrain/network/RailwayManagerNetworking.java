package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.registry.ModItems;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;

public final class RailwayManagerNetworking {
    private RailwayManagerNetworking() {}
    public static final int CREATE=0, ADD=1, MOVE=2, REMOVE=3, DIRECTION=4, RENAME=5, DELETE=6;

    public static void registerServer() {
        PayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(SelectPayload.ID, SelectPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(EditPayload.ID, EditPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ClosePayload.ID, ClosePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SelectPayload.ID, (payload, context) -> context.server().execute(() -> select(context.player(), payload)));
        ServerPlayNetworking.registerGlobalReceiver(EditPayload.ID, (payload, context) -> context.server().execute(() -> edit(context.player(), payload)));
        ServerPlayNetworking.registerGlobalReceiver(ClosePayload.ID, (payload, context) ->
                context.server().execute(() -> DepotRemoteAccessSessions.revokeAll(context.player().method_5667())));
    }

    private static void select(class_3222 player, SelectPayload payload) {
        if (!hasManagerAccess(player)) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(net.minecraft.class_2561.method_43471(
                    "message.fabric_train_simulator.depot.remote_access_expired"));
            return;
        }
        RailwaySavedData data=RailwayDataManager.state(player.method_51469());
        if(payload.device()) {
            RailwayDevice device=data.device(payload.id()); if(device==null)return;
            if(device.type()==DeviceType.DEPOT) {
                for(class_3218 level:player.method_51469().method_8503().method_3738()) {
                    if(!RailwayDataManager.dimension(level).equals(device.dimension()))continue;
                    class_2338 pos=new class_2338(device.x(),device.y(),device.z());
                    if(level.method_8321(pos) instanceof TrainDepotBlockEntity depot) {
                        DepotRemoteAccessSessions.authorize(player.method_5667(), device.dimension(), pos, System.nanoTime());
                        DepotNetworking.open(player,pos,depot);
                    }
                }
            } else DeviceSettingsNetworking.open(player,device);
        } else {cn.quit5700.fabrictrain.item.LineSetterItem.select(player.method_5667(),payload.id());open(player, payload.id());}
    }

    private static void edit(class_3222 player, EditPayload payload) {
        boolean authorized = hasManagerAccess(player);
        if (!authorized) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(net.minecraft.class_2561.method_43471(
                    "message.fabric_train_simulator.depot.remote_access_expired"));
            return;
        }
        RailwaySavedData data=RailwayDataManager.state(player.method_51469());
        try {
            switch(payload.operation()) {
                case CREATE -> {
                    RailwayLine created=data.createEmptyLine(payload.text());
                    open(player,created.id());
                    return;
                }
                case ADD -> data.insertLineNode(payload.lineId(),payload.index(),payload.deviceId());
                case MOVE -> { int from=payload.index(),to=payload.value(); while(from>to){data.modifyLineNode(payload.lineId(),from,0);from--;}while(from<to){data.modifyLineNode(payload.lineId(),from,1);from++;} }
                case REMOVE -> data.modifyLineNode(payload.lineId(),payload.index(),2);
                case DIRECTION -> data.setSwitchDirection(payload.lineId(),payload.index(),payload.value());
                case RENAME -> { RailwayLine line=data.line(payload.lineId()); if(line!=null){data.updateLineSettings(line.id(),payload.text(),line.departureIntervalSeconds(),line.speedLimitKmh(),line.maximumTrains(),LineStatus.NEEDS_VALIDATION);open(player,0,"screen.fabric_train_simulator.manager.saved");return;} }
                case DELETE -> { LineDeletionService.delete(player.method_51469().method_8503(), (class_3218) player.method_51469(), payload.lineId()); open(player,0); return; }
                default -> { return; }
            }
        } catch (IllegalArgumentException ignored) { }
        open(player,payload.lineId());
    }

    public static void open(class_3222 player) { open(player,0,""); }
    public static void open(class_3222 player,long selectedLineId) { open(player,selectedLineId,""); }
    private static void open(class_3222 player,long selectedLineId,String statusMessageKey) {
        DepotRemoteAccessSessions.authorizeManager(player.method_5667(), System.nanoTime());
        RailwaySavedData data=RailwayDataManager.state(player.method_51469());
        List<DeviceSummary> devices=data.devices().values().stream().sorted(java.util.Comparator.comparingLong(RailwayDevice::id)).map(d->new DeviceSummary(d.id(),d.type().ordinal(),d.name())).toList();
        List<LineSummary> lines=data.lines().values().stream().sorted(java.util.Comparator.comparingLong(RailwayLine::id)).map(l->{
            List<Integer> directions=new ArrayList<>(l.nodeIds().size()); for(int i=0;i<l.nodeIds().size();i++) directions.add(l.switchDirection(i));
            List<StopSummary> stops=new ArrayList<>(l.nodeIds().size());
            for(int i=0;i<l.nodeIds().size();i++){StopTrack stop=l.stationStopTrack(i);stops.add(stop==null
                    ?new StopSummary(false,0,0,0):new StopSummary(true,stop.x(),stop.y(),stop.z()));}
            return new LineSummary(l.id(),l.name(),l.status().ordinal(),data.activeTrainCount(l.id()),l.maximumTrains(),l.nodeIds(),directions,stops);
        }).toList();
        ServerPlayNetworking.send(player,new OpenPayload(devices,lines,selectedLineId,statusMessageKey));
    }
    private static boolean hasManagerAccess(class_3222 player) {
        boolean holdingSetter = player.method_6047().method_31574(ModItems.LINE_SETTER)
                || player.method_6079().method_31574(ModItems.LINE_SETTER);
        return restoreManagerAccess(player.method_5667(), System.nanoTime(), holdingSetter);
    }
    static boolean restoreManagerAccess(java.util.UUID playerId, long nowNanos, boolean holdingSetter) {
        if (DepotRemoteAccessSessions.hasManagerAccess(playerId, nowNanos)) return true;
        if (!holdingSetter) return false;
        DepotRemoteAccessSessions.authorizeManager(playerId, nowNanos);
        return true;
    }
    public record DeviceSummary(long id,int type,String name) {}
    public record StopSummary(boolean bound,int x,int y,int z) {}
    public record LineSummary(long id,String name,int status,long active,int maximum,List<Long> nodes,List<Integer> directions,List<StopSummary> stops) {}
    public record OpenPayload(List<DeviceSummary> devices,List<LineSummary> lines,long selectedLineId,String statusMessageKey) implements class_8710 {
        public static final class_9154<OpenPayload> ID=new class_9154<>(FabricTrainMod.id("open_railway_manager"));
        public static final class_9139<class_9129,OpenPayload> CODEC=class_8710.method_56484(OpenPayload::write,OpenPayload::read);
        private void write(class_9129 b){b.method_10804(devices.size());for(DeviceSummary d:devices){b.method_10791(d.id());b.method_10804(d.type());b.method_10788(d.name(),64);}b.method_10804(lines.size());for(LineSummary l:lines){b.method_10791(l.id());b.method_10788(l.name(),64);b.method_10804(l.status());b.method_10791(l.active());b.method_10804(l.maximum());b.method_10804(l.nodes().size());for(int i=0;i<l.nodes().size();i++){b.method_10791(l.nodes().get(i));b.method_10804(l.directions().get(i));StopSummary s=l.stops().get(i);b.method_52964(s.bound());if(s.bound()){b.method_53002(s.x());b.method_53002(s.y());b.method_53002(s.z());}}}b.method_10791(selectedLineId);b.method_10788(statusMessageKey,128);}
        private static OpenPayload read(class_9129 b){int dc=Math.clamp(b.method_10816(),0,10000);ArrayList<DeviceSummary> ds=new ArrayList<>(dc);for(int i=0;i<dc;i++)ds.add(new DeviceSummary(b.method_10792(),b.method_10816(),b.method_10800(64)));int lc=Math.clamp(b.method_10816(),0,10000);ArrayList<LineSummary> ls=new ArrayList<>(lc);for(int i=0;i<lc;i++){long id=b.method_10792();String name=b.method_10800(64);int status=b.method_10816();long active=b.method_10792();int maximum=b.method_10816();int nc=Math.clamp(b.method_10816(),0,1000);ArrayList<Long> nodes=new ArrayList<>(nc);ArrayList<Integer> directions=new ArrayList<>(nc);ArrayList<StopSummary> stops=new ArrayList<>(nc);for(int j=0;j<nc;j++){nodes.add(b.method_10792());directions.add(b.method_10816());boolean bound=b.readBoolean();stops.add(bound?new StopSummary(true,b.readInt(),b.readInt(),b.readInt()):new StopSummary(false,0,0,0));}ls.add(new LineSummary(id,name,status,active,maximum,List.copyOf(nodes),List.copyOf(directions),List.copyOf(stops)));}return new OpenPayload(List.copyOf(ds),List.copyOf(ls),b.method_10792(),b.method_10800(128));}
        @Override public class_9154<? extends class_8710> method_56479(){return ID;}
    }
    public record SelectPayload(boolean device,long id) implements class_8710 {
        public static final class_9154<SelectPayload> ID=new class_9154<>(FabricTrainMod.id("select_railway_manager"));
        public static final class_9139<class_9129,SelectPayload> CODEC=class_8710.method_56484((p,b)->{b.method_52964(p.device);b.method_10791(p.id);},b->new SelectPayload(b.readBoolean(),b.method_10792()));
        @Override public class_9154<? extends class_8710> method_56479(){return ID;}
    }
    public record EditPayload(int operation,long lineId,long deviceId,int index,int value,String text) implements class_8710 {
        public static final class_9154<EditPayload> ID=new class_9154<>(FabricTrainMod.id("edit_railway_manager"));
        public static final class_9139<class_9129,EditPayload> CODEC=class_8710.method_56484((p,b)->{b.method_10804(p.operation);b.method_10791(p.lineId);b.method_10791(p.deviceId);b.method_10804(p.index);b.method_10804(p.value);b.method_10788(p.text,64);},b->new EditPayload(b.method_10816(),b.method_10792(),b.method_10792(),b.method_10816(),b.method_10816(),b.method_10800(64)));
        @Override public class_9154<? extends class_8710> method_56479(){return ID;}
    }
    public record ClosePayload() implements class_8710 {
        public static final class_9154<ClosePayload> ID = new class_9154<>(FabricTrainMod.id("close_railway_manager"));
        public static final class_9139<class_9129, ClosePayload> CODEC =
                class_8710.method_56484((payload, buffer) -> {}, buffer -> new ClosePayload());
        @Override public class_9154<? extends class_8710> method_56479() { return ID; }
    }
}

