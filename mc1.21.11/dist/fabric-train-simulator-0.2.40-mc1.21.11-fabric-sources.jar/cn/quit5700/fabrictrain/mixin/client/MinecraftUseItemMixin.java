package cn.quit5700.fabrictrain.mixin.client;

import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.train.DepotSettingsGesture;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_310.class, priority = 2000)
abstract class MinecraftUseItemMixin {
    @Inject(method = "startUseItem", at = @At("HEAD"), cancellable = true)
    private void fabricTrain$openDepotSettingsBeforeOtherInteractions(CallbackInfo callback) {
        class_310 minecraft = (class_310) (Object) this;
        if (minecraft.field_1687 == null || minecraft.field_1724 == null
                || !(minecraft.field_1765 instanceof class_3965 hit)) return;
        boolean control = class_3675.method_15987(minecraft.method_22683(), class_3675.field_31950)
                || class_3675.method_15987(minecraft.method_22683(), class_3675.field_31954);
        if (!control) return;
        var state = minecraft.field_1687.method_8320(hit.method_17777());
        if (state.method_27852(ModBlocks.TRAIN_DEPOT)) {
            if (DepotSettingsGesture.tryOpen(hit.method_17777())) callback.cancel();
            return;
        }
        if (state.method_27852(ModBlocks.STATION_MARKER) || state.method_27852(ModBlocks.SWITCH_RAIL)) {
            ClientPlayNetworking.send(new DeviceSettingsNetworking.RequestOpenPayload(hit.method_17777()));
            callback.cancel();
        }
    }
}
