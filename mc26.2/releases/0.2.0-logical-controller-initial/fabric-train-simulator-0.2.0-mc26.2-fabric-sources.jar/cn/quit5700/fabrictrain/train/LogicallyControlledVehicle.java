package cn.quit5700.fabrictrain.train;

public interface LogicallyControlledVehicle {
    boolean fabricTrain$isLogicallyControlled();
    void fabricTrain$setLogicallyControlled(boolean controlled);
}
