package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerPlayer;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.route.SwitchLockManager;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.cargo.CargoTransferService;
import cn.quit5700.fabrictrain.cargo.CargoLedgerService;
import cn.quit5700.fabrictrain.depot.DepotRecoveryService;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.level.block.state.properties.RailShape;
import cn.quit5700.fabrictrain.route.RuntimePathCache;
import cn.quit5700.fabrictrain.power.RailPowerService;
import net.minecraft.network.chat.Component;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;
import cn.quit5700.fabrictrain.registry.ModBlocks;

import java.util.*;

public final class TrainControllerManager {
    private static final double CAR_SPACING = 1.25D;
    private static final Map<UUID, TrackTrail> TRAILS = new HashMap<>();
    private static final Map<UUID, PausedTrain> PAUSED = new HashMap<>();
    private static final Map<UUID, RouteProgress> ROUTES = new HashMap<>();
    private static final Map<UUID, LogicalMotion> LOGICAL_MOTIONS = new HashMap<>();
    private static final SwitchLockManager SWITCH_LOCKS = new SwitchLockManager();
    private static long ticks;
    private static final Set<Long> EMERGENCY_STATIONS=new HashSet<>();
    private static final Map<UUID, Integer> CAR_ONLY_INPUT = new HashMap<>();
    private static final Map<UUID,ManualInput> MANUAL=new HashMap<>();
    private static final Map<UUID,ManualSwitch> MANUAL_SWITCHES=new HashMap<>();

    private TrainControllerManager() {
    }

    public static void tick(MinecraftServer server) {
        ticks++;
        Set<UUID> active = new HashSet<>();
        for (ServerLevel level : server.getAllLevels()) {
            Map<UUID, List<Entity>> trains = new HashMap<>();
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof LinkedTrainCar linked && !entity.isRemoved()) {
                    trains.computeIfAbsent(linked.trainLink().trainId(), ignored -> new ArrayList<>()).add(entity);
                }
            }
            trains.forEach((trainId, cars) -> {
                LinkedTrainCar sample = (LinkedTrainCar) cars.getFirst();
                RailwayDataManager.state(level).ensureTrain(trainId,
                        sample.trainLink().depotGenerated(), sample.trainLink().lineId());
                boolean hasLocomotive = cars.stream().anyMatch(LocomotiveEntity.class::isInstance);
                boolean controlled = hasLocomotive || cars.size() > 1;
                cars.forEach(entity -> {
                    if (entity instanceof LogicallyControlledVehicle vehicle)
                        vehicle.fabricTrain$setLogicallyControlled(controlled);
                });
                if (hasLocomotive) tickTrain(level, trainId, cars, active);
                else if (cars.size() > 1) tickCarOnlyGroup(level, trainId, cars, active);
            });
        }
        TRAILS.keySet().removeIf(id -> !active.contains(id));
        LOGICAL_MOTIONS.keySet().removeIf(id -> !active.contains(id));
        ROUTES.keySet().removeIf(id -> !active.contains(id));
        PAUSED.entrySet().removeIf(entry -> {
            if (entry.getValue().resumeAtTick() > ticks) return false;
            Entity entity = server.overworld().getEntityInAnyDimension(entry.getKey());
            if (entity instanceof LocomotiveEntity locomotive) {
                if(EMERGENCY_STATIONS.contains(locomotive.trainLink().lastDeviceId()))return false;
                locomotive.setDeltaMovement(entry.getValue().resumeVelocity());
                locomotive.trainLink().setAutomaticRunning(true);
            }
            return true;
        });
    }

    public static void drive(ServerPlayer player, Entity occupiedVehicle, boolean forward, boolean brake) {
        if (!(occupiedVehicle instanceof LinkedTrainCar occupiedCar)) return;
        if (occupiedCar.trainLink().depotGenerated()) {
            player.sendSystemMessage(Component.translatable("message.fabric_train_simulator.train.depot_controlled"));
            return;
        }
        UUID locomotiveId = occupiedCar.trainLink().locomotiveId();
        Entity found = player.level().getEntityInAnyDimension(locomotiveId);
        if (!(found instanceof LocomotiveEntity locomotive)) {
            if (occupiedCar.trainLink().hasLocomotive()) return;
            List<Entity> formation = TrainFormationService.formation(occupiedVehicle);
            if (formation.isEmpty() || formation.getFirst() != occupiedVehicle) return;
            int input = forward ? 1 : brake ? -1 : 0;
            CAR_ONLY_INPUT.put(occupiedCar.trainLink().trainId(), input);
            formation.forEach(entity -> {
                if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
                if (entity instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            });
            return;
        }
        if (!isDriver(player, occupiedCar.trainLink().trainId(), locomotive)) return;
        if (forward && railDirection(locomotive) == null) {
            player.sendSystemMessage(Component.translatable("message.fabric_train_simulator.train.not_on_rail"));
            return;
        }
        locomotive.trainLink().setParked(false);
        for (Entity entity : player.level().getAllEntities()) {
            if (entity instanceof LinkedTrainCar car
                    && car.trainLink().trainId().equals(occupiedCar.trainLink().trainId())) {
                car.trainLink().setParked(false);
                if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
                if (entity instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            }
        }
        PAUSED.remove(locomotiveId);
        if(forward){MANUAL.remove(locomotiveId);locomotive.trainLink().setAutomaticRunning(true);}
        else if(brake){locomotive.trainLink().setAutomaticRunning(false);MANUAL.put(locomotiveId,new ManualInput(false,true,ticks));}
        else if(MANUAL.remove(locomotiveId)!=null){locomotive.setDeltaMovement(Vec3.ZERO);PAUSED.put(locomotiveId,new PausedTrain(ticks+AutoResumeTimer.DEFAULT_DELAY_TICKS,direction(locomotive).scale(targetSpeed(locomotive))));}
    }

    public static void emergencyStopAt(long stationId){EMERGENCY_STATIONS.add(stationId);}
    public static void releaseEmergencyAt(long stationId){EMERGENCY_STATIONS.remove(stationId);}
    public static void departStation(MinecraftServer server,long stationId){
        EMERGENCY_STATIONS.remove(stationId);
        for(ServerLevel level:server.getAllLevels())for(Entity entity:level.getAllEntities())if(entity instanceof LocomotiveEntity locomotive&&locomotive.trainLink().lastDeviceId()==stationId){
            PausedTrain paused=PAUSED.remove(locomotive.getUUID());Vec3 velocity=paused==null?direction(locomotive).scale(targetSpeed(locomotive)):paused.resumeVelocity();locomotive.setDeltaMovement(velocity);locomotive.trainLink().setAutomaticRunning(true);
        }
    }
    public static void startLine(MinecraftServer server,long lineId){for(ServerLevel level:server.getAllLevels())for(Entity entity:level.getAllEntities())if(entity instanceof LocomotiveEntity locomotive&&locomotive.trainLink().lineId()==lineId){locomotive.trainLink().setAutomaticRunning(true);PAUSED.remove(locomotive.getUUID());}}

    private static boolean isDriver(ServerPlayer player, UUID trainId, LocomotiveEntity locomotive) {
        double playerDistance = player.distanceToSqr(locomotive);
        for (Entity passenger : locomotive.getPassengers())
            if (passenger instanceof ServerPlayer other && other != player
                    && other.distanceToSqr(locomotive) < playerDistance) return false;
        for (Entity entity : player.level().getAllEntities()) {
            if (entity instanceof PassengerCarEntity car
                    && car.trainLink().trainId().equals(trainId)
                    && car.getPassengers().stream().anyMatch(passenger ->
                    passenger instanceof ServerPlayer other && other != player
                            && other.distanceToSqr(locomotive) < playerDistance)) return false;
        }
        return true;
    }

    private static Vec3 direction(LocomotiveEntity locomotive) {
        double radians = Math.toRadians(locomotive.getYRot());
        return new Vec3(-Math.sin(radians), 0, Math.cos(radians));
    }

    private static Vec3 railDirection(LocomotiveEntity locomotive) {
        BlockPos railPos = locomotive.getCurrentBlockPosOrRailBelow();
        if (!BaseRailBlock.isRail(locomotive.level(), railPos)) return null;
        var state = locomotive.level().getBlockState(railPos);
        if (!state.hasProperty(RailBlock.SHAPE)) return null;
        var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
        return RailStartDirection.choose(exits.getFirst(), exits.getSecond(), direction(locomotive));
    }

    private static void tickTrain(ServerLevel level, UUID trainId, List<Entity> cars, Set<UUID> active) {
        LocomotiveEntity locomotive = cars.stream()
                .filter(LocomotiveEntity.class::isInstance)
                .map(LocomotiveEntity.class::cast)
                .findFirst().orElse(null);
        if (locomotive == null) return;
        active.add(trainId);
        if (locomotive.trainLink().lineId() > 0 && !net.minecraft.world.level.block.BaseRailBlock.isRail(
                level, locomotive.getCurrentBlockPosOrRailBelow())) {
            DerailedTrainRecoveryService.dropAsItems(level, cars);
            return;
        }
        if (locomotive.trainLink().loadedFromSave() && tryStartupRecovery(level, locomotive, cars)) return;
        RailwayLine operatingLine = RailwayDataManager.state(level).line(locomotive.trainLink().lineId());
        if (operatingLine == null && !prepareManualSwitch(level, locomotive, cars)) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return;
        }
        if (operatingLine != null && !RailPowerService.isPowered(level, locomotive.getCurrentBlockPosOrRailBelow())) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return;
        }
        if (operatingLine != null && operatingLine.status() == LineStatus.MAINTENANCE) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return;
        }
        if (!nextTrainChunkLoaded(level, locomotive)) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return;
        }
        boolean routeClear = prepareNextSwitch(level, locomotive, cars);
        if (routeClear) processLineNode(level, locomotive, cars);
        escrowUnloadedDestinations(level, locomotive, cars);
        TrackTrail trail = TRAILS.computeIfAbsent(trainId, ignored -> new TrackTrail(140.0D));
        if (!advanceLogicalTrain(level, trainId, locomotive, routeClear, trail)) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
        }
        cars.stream()
                .filter(entity -> entity != locomotive)
                .sorted(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()))
                .forEach(entity -> follow(level, locomotive, entity, trail));
    }

    private static boolean advanceLogicalTrain(ServerLevel level, UUID trainId, LocomotiveEntity locomotive,
                                               boolean routeClear, TrackTrail trail) {
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(trainId, ignored -> new LogicalMotion());
        ManualInput manual = MANUAL.get(locomotive.getUUID());
        double target = 0;
        if (routeClear && !PAUSED.containsKey(locomotive.getUUID())) {
            if (manual != null && manual.backward()) target = -targetSpeed(locomotive);
            else if (manual != null && manual.forward()) target = targetSpeed(locomotive);
            else if (locomotive.trainLink().automaticRunning()) target = targetSpeed(locomotive);
        }
        double speed = motion.speed.approach(target, 0.015D);
        if (Math.abs(speed) < 0.0001D) {
            locomotive.setDeltaMovement(Vec3.ZERO);
            return true;
        }
        if (motion.cursor == null) {
            motion.cursor = RailMotionCursor.create(level, locomotive, direction(locomotive));
            if (motion.cursor == null) {
                motion.speed.stop();
                locomotive.trainLink().setAutomaticRunning(false);
                return false;
            }
        }
        RailMotionCursor.Pose pose = motion.cursor.advance(level, speed);
        if (pose == null || !level.hasChunkAt(BlockPos.containing(pose.position()))) {
            motion.speed.stop();
            locomotive.trainLink().setAutomaticRunning(false);
            return false;
        }
        locomotive.setPos(pose.position());
        locomotive.setYRot(pose.yaw());
        locomotive.setXRot(0);
        locomotive.setDeltaMovement(Vec3.ZERO);
        trail.record(pose.position().x, pose.position().y, pose.position().z);
        return true;
    }

    private static void applyManual(LocomotiveEntity locomotive){ManualInput input=MANUAL.get(locomotive.getUUID());if(input==null||(!input.forward&&!input.backward))return;Vec3 forward=direction(locomotive);double signed=locomotive.getDeltaMovement().dot(forward);double target=(input.forward?1:-1)*targetSpeed(locomotive);double acceleration=0.015;double next=signed<target?Math.min(target,signed+acceleration):Math.max(target,signed-acceleration);if(Math.abs(next)<0.005)next=0;locomotive.setDeltaMovement(forward.scale(next));}

    private static void tickCarOnlyGroup(ServerLevel level, UUID trainId, List<Entity> cars, Set<UUID> active) {
        Entity leader = cars.stream().min(Comparator.comparingInt(entity ->
                ((LinkedTrainCar) entity).trainLink().carIndex())).orElse(null);
        if (leader == null) return;
        active.add(trainId);
        TrackTrail trail = TRAILS.computeIfAbsent(trainId, ignored -> new TrackTrail(140.0D));
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(trainId, ignored -> new LogicalMotion());
        int input = CAR_ONLY_INPUT.getOrDefault(trainId, 0);
        double limit = SpeedRules.blocksPerTick(SpeedRules.classLimit(
                ((LinkedTrainCar) leader).trainLink().trainClass()));
        double speed = motion.speed.approach(input * limit, 0.015D);
        if (Math.abs(speed) > 0.0001D && leader instanceof AbstractMinecart minecart) {
            if (motion.cursor == null) motion.cursor = RailMotionCursor.create(level, minecart, direction(leader));
            RailMotionCursor.Pose pose = motion.cursor == null ? null : motion.cursor.advance(level, speed);
            if (pose == null || !level.hasChunkAt(BlockPos.containing(pose.position()))) {
                motion.speed.stop();
                CAR_ONLY_INPUT.put(trainId, 0);
            } else {
                leader.setPos(pose.position());
                leader.setYRot(pose.yaw());
                leader.setDeltaMovement(Vec3.ZERO);
                trail.record(pose.position().x, pose.position().y, pose.position().z);
            }
        } else {
            leader.setDeltaMovement(Vec3.ZERO);
            trail.record(leader.getX(), leader.getY(), leader.getZ());
        }
        cars.stream().filter(entity -> entity != leader)
                .sorted(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()))
                .forEach(entity -> {
                    int index = Math.max(1, ((LinkedTrainCar) entity).trainLink().carIndex());
                    TrackTrail.Point target = trail.pointBehind(index * CAR_SPACING);
                    if (target == null) {
                        Vec3 anchor = FormationGeometry.anchor(leader.position(), entity.position(), index * CAR_SPACING);
                        entity.setPos(anchor);
                    } else entity.setPos(target.x(), target.y(), target.z());
                    if (entity instanceof CargoCarEntity cargo) {
                        cargo.beginAuthorizedPush();
                        try { entity.setDeltaMovement(leader.getDeltaMovement()); }
                        finally { cargo.endAuthorizedPush(); }
                    } else entity.setDeltaMovement(leader.getDeltaMovement());
                });
    }

    private static Vec3 direction(Entity entity) {
        double radians = Math.toRadians(entity.getYRot());
        return new Vec3(-Math.sin(radians), 0, Math.cos(radians));
    }

    private static void maintainAutomaticSpeed(LocomotiveEntity locomotive) {
        if (!locomotive.trainLink().automaticRunning() || PAUSED.containsKey(locomotive.getUUID())) return;
        double target = targetSpeed(locomotive);
        Vec3 velocity = locomotive.getDeltaMovement();
        double horizontal = Math.sqrt(velocity.horizontalDistanceSqr());
        Vec3 travelDirection = horizontal > 0.001D
                ? new Vec3(velocity.x / horizontal, 0, velocity.z / horizontal)
                : railDirection(locomotive);
        if (travelDirection == null) {
            locomotive.setDeltaMovement(Vec3.ZERO);
            locomotive.trainLink().setAutomaticRunning(false);
            return;
        }
        double nextSpeed = Math.min(target, horizontal + 0.015D);
        locomotive.setDeltaMovement(travelDirection.x * nextSpeed, velocity.y, travelDirection.z * nextSpeed);
    }

    private static boolean nextTrainChunkLoaded(ServerLevel level, LocomotiveEntity locomotive) {
        Vec3 velocity = locomotive.getDeltaMovement();
        double horizontal = Math.sqrt(velocity.horizontalDistanceSqr());
        Vec3 travelDirection = horizontal > 0.001D
                ? new Vec3(velocity.x / horizontal, 0, velocity.z / horizontal)
                : direction(locomotive);
        double lookAhead = Math.max(1.0D, Math.max(horizontal, targetSpeed(locomotive)) + 0.5D);
        Vec3 next = locomotive.position().add(travelDirection.scale(lookAhead));
        return level.hasChunkAt(BlockPos.containing(next));
    }

    public static void noteInteraction(LinkedTrainCar car) {
        PausedTrain paused = PAUSED.get(car.trainLink().locomotiveId());
        if (paused != null) PAUSED.put(car.trainLink().locomotiveId(), new PausedTrain(
                ticks + AutoResumeTimer.DEFAULT_DELAY_TICKS, paused.resumeVelocity()));
    }

    public static void resetFormation(UUID trainId, List<Entity> cars) {
        TRAILS.remove(trainId);
        LOGICAL_MOTIONS.remove(trainId);
        ROUTES.remove(trainId);
        cars.stream().filter(LocomotiveEntity.class::isInstance).findFirst().ifPresent(locomotive -> {
            MANUAL.remove(locomotive.getUUID());
            PAUSED.remove(locomotive.getUUID());
        });
        cars.forEach(car -> {
            car.setDeltaMovement(Vec3.ZERO);
            if (car instanceof LinkedTrainCar linked) {
                linked.trainLink().setAutomaticRunning(false);
                linked.trainLink().setParked(true);
            }
            if (car instanceof LogicallyControlledVehicle vehicle)
                vehicle.fabricTrain$setLogicallyControlled(cars.stream().anyMatch(LocomotiveEntity.class::isInstance)
                        || cars.size() > 1);
        });
        TrackTrail trail = new TrackTrail(140.0D);
        cars.stream()
                .sorted(Comparator.comparingInt(entity ->
                        ((LinkedTrainCar) entity).trainLink().carIndex()).reversed())
                .forEach(entity -> trail.record(entity.getX(), entity.getY(), entity.getZ()));
        TRAILS.put(trainId, trail);
    }

    public static void detachLine(MinecraftServer server, long lineId) {
        for (ServerLevel level : server.getAllLevels()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof LinkedTrainCar linked) || linked.trainLink().lineId() != lineId) continue;
                UUID trainId = linked.trainLink().trainId();
                SWITCH_LOCKS.releaseAll(trainId);
                PAUSED.remove(linked.trainLink().locomotiveId());
                linked.trainLink().detachFromLine();
                data.unregisterActiveTrain(trainId);
            }
        }
    }

    private static boolean prepareNextSwitch(ServerLevel level, LocomotiveEntity locomotive, List<Entity> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(locomotive.trainLink().lineId());
        if (line == null || line.nodeIds().isEmpty()) return true;
        RouteProgress progress = routeProgress(locomotive);
        int nextIndex = Math.min(progress.nextNodeIndex, line.nodeIds().size() - 1);
        RailwayDevice next = data.device(line.nodeIds().get(nextIndex));
        if (next == null || next.type() != DeviceType.SWITCH
                || !next.dimension().equals(RailwayDataManager.dimension(level))) return true;
        BlockPos pos = new BlockPos(next.x(), next.y(), next.z());
        if (locomotive.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0D) return true;
        UUID trainId = locomotive.trainLink().trainId();
        if (!SWITCH_LOCKS.tryAcquire(next.id(), trainId)) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return false;
        }
        if (progress.lockedSwitchId != 0 && progress.lockedSwitchId != next.id()) {
            SWITCH_LOCKS.release(progress.lockedSwitchId, trainId);
        }
        progress.lockedSwitchId = next.id();
        syncRouteProgress(locomotive, progress);
        if (level.hasChunkAt(pos) && level.getBlockState(pos).hasProperty(RailBlock.SHAPE)) {
            level.setBlock(pos, level.getBlockState(pos).setValue(RailBlock.SHAPE,
                    SwitchRailRouting.shapeFor(travelDirection(locomotive), line.switchDirection(nextIndex) >= 0
                            ? line.switchDirection(nextIndex) : next.switchShapeOrdinal())), 3);
        }
        return true;
    }

    private static net.minecraft.core.Direction travelDirection(LocomotiveEntity locomotive) {
        Vec3 velocity = locomotive.getDeltaMovement();
        Vec3 movement = velocity.horizontalDistanceSqr() > 0.0001D ? velocity : direction(locomotive);
        return Math.abs(movement.x) >= Math.abs(movement.z)
                ? (movement.x >= 0 ? net.minecraft.core.Direction.EAST : net.minecraft.core.Direction.WEST)
                : (movement.z >= 0 ? net.minecraft.core.Direction.SOUTH : net.minecraft.core.Direction.NORTH);
    }

    private static boolean prepareManualSwitch(ServerLevel level, LocomotiveEntity locomotive, List<Entity> cars) {
        net.minecraft.core.Direction travel = travelDirection(locomotive);
        BlockPos railPos = locomotive.getCurrentBlockPosOrRailBelow();
        RailwaySavedData data = RailwayDataManager.state(level);
        UUID trainId = locomotive.trainLink().trainId();
        ManualSwitch held = MANUAL_SWITCHES.get(trainId);
        if (held != null && cars.stream().noneMatch(car ->
                car.distanceToSqr(Vec3.atCenterOf(held.pos())) <= 16.0D)) {
            SWITCH_LOCKS.release(held.deviceId(), trainId);
            MANUAL_SWITCHES.remove(trainId);
        }
        for (int distance = 0; distance <= 2; distance++) {
            BlockPos pos = railPos.relative(travel, distance);
            if (!level.getBlockState(pos).is(ModBlocks.SWITCH_RAIL)) continue;
            RailwayDevice device = data.find(RailwayDataManager.dimension(level), pos.getX(), pos.getY(), pos.getZ());
            if (device != null) {
                if (!SWITCH_LOCKS.tryAcquire(device.id(), trainId)) return false;
                RailShape shape = SwitchRailRouting.shapeFor(travel, device.switchShapeOrdinal());
                var exits = net.minecraft.world.entity.vehicle.minecart.AbstractMinecart.exits(shape);
                boolean connected = net.minecraft.world.level.block.BaseRailBlock.isRail(level, pos.offset(exits.getFirst()))
                        && net.minecraft.world.level.block.BaseRailBlock.isRail(level, pos.offset(exits.getSecond()));
                if (!connected) return false;
                level.setBlock(pos, level.getBlockState(pos).setValue(RailBlock.SHAPE, shape), 3);
                MANUAL_SWITCHES.put(trainId, new ManualSwitch(device.id(), pos));
            }
            return true;
        }
        return true;
    }

    private static void escrowUnloadedDestinations(ServerLevel level, LocomotiveEntity locomotive, List<Entity> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        for (Entity entity : cars) {
            if (!(entity instanceof CargoCarEntity cargo) || cargo.destinationStationId() <= 0 || cargo.isEmpty()) continue;
            RailwayDevice station = data.device(cargo.destinationStationId());
            if (station == null || !station.dimension().equals(RailwayDataManager.dimension(level))) continue;
            BlockPos destination = new BlockPos(station.x(), station.y(), station.z());
            if (level.hasChunkAt(destination)) continue;
            double blocksPerTick = Math.max(0.001D, targetSpeed(locomotive));
            long travelTicks = Math.max(20L, (long) Math.ceil(Math.sqrt(locomotive.distanceToSqr(Vec3.atCenterOf(destination))) / blocksPerTick));
            CargoLedgerService.escrow(level, cargo, station.id(), level.getGameTime() + travelTicks);
        }
    }

    private static double targetSpeed(LocomotiveEntity locomotive) {
        double lineLimit = Double.MAX_VALUE;
        if (locomotive.level() instanceof ServerLevel level) {
            RailwayLine line = RailwayDataManager.state(level).line(locomotive.trainLink().lineId());
            if (line != null) lineLimit = line.speedLimitKmh();
        }
        double classLimit = locomotive.level() instanceof ServerLevel level
                ? RailwayDataManager.state(level).classSpeedLimit(locomotive.trainLink().trainClass())
                : SpeedRules.classLimit(locomotive.trainLink().trainClass());
        return SpeedRules.blocksPerTick(SpeedRules.actualSpeed(lineLimit, classLimit));
    }

    private static void enforceSpeedLimit(ServerLevel level, LocomotiveEntity locomotive) {
        Vec3 velocity = locomotive.getDeltaMovement();
        double horizontal = Math.sqrt(velocity.horizontalDistanceSqr());
        double maximum = targetSpeed(locomotive);
        if (horizontal > maximum && horizontal > 0) {
            locomotive.setDeltaMovement(velocity.x * maximum / horizontal, velocity.y, velocity.z * maximum / horizontal);
        }
    }

    private static boolean tryStartupRecovery(ServerLevel level, LocomotiveEntity locomotive, List<Entity> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(locomotive.trainLink().lineId());
        if (line == null) {
            locomotive.trainLink().markStartupRecovered();
            return false;
        }
        data.registerActiveTrain(locomotive.trainLink().trainId(), line.id());
        RailwayDevice depotDevice = data.device(line.depotId());
        if (depotDevice == null || !depotDevice.dimension().equals(RailwayDataManager.dimension(level))) return false;
        BlockPos depotPos = new BlockPos(depotDevice.x(), depotDevice.y(), depotDevice.z());
        if (!level.hasChunkAt(depotPos)) {
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return true;
        }
        if (level.getBlockEntity(depotPos) instanceof TrainDepotBlockEntity depot) {
            if (DepotRecoveryService.recover(cars, depot)) return true;
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            return true;
        }
        return false;
    }

    private static void processLineNode(ServerLevel level, LocomotiveEntity locomotive, List<Entity> cars) {
        long lineId = locomotive.trainLink().lineId();
        if (lineId <= 0) return;
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(lineId);
        if (line == null || line.nodeIds().size() < 2) return;
        BlockPos railPos = locomotive.getCurrentBlockPosOrRailBelow();
        RailwayDevice current = data.find(RailwayDataManager.dimension(level), railPos.getX(), railPos.getY(), railPos.getZ());
        if (current == null) current = data.find(RailwayDataManager.dimension(level), railPos.getX(), railPos.getY() - 1, railPos.getZ());
        if (current == null) current = adjacentStation(data, level, railPos);
        RouteProgress progress = routeProgress(locomotive);
        if (current == null) {
            progress.lastDeviceId = 0;
            syncRouteProgress(locomotive, progress);
            return;
        }
        final RailwayDevice currentNode = current;
        if (current.id() == progress.lastDeviceId) return;
        int expectedIndex = Math.min(progress.nextNodeIndex, line.nodeIds().size() - 1);
        if (line.nodeIds().get(expectedIndex) != current.id()) return;
        progress.lastDeviceId = current.id();
        if (current.type() == DeviceType.STATION) {
            Vec3 velocity = locomotive.getDeltaMovement();
            if (velocity.horizontalDistanceSqr() < 0.0001D) velocity = direction(locomotive).scale(targetSpeed(locomotive));
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            PAUSED.put(locomotive.getUUID(), new PausedTrain(EMERGENCY_STATIONS.contains(current.id())?ticks+2:ticks + (long) current.dwellSeconds() * 20L, velocity));
            if(!current.announcement().isBlank())level.players().stream().filter(player->player.distanceToSqr(currentNode.x()+.5,currentNode.y()+.5,currentNode.z()+.5)<=1024).forEach(player->player.sendOverlayMessage(Component.literal(currentNode.announcement())));
            cars.stream().filter(CargoCarEntity.class::isInstance).map(CargoCarEntity.class::cast)
                    .filter(cargo -> cargo.destinationStationId() == currentNode.id())
                    .forEach(cargo -> {
                        CargoTransferService.unloadAtStation(level,
                                new BlockPos(currentNode.x(), currentNode.y(), currentNode.z()), cargo);
                        if (cargo.isEmpty()) cargo.setDestinationStationId(0L);
                    });
            progress.nextNodeIndex++;
        } else if (current.type() == DeviceType.SWITCH) {
            if (SWITCH_LOCKS.tryAcquire(current.id(), locomotive.trainLink().trainId())) {
                if (progress.lockedSwitchId != 0 && progress.lockedSwitchId != current.id()) {
                    SWITCH_LOCKS.release(progress.lockedSwitchId, locomotive.trainLink().trainId());
                }
                progress.lockedSwitchId = current.id();
                progress.nextNodeIndex++;
            } else {
                cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            }
        } else if (current.type() == DeviceType.DEPOT && expectedIndex == line.nodeIds().size() - 1) {
            BlockPos depotPos = new BlockPos(current.x(), current.y(), current.z());
            if (level.getBlockEntity(depotPos) instanceof TrainDepotBlockEntity depot
                    && DepotRecoveryService.recover(cars, depot)) {
                if (progress.lockedSwitchId != 0) SWITCH_LOCKS.release(progress.lockedSwitchId, locomotive.trainLink().trainId());
                return;
            }
            cars.forEach(car -> car.setDeltaMovement(Vec3.ZERO));
            locomotive.trainLink().setAutomaticRunning(false);
        } else {
            progress.nextNodeIndex++;
        }
        if (progress.nextNodeIndex >= line.nodeIds().size()) {
            progress.nextNodeIndex = isLoop(line, data) ? 1 : line.nodeIds().size() - 1;
        }
        syncRouteProgress(locomotive, progress);
    }

    private static RailwayDevice adjacentStation(RailwaySavedData data, ServerLevel level, BlockPos railPos) {
        String dimension = RailwayDataManager.dimension(level);
        for (net.minecraft.core.Direction direction : net.minecraft.core.Direction.Plane.HORIZONTAL) {
            BlockPos stationPos = railPos.relative(direction);
            RailwayDevice device = data.find(dimension, stationPos.getX(), stationPos.getY(), stationPos.getZ());
            if (device != null && device.type() == DeviceType.STATION) return device;
        }
        return null;
    }

    private static RouteProgress routeProgress(LocomotiveEntity locomotive) {
        return ROUTES.computeIfAbsent(locomotive.trainLink().trainId(), ignored -> new RouteProgress(
                locomotive.trainLink().nextNodeIndex(), locomotive.trainLink().lastDeviceId(), locomotive.trainLink().lockedSwitchId()));
    }

    private static void syncRouteProgress(LocomotiveEntity locomotive, RouteProgress progress) {
        locomotive.trainLink().updateRouteProgress(progress.nextNodeIndex, progress.lastDeviceId, progress.lockedSwitchId);
    }

    private static boolean isLoop(RailwayLine line, RailwaySavedData data) {
        List<Long> stations = line.nodeIds().stream()
                .filter(id -> data.device(id) != null && data.device(id).type() == DeviceType.STATION).toList();
        return stations.size() >= 2 && stations.getFirst().equals(stations.getLast());
    }

    private static void follow(ServerLevel level, LocomotiveEntity locomotive, Entity entity, TrackTrail trail) {
        int index = ((LinkedTrainCar) entity).trainLink().carIndex();
        if (index <= 0) return;
        TrackTrail.Point target = trail.pointBehind(index * CAR_SPACING);
        if (target == null) {
            entity.setDeltaMovement(Vec3.ZERO);
            return;
        }
        BlockPos targetPos = BlockPos.containing(target.x(), target.y(), target.z());
        if (!level.hasChunkAt(targetPos)) {
            entity.setDeltaMovement(Vec3.ZERO);
            return;
        }
        entity.setPos(target.x(), target.y(), target.z());
        TrackTrail.Point ahead = trail.pointBehind(Math.max(0, index * CAR_SPACING - 0.2D));
        if (ahead != null) {
            double dx = ahead.x() - target.x();
            double dz = ahead.z() - target.z();
            if (dx * dx + dz * dz > 0.000001D)
                entity.setYRot((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        entity.setDeltaMovement(Vec3.ZERO);
    }

    public static void clear() {
        TRAILS.clear();
        PAUSED.clear();
        ROUTES.clear();
        SWITCH_LOCKS.clearOnWorldRestart();
        EMERGENCY_STATIONS.clear();
        MANUAL.clear();
        LOGICAL_MOTIONS.clear();
        CAR_ONLY_INPUT.clear();
        RuntimePathCache.clear();
        ticks = 0;
    }

    private record PausedTrain(long resumeAtTick, Vec3 resumeVelocity) {}
    private record ManualInput(boolean forward,boolean backward,long changedAt){}
    private record ManualSwitch(long deviceId,BlockPos pos){}
    private static final class LogicalMotion {
        private final LogicalSpeedState speed = new LogicalSpeedState();
        private RailMotionCursor cursor;
    }
    private static final class RouteProgress {
        private int nextNodeIndex;
        private long lastDeviceId;
        private long lockedSwitchId;
        private RouteProgress(int nextNodeIndex, long lastDeviceId, long lockedSwitchId) {
            this.nextNodeIndex = Math.max(1, nextNodeIndex);
            this.lastDeviceId = lastDeviceId;
            this.lockedSwitchId = lockedSwitchId;
        }
    }
}
