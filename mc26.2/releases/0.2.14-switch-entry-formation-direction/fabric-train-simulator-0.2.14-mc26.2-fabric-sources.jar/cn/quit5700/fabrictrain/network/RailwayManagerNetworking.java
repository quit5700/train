package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;

public final class RailwayManagerNetworking {
    private RailwayManagerNetworking() {}
    public static final int CREATE=0, ADD=1, MOVE=2, REMOVE=3, DIRECTION=4, RENAME=5, DELETE=6;

    public static void registerServer() {
        PayloadTypeRegistry.clientboundPlay().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(SelectPayload.ID, SelectPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(EditPayload.ID, EditPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(SelectPayload.ID, (payload, context) -> context.server().execute(() -> select(context.player(), payload)));
        ServerPlayNetworking.registerGlobalReceiver(EditPayload.ID, (payload, context) -> context.server().execute(() -> edit(context.player(), payload)));
    }

    private static void select(ServerPlayer player, SelectPayload payload) {
        RailwaySavedData data=RailwayDataManager.state(player.level());
        if(payload.device()) {
            RailwayDevice device=data.device(payload.id()); if(device==null)return;
            if(device.type()==DeviceType.DEPOT) {
                for(ServerLevel level:player.level().getServer().getAllLevels()) {
                    if(!RailwayDataManager.dimension(level).equals(device.dimension()))continue;
                    BlockPos pos=new BlockPos(device.x(),device.y(),device.z());
                    if(level.getBlockEntity(pos) instanceof TrainDepotBlockEntity depot)
                        DepotNetworking.open(player,pos,depot);
                }
            } else DeviceSettingsNetworking.open(player,device);
        } else {cn.quit5700.fabrictrain.item.LineSetterItem.select(player.getUUID(),payload.id());open(player, payload.id());}
    }

    private static void edit(ServerPlayer player, EditPayload payload) {
        RailwaySavedData data=RailwayDataManager.state(player.level());
        try {
            switch(payload.operation()) {
                case CREATE -> { RailwayLine created=data.createEmptyLine(payload.text()); open(player,created.id()); return; }
                case ADD -> data.insertLineNode(payload.lineId(),payload.index(),payload.deviceId());
                case MOVE -> { int from=payload.index(),to=payload.value(); while(from>to){data.modifyLineNode(payload.lineId(),from,0);from--;}while(from<to){data.modifyLineNode(payload.lineId(),from,1);from++;} }
                case REMOVE -> data.modifyLineNode(payload.lineId(),payload.index(),2);
                case DIRECTION -> data.setSwitchDirection(payload.lineId(),payload.index(),payload.value());
                case RENAME -> { RailwayLine line=data.line(payload.lineId()); if(line!=null)data.updateLineSettings(line.id(),payload.text(),line.departureIntervalSeconds(),line.speedLimitKmh(),line.maximumTrains(),LineStatus.NEEDS_VALIDATION); }
                case DELETE -> { LineDeletionService.delete(player.level().getServer(), (ServerLevel) player.level(), payload.lineId()); open(player,0); return; }
                default -> { return; }
            }
        } catch (IllegalArgumentException ignored) { }
        open(player,payload.lineId());
    }

    public static void open(ServerPlayer player) { open(player,0); }
    public static void open(ServerPlayer player,long selectedLineId) {
        RailwaySavedData data=RailwayDataManager.state(player.level());
        List<DeviceSummary> devices=data.devices().values().stream().sorted(java.util.Comparator.comparingLong(RailwayDevice::id)).map(d->new DeviceSummary(d.id(),d.type().ordinal(),d.name())).toList();
        List<LineSummary> lines=data.lines().values().stream().sorted(java.util.Comparator.comparingLong(RailwayLine::id)).map(l->{
            List<Integer> directions=new ArrayList<>(l.nodeIds().size()); for(int i=0;i<l.nodeIds().size();i++) directions.add(l.switchDirection(i));
            return new LineSummary(l.id(),l.name(),l.status().ordinal(),data.activeTrainCount(l.id()),l.maximumTrains(),l.nodeIds(),directions);
        }).toList();
        ServerPlayNetworking.send(player,new OpenPayload(devices,lines,selectedLineId));
    }
    public record DeviceSummary(long id,int type,String name) {}
    public record LineSummary(long id,String name,int status,long active,int maximum,List<Long> nodes,List<Integer> directions) {}
    public record OpenPayload(List<DeviceSummary> devices,List<LineSummary> lines,long selectedLineId) implements CustomPacketPayload {
        public static final Type<OpenPayload> ID=new Type<>(FabricTrainMod.id("open_railway_manager"));
        public static final StreamCodec<RegistryFriendlyByteBuf,OpenPayload> CODEC=CustomPacketPayload.codec(OpenPayload::write,OpenPayload::read);
        private void write(RegistryFriendlyByteBuf b){b.writeVarInt(devices.size());for(DeviceSummary d:devices){b.writeVarLong(d.id());b.writeVarInt(d.type());b.writeUtf(d.name(),64);}b.writeVarInt(lines.size());for(LineSummary l:lines){b.writeVarLong(l.id());b.writeUtf(l.name(),64);b.writeVarInt(l.status());b.writeVarLong(l.active());b.writeVarInt(l.maximum());b.writeVarInt(l.nodes().size());for(int i=0;i<l.nodes().size();i++){b.writeVarLong(l.nodes().get(i));b.writeVarInt(l.directions().get(i));}}b.writeVarLong(selectedLineId);}
        private static OpenPayload read(RegistryFriendlyByteBuf b){int dc=Math.clamp(b.readVarInt(),0,10000);ArrayList<DeviceSummary> ds=new ArrayList<>(dc);for(int i=0;i<dc;i++)ds.add(new DeviceSummary(b.readVarLong(),b.readVarInt(),b.readUtf(64)));int lc=Math.clamp(b.readVarInt(),0,10000);ArrayList<LineSummary> ls=new ArrayList<>(lc);for(int i=0;i<lc;i++){long id=b.readVarLong();String name=b.readUtf(64);int status=b.readVarInt();long active=b.readVarLong();int maximum=b.readVarInt();int nc=Math.clamp(b.readVarInt(),0,1000);ArrayList<Long> nodes=new ArrayList<>(nc);ArrayList<Integer> directions=new ArrayList<>(nc);for(int j=0;j<nc;j++){nodes.add(b.readVarLong());directions.add(b.readVarInt());}ls.add(new LineSummary(id,name,status,active,maximum,List.copyOf(nodes),List.copyOf(directions)));}return new OpenPayload(List.copyOf(ds),List.copyOf(ls),b.readVarLong());}
        @Override public Type<? extends CustomPacketPayload> type(){return ID;}
    }
    public record SelectPayload(boolean device,long id) implements CustomPacketPayload {
        public static final Type<SelectPayload> ID=new Type<>(FabricTrainMod.id("select_railway_manager"));
        public static final StreamCodec<RegistryFriendlyByteBuf,SelectPayload> CODEC=CustomPacketPayload.codec((p,b)->{b.writeBoolean(p.device);b.writeVarLong(p.id);},b->new SelectPayload(b.readBoolean(),b.readVarLong()));
        @Override public Type<? extends CustomPacketPayload> type(){return ID;}
    }
    public record EditPayload(int operation,long lineId,long deviceId,int index,int value,String text) implements CustomPacketPayload {
        public static final Type<EditPayload> ID=new Type<>(FabricTrainMod.id("edit_railway_manager"));
        public static final StreamCodec<RegistryFriendlyByteBuf,EditPayload> CODEC=CustomPacketPayload.codec((p,b)->{b.writeVarInt(p.operation);b.writeVarLong(p.lineId);b.writeVarLong(p.deviceId);b.writeVarInt(p.index);b.writeVarInt(p.value);b.writeUtf(p.text,64);},b->new EditPayload(b.readVarInt(),b.readVarLong(),b.readVarLong(),b.readVarInt(),b.readVarInt(),b.readUtf(64)));
        @Override public Type<? extends CustomPacketPayload> type(){return ID;}
    }
}
