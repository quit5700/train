package cn.quit5700.fabrictrain.train;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.phys.Vec3;

import net.minecraft.core.Direction;
import java.util.Optional;

final class RailMotionCursor {
    private BlockPos previous;
    private BlockPos current;
    private BlockPos next;
    private double progress;

    private RailMotionCursor(BlockPos previous, BlockPos current, BlockPos next) {
        this.previous = previous;
        this.current = current;
        this.next = next;
    }

    static RailMotionCursor create(ServerLevel level, AbstractMinecart leader, Vec3 facing) {
        BlockPos current = railAt(level, leader.getCurrentBlockPosOrRailBelow());
        if (current == null) return null;
        var exits = exits(level, current);
        if (exits == null) return null;
        BlockPos first = railAt(level, current.offset(exits.getFirst()));
        BlockPos second = railAt(level, current.offset(exits.getSecond()));
        if (first == null && second == null) return null;
        BlockPos next;
        BlockPos previous;
        if (first == null) {
            next = second;
            previous = null;
        } else if (second == null) {
            next = first;
            previous = null;
        } else {
            Vec3 firstDirection = Vec3.atCenterOf(first).subtract(Vec3.atCenterOf(current)).normalize();
            Vec3 secondDirection = Vec3.atCenterOf(second).subtract(Vec3.atCenterOf(current)).normalize();
            if (firstDirection.dot(facing) >= secondDirection.dot(facing)) {
                next = first;
                previous = second;
            } else {
                next = second;
                previous = first;
            }
        }
        return new RailMotionCursor(previous, current, next);
    }

    Pose advance(ServerLevel level, double distance) {
        double remaining = distance;
        int budget = 32;
        while (Math.abs(remaining) > 0.000001D && budget-- > 0) {
            if (remaining > 0) {
                if (next == null) return null;
                double length = center(current).distanceTo(center(next));
                double available = Math.max(0, length - progress);
                if (remaining <= available) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining -= available;
                    BlockPos oldCurrent = current;
                    current = next;
                    previous = oldCurrent;
                    next = continuation(level, current, previous);
                    progress = 0;
                }
            } else {
                if (-remaining <= progress) {
                    progress += remaining;
                    remaining = 0;
                } else {
                    remaining += progress;
                    if (previous == null) return null;
                    BlockPos oldCurrent = current;
                    current = previous;
                    next = oldCurrent;
                    previous = continuation(level, current, next);
                    progress = center(current).distanceTo(center(next));
                }
            }
        }
        if (next == null) return new Pose(center(current), 0);
        Vec3 from = center(current);
        Vec3 to = center(next);
        double length = from.distanceTo(to);
        double ratio = length < 0.0001D ? 0 : Math.max(0, Math.min(1, progress / length));
        Vec3 position = from.lerp(to, ratio);
        Vec3 tangent = to.subtract(from);
        float yaw = (float) Math.toDegrees(Math.atan2(-tangent.x, tangent.z));
        return new Pose(position, yaw);
    }

    Optional<Direction> travelDirection(boolean forward) {
        BlockPos target=forward?next:previous;
        if(target==null)return Optional.empty();
        return FormationDirection.fromPositions(target.getX(),target.getZ(),current.getX(),current.getZ());
    }

    private static BlockPos continuation(ServerLevel level, BlockPos at, BlockPos cameFrom) {
        var exits = exits(level, at);
        if (exits == null) return null;
        BlockPos first = railAt(level, at.offset(exits.getFirst()));
        BlockPos second = railAt(level, at.offset(exits.getSecond()));
        if (first != null && !first.equals(cameFrom)) return first;
        if (second != null && !second.equals(cameFrom)) return second;
        return null;
    }

    private static com.mojang.datafixers.util.Pair<net.minecraft.core.Vec3i, net.minecraft.core.Vec3i> exits(
            ServerLevel level, BlockPos pos) {
        var state = level.getBlockState(pos);
        if (!state.hasProperty(RailBlock.SHAPE)) return null;
        return AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
    }

    private static BlockPos railAt(ServerLevel level, BlockPos pos) {
        if (BaseRailBlock.isRail(level, pos)) return pos;
        if (BaseRailBlock.isRail(level, pos.below())) return pos.below();
        if (BaseRailBlock.isRail(level, pos.above())) return pos.above();
        return null;
    }

    private static Vec3 center(BlockPos pos) {
        return Vec3.atBottomCenterOf(pos).add(0, 0.1D, 0);
    }

    record Pose(Vec3 position, float yaw) {}
}
