package cn.quit5700.fabrictrain.power;

import java.util.function.BooleanSupplier;

public final class GeneratorFuelState {
    private long activeUntilGameTime;
    private long legacyRemainingTicks;

    private GeneratorFuelState(long activeUntilGameTime, long legacyRemainingTicks) {
        this.activeUntilGameTime = Math.max(0L, activeUntilGameTime);
        this.legacyRemainingTicks = Math.max(0L, legacyRemainingTicks);
    }

    public static GeneratorFuelState empty() {
        return new GeneratorFuelState(0L, 0L);
    }

    public static GeneratorFuelState restore(long activeUntilGameTime, long legacyRemainingTicks) {
        return new GeneratorFuelState(activeUntilGameTime, activeUntilGameTime > 0L ? 0L : legacyRemainingTicks);
    }

    public boolean tryActivate(long currentGameTime, long durationTicks, BooleanSupplier commitFuel) {
        if (durationTicks <= 0L || isActive(currentGameTime)) return false;
        long previousUntil = activeUntilGameTime;
        activeUntilGameTime = saturatingAdd(Math.max(0L, currentGameTime), durationTicks);
        try {
            if (commitFuel.getAsBoolean()) {
                legacyRemainingTicks = 0L;
                return true;
            }
            activeUntilGameTime = previousUntil;
            return false;
        } catch (RuntimeException | Error failure) {
            activeUntilGameTime = previousUntil;
            throw failure;
        }
    }

    public boolean migrateLegacyRemaining(long currentGameTime) {
        if (activeUntilGameTime > 0L || legacyRemainingTicks <= 0L) return false;
        activeUntilGameTime = saturatingAdd(Math.max(0L, currentGameTime), legacyRemainingTicks);
        legacyRemainingTicks = 0L;
        return true;
    }

    public boolean isActive(long currentGameTime) {
        return activeUntilGameTime > Math.max(0L, currentGameTime);
    }

    public long remainingTicks(long currentGameTime) {
        if (activeUntilGameTime > 0L) return Math.max(0L, activeUntilGameTime - Math.max(0L, currentGameTime));
        return legacyRemainingTicks;
    }

    public long activeUntilGameTime() {
        return activeUntilGameTime;
    }

    private static long saturatingAdd(long left, long right) {
        if (right > Long.MAX_VALUE - left) return Long.MAX_VALUE;
        return left + right;
    }
}
