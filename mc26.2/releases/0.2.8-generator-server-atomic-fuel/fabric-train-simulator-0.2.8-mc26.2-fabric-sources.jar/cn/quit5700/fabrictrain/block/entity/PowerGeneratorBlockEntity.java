package cn.quit5700.fabrictrain.block.entity;

import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.power.GeneratorFuelState;
import cn.quit5700.fabrictrain.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class PowerGeneratorBlockEntity extends BaseContainerBlockEntity {
    private static final Logger LOGGER = LoggerFactory.getLogger(PowerGeneratorBlockEntity.class);
    private static final String FUEL_UNTIL_KEY = "FuelUntilGameTime";
    private static final String LEGACY_REMAINING_KEY = "RemainingFuelTicks";
    public static final int SIZE = 9;
    public static final long REDSTONE_DUST_TICKS = 72_000L;
    public static final long REDSTONE_BLOCK_TICKS = 504_000L;
    private NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
    private GeneratorFuelState fuelState = GeneratorFuelState.empty();
    private long lastObservedGameTime;
    private boolean active;

    public PowerGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.POWER_GENERATOR, pos, state);
    }

    public static void serverTick(ServerLevel level, BlockPos pos, BlockState state, PowerGeneratorBlockEntity generator) {
        long gameTime = level.getGameTime();
        generator.lastObservedGameTime = gameTime;
        boolean before = generator.active;
        boolean migrated = generator.fuelState.migrateLegacyRemaining(gameTime);
        generator.active = generator.fuelState.isActive(gameTime);
        boolean activated = !generator.active && generator.activateFuelIfAvailable(level, gameTime);
        generator.active = generator.fuelState.isActive(gameTime);
        RailPowerService.updateGenerator(level, pos, generator.active);
        if (before != generator.active || activated) {
            RailPowerService.refreshNow(level);
            generator.setChanged();
            level.updateNeighborsAt(pos, state.getBlock());
        } else if (migrated) {
            generator.setChanged();
        }
    }

    private boolean activateFuelIfAvailable(ServerLevel serverLevel, long gameTime) {
        for (ItemStack stack : items) {
            long fuelTicks = fuelDuration(stack);
            if (fuelTicks <= 0) continue;
            try {
                return fuelState.tryActivate(gameTime, fuelTicks, () -> {
                    RailPowerService.updateGenerator(serverLevel, worldPosition, true);
                    RailPowerService.refreshNow(serverLevel);
                    setChanged();
                    stack.shrink(1);
                    return true;
                });
            } catch (RuntimeException | Error failure) {
                RailPowerService.updateGenerator(serverLevel, worldPosition, false);
                LOGGER.error("铁路发电机燃料提交失败，燃料未扣除：{}", worldPosition, failure);
                return false;
            }
        }
        return false;
    }

    static long fuelDuration(ItemStack stack) {
        if (stack.is(Items.REDSTONE_BLOCK)) return REDSTONE_BLOCK_TICKS;
        if (stack.is(Items.REDSTONE)) return REDSTONE_DUST_TICKS;
        return 0L;
    }

    public boolean active() { return active; }
    public long remainingTicks() { return fuelState.remainingTicks(lastObservedGameTime); }
    @Override public int getContainerSize() { return SIZE; }
    @Override protected NonNullList<ItemStack> getItems() { return items; }
    @Override protected void setItems(NonNullList<ItemStack> value) { items = value; }
    @Override protected Component getDefaultName() {
        long remainingTicks = remainingTicks();
        Component status = remainingTicks > 0
                ? Component.translatable("container.fabric_train_simulator.power_generator.remaining", formatRemainingTime())
                : Component.translatable("container.fabric_train_simulator.power_generator.offline");
        return Component.translatable("container.fabric_train_simulator.power_generator", status);
    }
    @Override protected AbstractContainerMenu createMenu(int syncId, Inventory inventory) { return ChestMenu.oneRow(syncId, inventory); }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) {
        return stack.is(Items.REDSTONE) || stack.is(Items.REDSTONE_BLOCK);
    }
    @Override public boolean canTakeItem(Container destination, int slot, ItemStack stack) { return !active; }

    private String formatRemainingTime() {
        long seconds = remainingTicks() / 20L;
        return String.format(java.util.Locale.ROOT, "%02d:%02d:%02d", seconds / 3600L,
                (seconds % 3600L) / 60L, seconds % 60L);
    }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        ContainerHelper.saveAllItems(output, items);
        output.putLong(FUEL_UNTIL_KEY, fuelState.activeUntilGameTime());
        output.putLong(LEGACY_REMAINING_KEY, remainingTicks());
    }

    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(input, items);
        long activeUntil = input.getLongOr(FUEL_UNTIL_KEY, 0L);
        long legacyRemaining = input.getLongOr(LEGACY_REMAINING_KEY, 0L);
        fuelState = GeneratorFuelState.restore(activeUntil, legacyRemaining);
        lastObservedGameTime = 0L;
        active = activeUntil > 0L || legacyRemaining > 0L;
    }
}
