package cn.quit5700.fabrictrain.data;

import net.minecraft.nbt.CompoundTag;

/**
 * Old saves have no presence marker. They remain as hidden identities so a train entity loaded
 * later can reclaim its stable number without putting historical records back in the visible list.
 */
public final class TrainRecordPresence {
    public static final int CURRENT_FORMAT = 2;

    private TrainRecordPresence() {}

    public static boolean read(CompoundTag entry) {
        return entry.getBooleanOr("Present", false);
    }

    public static boolean read(CompoundTag entry, int storedFormat) {
        return storedFormat >= CURRENT_FORMAT && read(entry);
    }
}
