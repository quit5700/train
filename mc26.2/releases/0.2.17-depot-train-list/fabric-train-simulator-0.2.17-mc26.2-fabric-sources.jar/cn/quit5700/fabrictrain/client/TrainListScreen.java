package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.DepotNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class TrainListScreen extends Screen {
    private static final int PANEL_WIDTH = 260;
    private static final int ROW_HEIGHT = 16;
    private final List<DepotNetworking.TrainListEntry> trains;
    private int scrollOffset;

    public TrainListScreen(DepotNetworking.TrainListPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.train_list.title"));
        trains = payload.trains();
    }

    private ResponsiveScreenLayout layout() {
        int desiredHeight = Math.max(110, 74 + trains.size() * ROW_HEIGHT);
        return ResponsiveScreenLayout.of(width, height, PANEL_WIDTH, desiredHeight, 20);
    }

    @Override
    protected void init() {
        ResponsiveScreenLayout layout = layout();
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.train_list.close"),
                button -> onClose()).bounds(layout.left() + 10, layout.footerY(), layout.panelWidth() - 20, 20).build());
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        ResponsiveScreenLayout layout = layout();
        int visibleHeight = Math.max(ROW_HEIGHT, layout.scrollBottom() - layout.scrollTop());
        int contentHeight = Math.max(ROW_HEIGHT, trains.size() * ROW_HEIGHT);
        int maximumOffset = Math.max(0, contentHeight - visibleHeight);
        int next = Math.clamp(scrollOffset - (int) Math.signum(vertical) * ROW_HEIGHT, 0, maximumOffset);
        if (next == scrollOffset) return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
        scrollOffset = next;
        return true;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = layout();
        graphics.fill(layout.left(), layout.top(), layout.right(), layout.bottom(), 0xE020232A);
        graphics.outline(layout.left(), layout.top(), layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.centeredText(font, title, width / 2, layout.top() + 9, 0xFFFFFFFF);
        if (trains.isEmpty()) {
            graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.train_list.empty"),
                    width / 2, layout.scrollTop() + 12, 0xFFB8B8B8);
        } else {
            int y = layout.scrollTop() - scrollOffset;
            for (DepotNetworking.TrainListEntry train : trains) {
                if (y >= layout.scrollTop() && y + ROW_HEIGHT <= layout.scrollBottom()) {
                    Component mode = Component.translatable(train.automatic()
                            ? "screen.fabric_train_simulator.train_list.automatic"
                            : "screen.fabric_train_simulator.train_list.manual");
                    graphics.text(font, Component.translatable("screen.fabric_train_simulator.train_list.item",
                            train.number(), mode), layout.left() + 16, y + 3, 0xFFE6E6E6);
                }
                y += ROW_HEIGHT;
            }
        }
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }
}
