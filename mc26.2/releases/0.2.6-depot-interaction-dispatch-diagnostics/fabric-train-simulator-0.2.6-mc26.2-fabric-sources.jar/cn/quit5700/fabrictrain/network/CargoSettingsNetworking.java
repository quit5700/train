package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.Entity;

import java.util.List;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;

public final class CargoSettingsNetworking {
    private CargoSettingsNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.clientboundPlay().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            Entity entity = context.player().level().getEntity(payload.entityId());
            if (!(entity instanceof CargoCarEntity cargo) || context.player().distanceToSqr(entity) > 64.0D) return;
            var data=RailwayDataManager.state(context.player().level());
            if(StationSelectionService.canSelect(data,cargo.trainLink(),payload.stationId()))
                cargo.setDestinationStationId(payload.stationId());
        }));
    }

    public record Station(long id, String name, int etaSeconds) {}

    public record OpenPayload(int entityId, long selectedStationId, List<Station> stations) implements CustomPacketPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_cargo_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenPayload> CODEC = CustomPacketPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(RegistryFriendlyByteBuf b) {
            b.writeVarInt(entityId); b.writeVarLong(selectedStationId); b.writeVarInt(stations.size());
            for (Station station : stations) { b.writeVarLong(station.id()); b.writeUtf(station.name(), 128); b.writeVarInt(station.etaSeconds()); }
        }
        private static OpenPayload read(RegistryFriendlyByteBuf b) {
            int entityId = b.readVarInt(); long selected = b.readVarLong(); int size = Math.clamp(b.readVarInt(), 0, 1000);
            java.util.ArrayList<Station> stations = new java.util.ArrayList<>(size);
            for (int i = 0; i < size; i++) stations.add(new Station(b.readVarLong(), b.readUtf(128), b.readVarInt()));
            return new OpenPayload(entityId, selected, List.copyOf(stations));
        }
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }

    public record UpdatePayload(int entityId, long stationId) implements CustomPacketPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_cargo_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UpdatePayload> CODEC = CustomPacketPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(RegistryFriendlyByteBuf b) { b.writeVarInt(entityId); b.writeVarLong(stationId); }
        private static UpdatePayload read(RegistryFriendlyByteBuf b) { return new UpdatePayload(b.readVarInt(), b.readVarLong()); }
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }
}
