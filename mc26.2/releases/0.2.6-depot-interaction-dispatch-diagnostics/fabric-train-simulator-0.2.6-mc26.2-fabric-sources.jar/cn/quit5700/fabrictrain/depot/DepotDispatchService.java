package cn.quit5700.fabrictrain.depot;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.*;
import cn.quit5700.fabrictrain.registry.ModEntities;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.CarType;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.train.SpeedRules;
import cn.quit5700.fabrictrain.train.ControlMode;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.core.Vec3i;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.Container;
import net.minecraft.core.Direction;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.power.RailPowerService;

import java.util.*;

public final class DepotDispatchService {
    private static final Map<Long, Long> LAST_DISPATCH_TICK = new HashMap<>();
    private static long ticks;

    private DepotDispatchService() {}

    public static void tick(MinecraftServer server) {
        ticks++;
        if (ticks % 20 != 0) return;
        for (ServerLevel level : server.getAllLevels()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            for (RailwayDevice device : data.devices().values()) {
                if (device.type() != DeviceType.DEPOT
                        || !device.dimension().equals(RailwayDataManager.dimension(level))) continue;
                BlockPos pos = new BlockPos(device.x(), device.y(), device.z());
                if (level.hasChunkAt(pos) && level.getBlockEntity(pos) instanceof TrainDepotBlockEntity depot)
                    absorbConnectedVehicles(level, pos, depot);
            }
            for (RailwayLine line : data.lines().values()) {
                if (line.status() != LineStatus.RUNNING) continue;
                long last = LAST_DISPATCH_TICK.getOrDefault(line.id(), Long.MIN_VALUE / 2);
                RailwayDevice depot = data.device(line.depotId());
                if (depot == null || !depot.dimension().equals(RailwayDataManager.dimension(level))) continue;
                BlockPos depotPos = new BlockPos(depot.x(), depot.y(), depot.z());
                if (!level.hasChunkAt(depotPos) || !(level.getBlockEntity(depotPos) instanceof TrainDepotBlockEntity inventory)) continue;
                if (inventory.selectedLineId() != line.id() || data.activeTrainCount(line.id()) >= inventory.maximumTrains()) continue;
                if (ticks - last < (long) inventory.dispatchIntervalSeconds() * 20L) continue;
                if (dispatch(level, depotPos, line, inventory, true,ControlMode.ROUTE_AUTOMATIC).succeeded()) LAST_DISPATCH_TICK.put(line.id(), ticks);
            }
        }
    }

    public static int absorbConnectedVehicles(ServerLevel level, BlockPos pos, TrainDepotBlockEntity depot) {
        int moved = 0;
        for (Direction direction : Direction.values()) {
            if (!(level.getBlockEntity(pos.relative(direction)) instanceof Container source) || source == depot) continue;
            for (int slot=0;slot<source.getContainerSize();slot++) {
                ItemStack stack=source.getItem(slot);
                if (stack.isEmpty() || !(stack.is(ModItems.LOCOMOTIVE)
                        || stack.is(ModItems.PASSENGER_CAR) || stack.is(ModItems.CARGO_CAR))) continue;
                int before=stack.getCount();
                insertIntoDepot(depot,stack);
                if(before!=stack.getCount()){moved+=before-stack.getCount();source.setItem(slot,stack);source.setChanged();}
            }
        }
        if(moved>0)depot.setChanged();
        return moved;
    }

    private static void insertIntoDepot(TrainDepotBlockEntity depot,ItemStack source) {
        for(int slot=0;slot<depot.getContainerSize()&&!source.isEmpty();slot++){
            ItemStack target=depot.getItem(slot);
            if(target.isEmpty()||!ItemStack.isSameItemSameComponents(target,source))continue;
            int amount=Math.min(depot.getMaxStackSize(target)-target.getCount(),source.getCount());
            if(amount>0){target.grow(amount);source.shrink(amount);depot.setItem(slot,target);}
        }
        for(int slot=0;slot<depot.getContainerSize()&&!source.isEmpty();slot++){
            if(!depot.getItem(slot).isEmpty()||!depot.canPlaceItem(slot,source))continue;
            int amount=Math.min(depot.getMaxStackSize(source),source.getCount());
            depot.setItem(slot,source.copyWithCount(amount));source.shrink(amount);
        }
    }

    public static boolean dispatchNow(ServerLevel level, BlockPos depotPos, RailwayLine line,
                                      TrainDepotBlockEntity inventory, boolean consumeItems) {
        return dispatchNowDetailed(level, depotPos, line, inventory, consumeItems).succeeded();
    }

    public static DepotDispatchResult dispatchNowDetailed(ServerLevel level, BlockPos depotPos, RailwayLine line,
                                                          TrainDepotBlockEntity inventory, boolean consumeItems) {
        return dispatch(level, depotPos, line, inventory, consumeItems, ControlMode.MANUAL);
    }

    private static DepotDispatchResult dispatch(ServerLevel level, BlockPos depotPos, RailwayLine line,
                                                TrainDepotBlockEntity inventory, boolean consumeItems,
                                                ControlMode controlMode) {
        if(inventory.template().cars().isEmpty())return DepotDispatchResult.EMPTY_TEMPLATE;
        BlockPos railPos = depotPos.above();
        if (!BaseRailBlock.isRail(level, railPos)) return DepotDispatchResult.NO_RAIL;
        if (!RailPowerService.isPowered(level, railPos)) return DepotDispatchResult.UNPOWERED;
        List<Container> containers = connectedContainers(level, depotPos, inventory);
        if (consumeItems && (!has(containers, ModItems.LOCOMOTIVE, 1)
                || !has(containers, ModItems.PASSENGER_CAR,
                (int) inventory.template().cars().stream().filter(type -> type == CarType.PASSENGER).count())
                || !has(containers, ModItems.CARGO_CAR,
                (int) inventory.template().cars().stream().filter(type -> type == CarType.CARGO).count()))) {
            return DepotDispatchResult.MISSING_VEHICLE_ITEMS;
        }

        UUID trainId = UUID.randomUUID();
        RailShape railShape = level.getBlockState(railPos).getValue(RailBlock.SHAPE);
        var exits = AbstractMinecart.exits(railShape);
        boolean firstHasNode = reachesNode(level, railPos, exits.getFirst());
        boolean secondHasNode = reachesNode(level, railPos, exits.getSecond());
        int frontIndex = DepotDirectionRules.frontIndex(firstHasNode, secondHasNode);
        if (frontIndex < 0) return DepotDispatchResult.DIRECTION_UNRESOLVED;
        Vec3i exit = frontIndex == 0 ? exits.getFirst() : exits.getSecond();
        Vec3 forward = new Vec3(exit.getX(), exit.getY(), exit.getZ()).normalize();
        Vec3 center = Vec3.atCenterOf(railPos);
        List<Entity> spawned = new ArrayList<>();
        LocomotiveEntity locomotive = ModEntities.LOCOMOTIVE.create(level, EntitySpawnReason.TRIGGERED);
        if (locomotive == null) return DepotDispatchResult.SPAWN_FAILED;
        long lineId=controlMode==ControlMode.ROUTE_AUTOMATIC&&line!=null?line.id():0L;
        locomotive.trainLink().assign(trainId, locomotive.getUUID(), 0, lineId);
        locomotive.trainLink().setDepotGenerated(true);
        locomotive.trainLink().setControlMode(controlMode);
        TrainClass trainClass = inventory.trainClass();
        locomotive.trainLink().setTrainClass(trainClass);
        locomotive.trainLink().setConfiguredSpeedLimitKmh(inventory.speedLimitKmh(trainClass));
        locomotive.trainLink().setAutomaticRunning(controlMode==ControlMode.ROUTE_AUTOMATIC);
        locomotive.setPos(center);
        spawned.add(locomotive);
        for (int index = 0; index < inventory.template().cars().size(); index++) {
            CarType carType = inventory.template().cars().get(index);
            Entity car = carType == CarType.CARGO
                    ? ModEntities.CARGO_CAR.create(level, EntitySpawnReason.TRIGGERED)
                    : ModEntities.PASSENGER_CAR.create(level, EntitySpawnReason.TRIGGERED);
            if (!(car instanceof LinkedTrainCar linked)) return DepotDispatchResult.SPAWN_FAILED;
            if (car instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
            if (car instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            linked.trainLink().assign(trainId, locomotive.getUUID(), index + 1, lineId);
            linked.trainLink().setDepotGenerated(true);
            linked.trainLink().setControlMode(controlMode);
            linked.trainLink().setTrainClass(trainClass);
            linked.trainLink().setConfiguredSpeedLimitKmh(inventory.speedLimitKmh(trainClass));
            car.setPos(center.subtract(forward.scale((index + 1) * 1.25D)));
            spawned.add(car);
        }
        for (Entity entity : spawned) {
            BlockPos occupiedRail = BlockPos.containing(entity.position());
            var occupiedState = level.getBlockState(occupiedRail);
            if (!(occupiedState.is(ModBlocks.SIGNAL_RAIL) || occupiedState.is(ModBlocks.SWITCH_RAIL))
                    || !level.noCollision(entity)) return DepotDispatchResult.TRACK_SPACE_INVALID;
        }
        List<Entity> added = new ArrayList<>();
        for (Entity entity : spawned) {
            if (!level.addFreshEntity(entity)) {
                added.forEach(Entity::discard);
                return DepotDispatchResult.SPAWN_FAILED;
            }
            added.add(entity);
        }
        if (consumeItems) {
            take(containers, ModItems.LOCOMOTIVE, 1);
            take(containers, ModItems.PASSENGER_CAR, (int) inventory.template().cars().stream().filter(type -> type == CarType.PASSENGER).count());
            take(containers, ModItems.CARGO_CAR, (int) inventory.template().cars().stream().filter(type -> type == CarType.CARGO).count());
            containers.forEach(Container::setChanged);
        }
        if(controlMode==ControlMode.ROUTE_AUTOMATIC){
            RailwayDataManager.state(level).registerActiveTrain(trainId, lineId);
        }
        RailwayDataManager.state(level).ensureTrain(trainId, true, lineId,controlMode);
        if(controlMode==ControlMode.ROUTE_AUTOMATIC)locomotive.setDeltaMovement(forward.scale(SpeedRules.blocksPerTick(
                SpeedRules.actualSpeed(line.speedLimitKmh(), RailwayDataManager.state(level).classSpeedLimit(trainClass),
                        inventory.speedLimitKmh(trainClass)))));
        else locomotive.setDeltaMovement(Vec3.ZERO);
        return DepotDispatchResult.SUCCESS;
    }

    private static boolean reachesNode(ServerLevel level, BlockPos origin, Vec3i initialStep) {
        BlockPos previous = origin;
        BlockPos current = origin.offset(initialStep);
        for (int distance = 0; distance < 64; distance++) {
            if (!level.hasChunkAt(current)) return false;
            var state = level.getBlockState(current);
            if (state.is(ModBlocks.SWITCH_RAIL)) return true;
            for (Direction direction : Direction.values())
                if (level.getBlockState(current.relative(direction)).is(ModBlocks.STATION_MARKER)) return true;
            if (!BaseRailBlock.isRail(level, current) || !state.hasProperty(RailBlock.SHAPE)) return false;
            var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
            BlockPos first = current.offset(exits.getFirst());
            BlockPos second = current.offset(exits.getSecond());
            BlockPos next = first.equals(previous) ? second : first;
            previous = current;
            current = next;
        }
        return false;
    }

    private static List<Container> connectedContainers(ServerLevel level, BlockPos pos, TrainDepotBlockEntity depot) {
        ArrayList<Container> result = new ArrayList<>(); result.add(depot);
        for (Direction direction : Direction.values())
            if (level.getBlockEntity(pos.relative(direction)) instanceof Container container) result.add(container);
        return result;
    }

    private static boolean has(List<Container> containers, Item item, int amount) {
        if (amount <= 0) return true; int found = 0;
        for (Container container : containers) for (int slot=0;slot<container.getContainerSize();slot++)
            if (container.getItem(slot).is(item) && (found += container.getItem(slot).getCount()) >= amount) return true;
        return false;
    }

    private static void take(List<Container> containers, Item item, int amount) {
        for (Container container : containers) for (int slot=0;slot<container.getContainerSize()&&amount>0;slot++) {
            ItemStack stack=container.getItem(slot); if(!stack.is(item))continue;
            int moved=Math.min(amount,stack.getCount());stack.shrink(moved);amount-=moved;container.setItem(slot,stack);
        }
    }

    private static int find(TrainDepotBlockEntity inventory, Item item, int start) {
        for (int slot = start; slot < inventory.getContainerSize(); slot++) if (inventory.getItem(slot).is(item)) return slot;
        return -1;
    }

    private static List<Integer> reserveTemplate(TrainDepotBlockEntity inventory) {
        int[] reserved = new int[inventory.getContainerSize()];
        ArrayList<Integer> slots = new ArrayList<>();
        for (CarType type : inventory.template().cars()) {
            Item required = type == CarType.CARGO ? ModItems.CARGO_CAR : ModItems.PASSENGER_CAR;
            int selected = -1;
            for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
                if (inventory.getItem(slot).is(required) && inventory.getItem(slot).getCount() > reserved[slot]) {
                    selected = slot;
                    break;
                }
            }
            if (selected < 0) return null;
            reserved[selected]++;
            slots.add(selected);
        }
        return slots;
    }

    public static void clear() { LAST_DISPATCH_TICK.clear(); ticks = 0; }
}
