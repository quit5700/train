package cn.quit5700.fabrictrain.depot;

public final class DepotDirectionRules {
    private DepotDirectionRules() {}

    public static int frontIndex(boolean firstHasNode, boolean secondHasNode) {
        if (firstHasNode == secondHasNode) return -1;
        return firstHasNode ? 0 : 1;
    }
}
