package cn.quit5700.fabrictrain.block.entity;

import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

public final class PowerGeneratorBlockEntity extends BaseContainerBlockEntity {
    public static final int SIZE = 9;
    public static final long REDSTONE_DUST_TICKS = 72_000L;
    public static final long REDSTONE_BLOCK_TICKS = 504_000L;
    private NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
    private long remainingTicks;
    private boolean active;

    public PowerGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.POWER_GENERATOR, pos, state);
    }

    public static void serverTick(ServerLevel level, BlockPos pos, BlockState state, PowerGeneratorBlockEntity generator) {
        boolean before = generator.active;
        if (generator.remainingTicks <= 0) generator.consumeFuel();
        generator.active = generator.remainingTicks > 0;
        if (generator.active) generator.remainingTicks--;
        RailPowerService.updateGenerator(level, pos, generator.active);
        if (before != generator.active) {
            generator.setChanged();
            level.updateNeighborsAt(pos, state.getBlock());
        } else if (generator.active && generator.remainingTicks % 20 == 0) {
            generator.setChanged();
        }
    }

    private void consumeFuel() {
        for (int slot = 0; slot < items.size(); slot++) {
            ItemStack stack = items.get(slot);
            if (stack.is(Items.REDSTONE)) {
                stack.shrink(1);
                remainingTicks = REDSTONE_DUST_TICKS;
                return;
            }
        }
        for (int slot = 0; slot < items.size(); slot++) {
            ItemStack stack = items.get(slot);
            if (stack.is(Blocks.REDSTONE_BLOCK.asItem())) {
                stack.shrink(1);
                remainingTicks = REDSTONE_BLOCK_TICKS;
                return;
            }
        }
    }

    public boolean active() { return active; }
    public long remainingTicks() { return remainingTicks; }
    @Override public int getContainerSize() { return SIZE; }
    @Override protected NonNullList<ItemStack> getItems() { return items; }
    @Override protected void setItems(NonNullList<ItemStack> value) { items = value; }
    @Override protected Component getDefaultName() { return Component.translatable("container.fabric_train_simulator.power_generator"); }
    @Override protected AbstractContainerMenu createMenu(int syncId, Inventory inventory) { return ChestMenu.oneRow(syncId, inventory); }
    @Override public boolean canPlaceItem(int slot, ItemStack stack) {
        return stack.is(Items.REDSTONE) || stack.is(Blocks.REDSTONE_BLOCK.asItem());
    }

    @Override protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        ContainerHelper.saveAllItems(output, items);
        output.putLong("RemainingFuelTicks", remainingTicks);
    }

    @Override protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(input, items);
        remainingTicks = Math.max(0L, input.getLongOr("RemainingFuelTicks", 0L));
        active = remainingTicks > 0;
    }
}
