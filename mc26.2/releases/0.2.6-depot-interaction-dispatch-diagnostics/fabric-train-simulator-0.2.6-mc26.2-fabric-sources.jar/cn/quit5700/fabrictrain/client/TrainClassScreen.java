package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.TrainClassNetworking;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class TrainClassScreen extends Screen {
    private final int entityId;
    private final boolean hasCargo;
    private TrainClass selected;
    private final double freightSpeed;
    private final double passengerSpeed;
    private final double expressSpeed;
    private final java.util.List<TrainClassNetworking.Station> stations;
    private int stationIndex;
    private Button destination;

    public TrainClassScreen(TrainClassNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.train_class.title"));
        entityId = payload.entityId();
        hasCargo = payload.hasCargo();
        selected = TrainClass.values()[Math.clamp(payload.trainClassOrdinal(), 0, TrainClass.values().length - 1)];
        freightSpeed = payload.freightSpeedKmh();
        passengerSpeed = payload.passengerSpeedKmh();
        expressSpeed = payload.expressSpeedKmh();
        stations = payload.stations();
        for (int i = 0; i < stations.size(); i++)
            if (stations.get(i).id() == payload.destinationStationId()) stationIndex = i;
    }

    @Override
    protected void init() {
        int left = width / 2 - 100;
        int top = height / 2 - 105;
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.passenger"),
                button -> choose(TrainClass.PASSENGER)).bounds(left, top + 42, 62, 20).build()).active = !hasCargo;
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.cargo"),
                button -> choose(TrainClass.CARGO)).bounds(left + 69, top + 42, 62, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.express"),
                button -> choose(TrainClass.EXPRESS)).bounds(left + 138, top + 42, 62, 20).build()).active = !hasCargo;
        destination = addRenderableWidget(Button.builder(destinationLabel(), button -> {
            if (!stations.isEmpty()) stationIndex = (stationIndex + 1) % stations.size();
            button.setMessage(destinationLabel());
        }).bounds(left, top + 105, 200, 20).build());
        destination.visible = selected == TrainClass.CARGO;
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.train_class.save"),
                button -> save()).bounds(left + 65, top + 145, 70, 20).build());
    }

    private void choose(TrainClass trainClass) {
        selected = hasCargo ? TrainClass.CARGO : trainClass;
        destination.visible = selected == TrainClass.CARGO;
    }

    private Component destinationLabel() {
        return stations.isEmpty()
                ? Component.translatable("screen.fabric_train_simulator.cargo.no_station")
                : Component.literal(stations.get(stationIndex).name() + " ▼");
    }

    private void save() {
        ClientPlayNetworking.send(new TrainClassNetworking.UpdatePayload(entityId, selected.ordinal(),
                freightSpeed, passengerSpeed, expressSpeed, stations.isEmpty() ? 0 : stations.get(stationIndex).id()));
        onClose();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        int left = width / 2 - 110;
        int top = height / 2 - 105;
        graphics.fill(left, top, left + 220, top + 210, 0xE020232A);
        graphics.outline(left, top, 220, 210, 0xFF66CCFF);
        graphics.centeredText(font, title, width / 2, top + 10, 0xFFFFFFFF);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.train_class.current",
                Component.translatable("class.fabric_train_simulator." + selected.name().toLowerCase())),
                width / 2, top + 72, 0xFFE6E6E6);
        if (selected == TrainClass.CARGO)
            graphics.text(font, Component.translatable("screen.fabric_train_simulator.cargo.destination"),
                    left + 10, top + 91, 0xFFCCCCCC);
        if (hasCargo)
            graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.train_class.cargo_locked"),
                    width / 2, top + 177, 0xFFFFAA55);
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }
}
