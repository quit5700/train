package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.properties.RailShape;

public final class DeviceSettingsScreen extends Screen {
    private final long deviceId;
    private final DeviceType type;
    private int dwellSeconds;
    private int switchShape;
    private EditBox name;
    private EditBox announcement;
    private boolean manualUnload;
    private final boolean containerConnected;

    public DeviceSettingsScreen(DeviceSettingsNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                titleFor(payload));
        deviceId = payload.deviceId();
        type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        dwellSeconds = payload.dwellSeconds();
        switchShape = Math.clamp(payload.switchShapeOrdinal(), 0, 2);
        name = new EditBox(font, 190, 20, Component.translatable("screen.fabric_train_simulator.device.name"));
        name.setMaxLength(64);
        name.setValue(payload.name());
        announcement = new EditBox(font, 190, 20, Component.translatable("screen.fabric_train_simulator.station.announcement"));
        announcement.setMaxLength(128); announcement.setValue(payload.announcement());
        manualUnload = payload.manualUnload();
        containerConnected = payload.containerConnected();
    }

    @Override protected void init() {
        int left = width / 2 - 110;
        int top = height / 2 - 125;
        name.setX(left + 15); name.setY(top + 48); addRenderableWidget(name);
        if(type==DeviceType.STATION){announcement.setX(left+15);announcement.setY(top+142);addRenderableWidget(announcement);}
        if (type == DeviceType.STATION) {
            addRenderableWidget(Button.builder(Component.literal("-5"), b -> dwellSeconds = Math.max(0, dwellSeconds - 5)).bounds(left + 15, top + 102, 70, 20).build());
            addRenderableWidget(Button.builder(Component.literal("+5"), b -> dwellSeconds = Math.min(3600, dwellSeconds + 5)).bounds(left + 135, top + 102, 70, 20).build());
            addRenderableWidget(Button.builder(Component.translatable(manualUnload
                            ? "screen.fabric_train_simulator.station.manual_unload_on"
                            : "screen.fabric_train_simulator.station.manual_unload_off"),
                    b -> { manualUnload = !manualUnload; b.setMessage(Component.translatable(manualUnload
                            ? "screen.fabric_train_simulator.station.manual_unload_on"
                            : "screen.fabric_train_simulator.station.manual_unload_off")); })
                    .bounds(left + 15, top + 184, 190, 20).build());
        }
        if (type == DeviceType.SWITCH) {
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.left"), b -> switchShape = 0).bounds(left + 10, top + 90, 62, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.straight"), b -> switchShape = 1).bounds(left + 79, top + 90, 62, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.right"), b -> switchShape = 2).bounds(left + 148, top + 90, 62, 20).build());
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.device.save"), b -> save()).bounds(left + 75, top + 214, 70, 20).build());
    }

    private static Component titleFor(DeviceSettingsNetworking.OpenPayload payload) {
        DeviceType type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        return Component.translatable(type == DeviceType.STATION
                ? "screen.fabric_train_simulator.station.named_title"
                : "screen.fabric_train_simulator.switch.named_title", payload.name());
    }
    private void save() {
        ClientPlayNetworking.send(new DeviceSettingsNetworking.UpdatePayload(deviceId, name.getValue(), dwellSeconds, switchShape, announcement.getValue(), manualUnload));
        onClose();
    }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        int left = width / 2 - 110;
        int top = height / 2 - 125;
        graphics.fill(left, top, left + 220, top + 250, 0xE020232A);
        graphics.outline(left, top, 220, 250, 0xFF66CCFF);
        graphics.centeredText(font, title, width / 2, top + 10, 0xFFFFFFFF);
        graphics.text(font, Component.translatable("screen.fabric_train_simulator.device.name"), left + 15, top + 35, 0xFFCCCCCC);
        if (type == DeviceType.STATION) graphics.centeredText(font,
                Component.translatable("screen.fabric_train_simulator.device.dwell", dwellSeconds), width / 2, top + 87, 0xFFE6E6E6);
        if(type==DeviceType.STATION) {
            graphics.text(font,Component.translatable("screen.fabric_train_simulator.station.announcement"),left+15,top+129,0xFFCCCCCC);
            graphics.centeredText(font, Component.translatable(containerConnected
                    ? "screen.fabric_train_simulator.station.container_connected"
                    : "screen.fabric_train_simulator.station.container_disconnected"), width / 2, top + 168, 0xFFE6E6E6);
        }
        if (type == DeviceType.SWITCH) graphics.centeredText(font,
                Component.translatable("screen.fabric_train_simulator.device.shape",
                        Component.translatable("screen.fabric_train_simulator.switch." + switchName())), width / 2, top + 120, 0xFFE6E6E6);
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }

    private String switchName() { return switch (switchShape) { case 0 -> "left"; case 2 -> "right"; default -> "straight"; }; }
}
