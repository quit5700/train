package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.CargoSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class CargoSettingsScreen extends Screen {
    private final int entityId;
    private final List<CargoSettingsNetworking.Station> stations;
    private int selectedIndex;

    public CargoSettingsScreen(CargoSettingsNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.cargo.title"));
        entityId = payload.entityId();
        stations = payload.stations();
        selectedIndex = 0;
        for(int i=0;i<stations.size();i++)if(stations.get(i).id()==payload.selectedStationId())selectedIndex=i;
        for (int i = 0; i < stations.size(); i++) if (stations.get(i).id() == payload.selectedStationId()) selectedIndex = i;
    }

    @Override protected void init() {
        int left = width / 2 - 100;
        int top = height / 2 - 55;
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.cargo.previous"), b -> move(-1)).bounds(left, top + 55, 62, 20).build()).active = !stations.isEmpty();
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.cargo.clear"), b -> save(0L)).bounds(left + 69, top + 55, 62, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.cargo.next"), b -> move(1)).bounds(left + 138, top + 55, 62, 20).build()).active = !stations.isEmpty();
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.cargo.save"), b -> save(stations.isEmpty() ? 0L : stations.get(selectedIndex).id())).bounds(left + 69, top + 81, 62, 20).build());
    }

    private void move(int amount) { if (!stations.isEmpty()) selectedIndex = Math.floorMod(selectedIndex + amount, stations.size()); }
    private void save(long stationId) { ClientPlayNetworking.send(new CargoSettingsNetworking.UpdatePayload(entityId, stationId)); onClose(); }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        int left = width / 2 - 110;
        int top = height / 2 - 70;
        graphics.fill(left, top, left + 220, top + 140, 0xE020232A);
        graphics.outline(left, top, 220, 140, 0xFFFFA64D);
        graphics.centeredText(font, title, width / 2, top + 10, 0xFFFFFFFF);
        if (stations.isEmpty()) {
            graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.cargo.no_station"), width / 2, top + 31, 0xFFFFAA55);
        } else {
            CargoSettingsNetworking.Station station = stations.get(selectedIndex);
            graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.cargo.destination", station.name(), station.id()), width / 2, top + 30, 0xFFE6E6E6);
            graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.cargo.eta", station.etaSeconds()), width / 2, top + 43, 0xFFE6E6E6);
        }
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }
}
