package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.network.DepotNetworking;
import cn.quit5700.fabrictrain.train.CarType;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import cn.quit5700.fabrictrain.train.SpeedRules;

public final class DepotSettingsScreen extends Screen {
    private final BlockPos depotPos;
    private final ArrayList<CarType> cars;
    private final List<DepotNetworking.LineOption> lines;
    private int lineIndex = -1;
    private TrainClass trainClass;
    private int interval;
    private int maximum;
    private final long active;
    private Button lineButton;
    private Button dispatchButton;
    private Button passengerButton;
    private Button expressButton;
    private Button removeButton;
    private EditBox speedInput;
    private final double[] speeds=new double[TrainClass.values().length];

    public DepotSettingsScreen(DepotNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.depot.title"));
        depotPos = payload.pos();
        cars = new ArrayList<>(DepotTemplate.decode(payload.template()).cars());
        lines = payload.lines();
        for (int i = 0; i < lines.size(); i++) if (lines.get(i).id() == payload.lineId()) lineIndex = i;
        trainClass = TrainClass.values()[Math.clamp(payload.trainClass(), 0, TrainClass.values().length - 1)];
        interval = payload.interval();
        maximum = payload.maximum();
        active = payload.active();
        speeds[TrainClass.CARGO.ordinal()]=payload.cargoSpeedKmh();
        speeds[TrainClass.PASSENGER.ordinal()]=payload.passengerSpeedKmh();
        speeds[TrainClass.EXPRESS.ordinal()]=payload.expressSpeedKmh();
    }

    @Override protected void init() {
        int left=width/2-110,top=Math.max(6,height/2-138);
        passengerButton=addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.passenger"),b->choose(TrainClass.PASSENGER)).bounds(left+10,top+28,62,20).build());
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.cargo"),b->choose(TrainClass.CARGO)).bounds(left+79,top+28,62,20).build());
        expressButton=addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.express"),b->choose(TrainClass.EXPRESS)).bounds(left+148,top+28,62,20).build());
        speedInput=new EditBox(font,200,20,Component.translatable("screen.fabric_train_simulator.depot.speed"));
        speedInput.setPosition(left+10,top+66);speedInput.setMaxLength(12);
        speedInput.setValue(speedText(trainClass));addRenderableWidget(speedInput);
        lineButton=addRenderableWidget(Button.builder(lineLabel(),b->{
            lineIndex = lines.isEmpty() ? -1 : (lineIndex >= lines.size()-1 ? -1 : lineIndex+1);
            b.setMessage(lineLabel());
        }).bounds(left+10,top+94,200,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.minus_five"),b->interval=Math.max(1,interval-5)).bounds(left+10,top+121,55,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.plus_five"),b->interval=Math.min(3600,interval+5)).bounds(left+70,top+121,55,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.minus_one"),b->maximum=Math.max(1,maximum-1)).bounds(left+130,top+121,38,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.plus_one"),b->maximum=Math.min(1000,maximum+1)).bounds(left+172,top+121,38,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.add_passenger"),b->add(CarType.PASSENGER)).bounds(left+10,top+166,96,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.add_cargo"),b->add(CarType.CARGO)).bounds(left+114,top+166,96,20).build());
        removeButton=addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.remove"),b->removeLast()).bounds(left+10,top+192,96,20).build());
        dispatchButton=addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.dispatch_now"),b->send(true)).bounds(left+114,top+192,96,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.save"),b->send(false)).bounds(left+75,top+247,70,20).build());
        updateButtons();
    }
    private boolean hasCargo(){return cars.contains(CarType.CARGO);}
    private void choose(TrainClass value){commitSpeed();trainClass=hasCargo()?TrainClass.CARGO:value;speedInput.setValue(speedText(trainClass));updateButtons();}
    private void add(CarType type){if(cars.size()<100){cars.add(type);if(type==CarType.CARGO)choose(TrainClass.CARGO);updateButtons();}}
    private void removeLast(){if(!cars.isEmpty()){cars.removeLast();if(!hasCargo()&&trainClass==TrainClass.CARGO)choose(TrainClass.PASSENGER);updateButtons();}}
    private Component lineLabel(){return lineIndex<0?Component.translatable("screen.fabric_train_simulator.depot.no_line"):Component.literal(lines.get(lineIndex).name()+" ▼");}
    private String speedText(TrainClass value){return String.format(Locale.ROOT,"%.1f",speeds[value.ordinal()]);}
    private void commitSpeed(){if(speedInput==null)return;try{speeds[trainClass.ordinal()]=SpeedRules.sanitizeConfiguredLimit(Double.parseDouble(speedInput.getValue()),speeds[trainClass.ordinal()]);}catch(NumberFormatException ignored){ }speedInput.setValue(speedText(trainClass));}
    private void updateButtons(){if(passengerButton!=null)passengerButton.active=!hasCargo();if(expressButton!=null)expressButton.active=!hasCargo();if(removeButton!=null)removeButton.active=!cars.isEmpty();}
    private void send(boolean now){commitSpeed();long line=lineIndex<0?0:lines.get(lineIndex).id();ClientPlayNetworking.send(new DepotNetworking.UpdatePayload(depotPos,new DepotTemplate(cars).encode(),line,trainClass.ordinal(),interval,maximum,speeds[TrainClass.CARGO.ordinal()],speeds[TrainClass.PASSENGER.ordinal()],speeds[TrainClass.EXPRESS.ordinal()],now));if(!now)onClose();}

    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float tickProgress){
        int left=width/2-110,top=Math.max(6,height/2-138);g.fill(left,top,left+220,top+276,0xE020232A);g.outline(left,top,220,276,0xFF66CCFF);g.centeredText(font,title,width/2,top+9,0xFFFFFFFF);
        g.text(font,Component.translatable("screen.fabric_train_simulator.depot.speed",Component.translatable("class.fabric_train_simulator."+trainClass.name().toLowerCase(Locale.ROOT))),left+10,top+54,0xFFE6E6E6);
        g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.interval",interval),width/2-45,top+147,0xFFE6E6E6);
        g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.active",active,maximum),width/2+55,top+147,0xFFE6E6E6);
        long passengers=cars.stream().filter(t->t==CarType.PASSENGER).count();g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.summary",cars.size(),passengers,cars.size()-passengers),width/2,top+219,0xFFE6E6E6);
        if(cars.isEmpty())g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.empty_hint"),width/2,top+232,0xFFFFAA55);
        super.extractRenderState(g,mouseX,mouseY,tickProgress);
    }
}
