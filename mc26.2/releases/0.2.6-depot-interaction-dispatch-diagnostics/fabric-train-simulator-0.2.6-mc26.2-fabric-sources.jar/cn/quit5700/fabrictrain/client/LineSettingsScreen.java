package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.LineStatus;
import cn.quit5700.fabrictrain.network.LineSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import net.minecraft.client.gui.components.EditBox;

public final class LineSettingsScreen extends Screen {
    private final long lineId;
    private final ArrayList<Long> nodeIds;
    private int selectedNode;
    private int status;
    private int interval;
    private double speed;
    private int maximumTrains;
    private EditBox lineName;

    public LineSettingsScreen(LineSettingsNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.line.title", payload.lineId()));
        lineId = payload.lineId();
        nodeIds = new ArrayList<>(payload.nodeIds());
        selectedNode = Math.min(1, Math.max(0, nodeIds.size() - 1));
        status = payload.statusOrdinal();
        interval = payload.intervalSeconds();
        speed = payload.speedKmh();
        maximumTrains = payload.maximumTrains();
        lineName = new EditBox(font, 190, 20, Component.translatable("screen.fabric_train_simulator.line.name"));
        lineName.setMaxLength(64);
        lineName.setValue(payload.name());
    }

    @Override protected void init() {
        int left = width / 2 - 110;
        int top = height / 2 - 90;
        lineName.setX(left + 5); lineName.setY(top + 5); addRenderableWidget(lineName);
        addRenderableWidget(Button.builder(Component.literal("-30"), b -> interval = Math.max(0, interval - 30)).bounds(left, top + 50, 52, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+30"), b -> interval = Math.min(3600, interval + 30)).bounds(left + 168, top + 50, 52, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-10"), b -> speed = Math.max(0, speed - 10)).bounds(left, top + 76, 52, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+10"), b -> speed += 10).bounds(left + 168, top + 76, 52, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-1"), b -> maximumTrains = Math.max(1, maximumTrains - 1)).bounds(left, top + 102, 52, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+1"), b -> maximumTrains = Math.min(1000, maximumTrains + 1)).bounds(left + 168, top + 102, 52, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.status"), b -> status = (status + 1) % LineStatus.values().length).bounds(left, top + 128, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.refresh"), b -> send(true, false)).bounds(left + 76, top + 128, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.delete"), b -> send(false, true)).bounds(left + 152, top + 128, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.save"), b -> send(false, false)).bounds(left + 76, top + 154, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.previous_node"), b -> selectNode(-1)).bounds(left, top + 180, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.move_up"), b -> modifyNode(0)).bounds(left + 76, top + 180, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.next_node"), b -> selectNode(1)).bounds(left + 152, top + 180, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.move_down"), b -> modifyNode(1)).bounds(left, top + 206, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.delete_node"), b -> modifyNode(2)).bounds(left + 76, top + 206, 68, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.line.add_nodes"), b -> beginEditing()).bounds(left + 152, top + 206, 68, 20).build());
    }

    private void send(boolean refresh, boolean delete) {
        ClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.getValue(), status, interval, speed, maximumTrains, refresh, delete, -1, -1, false));
        onClose();
    }

    private void selectNode(int amount) { if (nodeIds.size() > 1) selectedNode = 1 + Math.floorMod(selectedNode - 1 + amount, nodeIds.size() - 1); }
    private void modifyNode(int action) {
        if (selectedNode <= 0 || selectedNode >= nodeIds.size()) return;
        ClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.getValue(), status, interval, speed, maximumTrains, false, false, selectedNode, action, false));
        if (action == 0 && selectedNode > 1) { java.util.Collections.swap(nodeIds, selectedNode, selectedNode - 1); selectedNode--; }
        else if (action == 1 && selectedNode < nodeIds.size() - 1) { java.util.Collections.swap(nodeIds, selectedNode, selectedNode + 1); selectedNode++; }
        else if (action == 2) { nodeIds.remove(selectedNode); selectedNode = Math.min(selectedNode, nodeIds.size() - 1); }
    }
    private void beginEditing() { ClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.getValue(), status, interval, speed, maximumTrains, false, false, -1, -1, true)); onClose(); }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        int left = width / 2 - 120;
        int top = height / 2 - 105;
        graphics.fill(left, top, left + 240, top + 260, 0xE020232A);
        graphics.outline(left, top, 240, 260, 0xFF66CCFF);
        graphics.centeredText(font, title, width / 2, top + 10, 0xFFFFFFFF);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.nodes", nodeIds.size()), width / 2, top + 48, 0xFFE6E6E6);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.interval", interval), width / 2, top + 55, 0xFFE6E6E6);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.speed", speed), width / 2, top + 81, 0xFFE6E6E6);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.maximum", maximumTrains), width / 2, top + 107, 0xFFE6E6E6);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.current_status", Component.translatable("status.fabric_train_simulator." + LineStatus.values()[status].name().toLowerCase())), width / 2, top + 188, 0xFFE6E6E6);
        if (!nodeIds.isEmpty()) graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.line.selected_node", selectedNode, nodeIds.get(Math.max(0, selectedNode))), width / 2, top + 238, 0xFFE6E6E6);
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }
}
