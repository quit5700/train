package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.network.RailwayManagerNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class RailwayManagerScreen extends Screen {
    private static final int ROW_HEIGHT = 20;
    private final List<RailwayManagerNetworking.DeviceSummary> devices;
    private final List<RailwayManagerNetworking.LineSummary> lines;
    private RailwayManagerNetworking.LineSummary selected;
    private EditBox lineName;
    private Button leftDirection;
    private Button straightDirection;
    private Button rightDirection;
    private long draggedDevice;
    private int draggedNode = -1;
    private int selectedSwitch = -1;
    private int nodePage;
    private double pressX;
    private double pressY;

    public RailwayManagerScreen(RailwayManagerNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.manager.title"));
        devices = payload.devices();
        lines = payload.lines();
        selected = lines.stream().filter(line -> line.id() == payload.selectedLineId()).findFirst().orElse(null);
    }

    private Layout layout() {
        return Layout.of(width, height);
    }

    @Override
    protected void init() {
        Layout l = layout();
        lineName = new EditBox(font, Math.max(40, l.columnWidth() - 44), 20,
                Component.translatable("screen.fabric_train_simulator.line.name"));
        lineName.setMaxLength(64);
        lineName.setX(l.middleX() + 4);
        lineName.setY(l.footerY());
        lineName.setValue(selected == null ? "" : selected.name());
        addRenderableWidget(lineName);

        if (selected == null) {
            addRenderableWidget(Button.builder(Component.literal("＋"),
                    button -> send(RailwayManagerNetworking.CREATE, 0, 0, 0, 0, lineName.getValue()))
                    .bounds(l.middleX() + l.columnWidth() - 36, l.footerY(), 32, 20).build());
            return;
        }

        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.device.save"),
                button -> send(RailwayManagerNetworking.RENAME, selected.id(), 0, 0, 0, lineName.getValue()))
                .bounds(l.middleX() + l.columnWidth() - 36, l.footerY(), 32, 20).build());
        int operationY = l.footerY();
        int operationWidth = Math.max(36, (l.columnWidth() - 12) / 4);
        leftDirection = addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.left"),
                button -> setDirection(0)).bounds(l.rightX() + 4, operationY, operationWidth, 20).build());
        straightDirection = addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.straight"),
                button -> setDirection(1)).bounds(l.rightX() + 6 + operationWidth, operationY, operationWidth, 20).build());
        rightDirection = addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.right"),
                button -> setDirection(2)).bounds(l.rightX() + 8 + operationWidth * 2, operationY, operationWidth, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.manager.close"),
                button -> ClientPlayNetworking.send(new RailwayManagerNetworking.SelectPayload(false, 0)))
                .bounds(l.rightX() + 10 + operationWidth * 3, operationY, operationWidth, 20).build());
        updateDirectionButtonVisibility();
        addRenderableWidget(Button.builder(Component.literal("◀"), button -> nodePage = Math.max(0, nodePage - 1))
                .bounds(l.middleX() + 4, l.pageY(), 30, 18).build());
        addRenderableWidget(Button.builder(Component.literal("▶"), button ->
                        nodePage = Math.min(Math.max(0, (selected.nodes().size() - 1) / l.rows()), nodePage + 1))
                .bounds(l.middleX() + l.columnWidth() - 34, l.pageY(), 30, 18).build());
    }

    private void updateDirectionButtonVisibility() {
        boolean visible = selectedSwitch >= 0;
        if (leftDirection != null) leftDirection.visible = visible;
        if (straightDirection != null) straightDirection.visible = visible;
        if (rightDirection != null) rightDirection.visible = visible;
    }

    private void setDirection(int value) {
        if (selectedSwitch >= 0) send(RailwayManagerNetworking.DIRECTION, selected.id(), 0, selectedSwitch, value, "");
    }

    private static void send(int operation, long line, long device, int index, int value, String text) {
        ClientPlayNetworking.send(new RailwayManagerNetworking.EditPayload(operation, line, device, index, value, text));
    }

    private List<RailwayManagerNetworking.DeviceSummary> leftDevices() {
        return devices.stream().filter(device -> device.type() == DeviceType.STATION.ordinal()
                || device.type() == DeviceType.SWITCH.ordinal()).toList();
    }

    private List<RailwayManagerNetworking.DeviceSummary> depots() {
        return devices.stream().filter(device -> device.type() == DeviceType.DEPOT.ordinal()).toList();
    }

    private RailwayManagerNetworking.DeviceSummary device(long id) {
        return devices.stream().filter(device -> device.id() == id).findFirst().orElse(null);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        Layout l = layout();
        double x = event.x();
        double y = event.y();
        int row = (int) ((y - l.rowsY()) / ROW_HEIGHT);
        pressX = x;
        pressY = y;

        if (selected == null) {
            if (event.button() == 0 && l.insideMiddle(x) && validRow(row, lines.size(), l.rows())) {
                ClientPlayNetworking.send(new RailwayManagerNetworking.SelectPayload(false, lines.get(row).id()));
                return true;
            }
        }

        if (l.insideLeft(x) && validRow(row, leftDevices().size(), l.rows())) {
            if (event.button() == 0) draggedDevice = leftDevices().get(row).id();
            return true;
        }
        if (l.insideRight(x) && validRow(row, depots().size(), l.rows())) {
            RailwayManagerNetworking.DeviceSummary depot = depots().get(row);
            if (event.button() == 0) draggedDevice = depot.id();
            return true;
        }
        if (selected != null && l.insideMiddle(x)) {
            int nodeIndex = nodePage * l.rows() + row;
            if (row >= 0 && nodeIndex < selected.nodes().size()) {
                if (event.button() == 1) {
                    send(RailwayManagerNetworking.REMOVE, selected.id(), 0, nodeIndex, 0, "");
                    return true;
                }
                if (event.button() == 0) {
                    draggedNode = nodeIndex;
                    RailwayManagerNetworking.DeviceSummary device = device(selected.nodes().get(nodeIndex));
                    selectedSwitch = device != null && device.type() == DeviceType.SWITCH.ordinal() ? nodeIndex : -1;
                    updateDirectionButtonVisibility();
                    return true;
                }
            }
        }
        selectedSwitch = -1;
        updateDirectionButtonVisibility();
        return false;
    }

    private static boolean validRow(int row, int size, int rows) {
        return row >= 0 && row < Math.min(size, rows);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        Layout l = layout();
        double x = event.x();
        double y = event.y();
        boolean moved = Math.abs(x - pressX) + Math.abs(y - pressY) > 5;
        if (draggedDevice != 0) {
            long id = draggedDevice;
            draggedDevice = 0;
            if (selected != null && l.insideMiddle(x) && y >= l.rowsY() && y < l.rowsBottom()) {
                int at = Math.clamp(nodePage * l.rows() + (int) ((y - l.rowsY()) / ROW_HEIGHT), 0, selected.nodes().size());
                send(RailwayManagerNetworking.ADD, selected.id(), id, at, 0, "");
            } else if (!moved) {
                ClientPlayNetworking.send(new RailwayManagerNetworking.SelectPayload(true, id));
            }
            return true;
        }
        if (draggedNode >= 0) {
            int from = draggedNode;
            draggedNode = -1;
            if (moved && l.insideMiddle(x) && y >= l.rowsY() && y < l.rowsBottom()) {
                int to = Math.clamp(nodePage * l.rows() + (int) ((y - l.rowsY()) / ROW_HEIGHT),
                        0, Math.max(0, selected.nodes().size() - 1));
                send(RailwayManagerNetworking.MOVE, selected.id(), 0, from, to, "");
            }
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        Layout l = layout();
        graphics.fill(l.left(), l.top(), l.left() + l.panelWidth(), l.top() + l.panelHeight(), 0xED20232A);
        graphics.outline(l.left(), l.top(), l.panelWidth(), l.panelHeight(), 0xFF66CCFF);
        graphics.fill(l.middleX() - 3, l.top() + 28, l.middleX() - 2, l.footerY() - 4, 0xFF666B73);
        graphics.fill(l.rightX() - 3, l.top() + 28, l.rightX() - 2, l.footerY() - 4, 0xFF666B73);
        graphics.centeredText(font, title, width / 2, l.top() + 7, 0xFFFFFFFF);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.manager.devices"),
                l.leftX() + l.columnWidth() / 2, l.top() + 25, 0xFF66CCFF);
        graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.manager.lines"),
                l.middleX() + l.columnWidth() / 2, l.top() + 25, 0xFF66CCFF);
        graphics.centeredText(font, Component.translatable("device_type.fabric_train_simulator.depot"),
                l.rightX() + l.columnWidth() / 2, l.top() + 25, 0xFF66CCFF);

        renderDevices(graphics, l.leftX(), l.rowsY(), leftDevices(), l);
        renderDevices(graphics, l.rightX(), l.rowsY(), depots(), l);
        if (selected == null) {
            for (int i = 0; i < Math.min(l.rows(), lines.size()); i++)
                row(graphics, l.middleX(), l.rowsY() + i * ROW_HEIGHT, lines.get(i).name(), 0xFFEEEEEE, l);
        } else {
            int start = nodePage * l.rows();
            for (int i = 0; i < l.rows() && start + i < selected.nodes().size(); i++) {
                int index = start + i;
                var device = device(selected.nodes().get(index));
                int direction = selected.directions().get(index);
                String suffix = direction < 0 ? "" : "  [" + (direction == 0 ? "←" : direction == 1 ? "↑" : "→") + "]";
                row(graphics, l.middleX(), l.rowsY() + i * ROW_HEIGHT,
                        (index + 1) + ". " + (device == null ? "?" : device.name()) + suffix,
                        index == selectedSwitch ? 0xFF66CCFF : 0xFFEEEEEE, l);
            }
            graphics.centeredText(font, Component.literal((nodePage + 1) + " / "
                            + Math.max(1, (selected.nodes().size() + l.rows() - 1) / l.rows())),
                    l.middleX() + l.columnWidth() / 2, l.pageY() + 4, 0xFFCCCCCC);
            if (selectedSwitch >= 0)
                graphics.outline(l.rightX() + 1, l.footerY() - 3, l.columnWidth() - 2, 26, 0xFF777777);
        }
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }

    private void renderDevices(GuiGraphicsExtractor graphics, int x, int y,
                               List<RailwayManagerNetworking.DeviceSummary> list, Layout layout) {
        for (int i = 0; i < Math.min(layout.rows(), list.size()); i++) {
            RailwayManagerNetworking.DeviceSummary device = list.get(i);
            row(graphics, x, y + i * ROW_HEIGHT, device.name() + "  #" + device.id(), 0xFFEEEEEE, layout);
        }
    }

    private void row(GuiGraphicsExtractor graphics, int x, int y, String text, int color, Layout layout) {
        graphics.fill(x, y, x + layout.columnWidth(), y + ROW_HEIGHT - 2, 0xAA343941);
        String fitted = font.plainSubstrByWidth(text, Math.max(12, layout.columnWidth() - 8));
        graphics.text(font, Component.literal(fitted), x + 4, y + 5, color);
    }

    private record Layout(int left, int top, int panelWidth, int panelHeight, int columnWidth,
                          int leftX, int middleX, int rightX, int rowsY, int rowsBottom,
                          int pageY, int footerY, int rows) {
        static Layout of(int screenWidth, int screenHeight) {
            int panelWidth = Math.max(300, Math.min(900, screenWidth - 12));
            int panelHeight = Math.max(220, Math.min(500, screenHeight - 12));
            int left = (screenWidth - panelWidth) / 2;
            int top = (screenHeight - panelHeight) / 2;
            int gap = 8;
            int columnWidth = (panelWidth - gap * 4) / 3;
            int leftX = left + gap;
            int middleX = leftX + columnWidth + gap;
            int rightX = middleX + columnWidth + gap;
            int rowsY = top + 40;
            int footerY = top + panelHeight - 27;
            int pageY = footerY - 21;
            int rowsBottom = pageY - 2;
            int rows = Math.max(1, (rowsBottom - rowsY) / ROW_HEIGHT);
            return new Layout(left, top, panelWidth, panelHeight, columnWidth, leftX, middleX, rightX,
                    rowsY, rowsBottom, pageY, footerY, rows);
        }

        boolean insideLeft(double x) { return x >= leftX && x < leftX + columnWidth; }
        boolean insideMiddle(double x) { return x >= middleX && x < middleX + columnWidth; }
        boolean insideRight(double x) { return x >= rightX && x < rightX + columnWidth; }
    }
}
