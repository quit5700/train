package cn.quit5700.fabrictrain.route;

import net.minecraft.core.Direction;

import java.util.Map;

public final class SwitchEntryDirectionRules {
    private SwitchEntryDirectionRules() {}

    public static Direction choose(Direction placementEntry, Map<Direction, Integer> depotDistances) {
        int nearest = depotDistances.values().stream().mapToInt(Integer::intValue).min().orElse(Integer.MAX_VALUE);
        if (nearest == Integer.MAX_VALUE) return placementEntry;
        if (depotDistances.getOrDefault(placementEntry, Integer.MAX_VALUE) == nearest) return placementEntry;
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (depotDistances.getOrDefault(direction, Integer.MAX_VALUE) == nearest) return direction;
        }
        return placementEntry;
    }
}
