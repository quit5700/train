package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayDeque;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class SwitchEntryDirectionService {
    private static final int SCAN_INTERVAL_TICKS = 20;
    private static final int MAXIMUM_RAILS_PER_BRANCH = 64;
    private static long ticks;

    private SwitchEntryDirectionService() {}

    public static void tick(MinecraftServer server) {
        if (++ticks % SCAN_INTERVAL_TICKS != 0) return;
        for (ServerLevel level : server.getAllLevels()) refreshLoadedSwitches(level);
    }

    public static void clear() {
        ticks = 0;
    }

    private static void refreshLoadedSwitches(ServerLevel level) {
        var data = RailwayDataManager.state(level);
        data.devices().values().stream()
                .filter(device -> device.type() == DeviceType.SWITCH)
                .filter(device -> device.dimension().equals(RailwayDataManager.dimension(level)))
                .forEach(device -> refresh(level, new BlockPos(device.x(), device.y(), device.z())));
    }

    private static void refresh(ServerLevel level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return;
        BlockState state = level.getBlockState(pos);
        if (!state.is(ModBlocks.SWITCH_RAIL)) return;
        Direction fallback = state.getValue(DeviceRailBlock.PLACEMENT_ENTRY);
        Direction entry = SwitchEntryDirectionRules.choose(fallback, depotDistances(level, pos));
        if (entry == state.getValue(DeviceRailBlock.ENTRY_DIRECTION)) return;
        int choice = state.getValue(DeviceRailBlock.SWITCH_CHOICE);
        level.setBlock(pos, state.setValue(DeviceRailBlock.ENTRY_DIRECTION, entry)
                .setValue(RailBlock.SHAPE, SwitchRailRouting.shapeForEntry(entry, choice)), 3);
    }

    private static Map<Direction, Integer> depotDistances(ServerLevel level, BlockPos switchPos) {
        EnumMap<Direction, Integer> result = new EnumMap<>(Direction.class);
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            int distance = distanceToDepot(level, switchPos, direction);
            if (distance >= 0) result.put(direction, distance);
        }
        return result;
    }

    private static int distanceToDepot(ServerLevel level, BlockPos switchPos, Direction branch) {
        BlockPos first = railAt(level, switchPos.relative(branch));
        if (first == null || !neighbours(level, first).contains(switchPos)) return -1;
        ArrayDeque<RailStep> queue = new ArrayDeque<>();
        Set<BlockPos> visited = new HashSet<>();
        visited.add(switchPos);
        queue.add(new RailStep(first, 1));
        while (!queue.isEmpty() && visited.size() <= MAXIMUM_RAILS_PER_BRANCH) {
            RailStep step = queue.removeFirst();
            if (!visited.add(step.pos())) continue;
            if (level.getBlockState(step.pos().below()).is(ModBlocks.TRAIN_DEPOT)) return step.distance();
            for (BlockPos neighbour : neighbours(level, step.pos())) {
                if (!visited.contains(neighbour)) queue.addLast(new RailStep(neighbour, step.distance() + 1));
            }
        }
        return -1;
    }

    private static Set<BlockPos> neighbours(ServerLevel level, BlockPos pos) {
        HashSet<BlockPos> result = new HashSet<>(2);
        BlockState state = level.getBlockState(pos);
        if (!state.hasProperty(RailBlock.SHAPE)) return result;
        var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
        addRail(level, pos, exits.getFirst(), result);
        addRail(level, pos, exits.getSecond(), result);
        return result;
    }

    private static void addRail(ServerLevel level, BlockPos pos, Vec3i exit, Set<BlockPos> result) {
        BlockPos candidate = railAt(level, pos.offset(exit));
        if (candidate != null) result.add(candidate);
    }

    private static BlockPos railAt(ServerLevel level, BlockPos pos) {
        if (!level.hasChunkAt(pos)) return null;
        if (BaseRailBlock.isRail(level, pos)) return pos;
        if (BaseRailBlock.isRail(level, pos.below())) return pos.below();
        if (BaseRailBlock.isRail(level, pos.above())) return pos.above();
        return null;
    }

    private record RailStep(BlockPos pos, int distance) {}
}
