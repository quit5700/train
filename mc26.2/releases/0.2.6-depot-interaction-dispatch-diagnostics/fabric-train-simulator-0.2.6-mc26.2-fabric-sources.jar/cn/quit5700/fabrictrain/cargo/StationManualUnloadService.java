package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

public final class StationManualUnloadService {
    private StationManualUnloadService() {}

    public static void tick(MinecraftServer server) {
        for (ServerLevel level : server.getAllLevels()) {
            var data = RailwayDataManager.state(level);
            var stations = data.devices().values().stream()
                    .filter(device -> device.type() == DeviceType.STATION && device.manualUnload()
                            && device.dimension().equals(RailwayDataManager.dimension(level))).toList();
            if (stations.isEmpty()) continue;
            for (Entity entity : level.getAllEntities()) {
                if (!(entity instanceof CargoCarEntity cargo)) continue;
                for (var station : stations) {
                    BlockPos stationPos = new BlockPos(station.x(), station.y(), station.z());
                    Vec3 center = Vec3.atCenterOf(stationPos);
                    if (Math.abs(cargo.getX() - center.x) > 2.0D
                            || Math.abs(cargo.getY() - center.y) > 2.5D
                            || Math.abs(cargo.getZ() - center.z) > 2.0D) continue;
                    CargoTransferService.manualUnloadAtStation(level, stationPos, cargo);
                }
            }
        }
    }

    public static void clear() {}
}
