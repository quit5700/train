package cn.quit5700.fabrictrain.cargo;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

public final class DestinationUnloadService {
    private DestinationUnloadService() {}

    public static void tick(MinecraftServer server){
        for(ServerLevel level:server.getAllLevels()){
            var data=RailwayDataManager.state(level);
            String dimension=RailwayDataManager.dimension(level);
            for(var entity:level.getAllEntities()){
                if(!(entity instanceof CargoCarEntity cargo)||cargo.destinationStationId()<=0L||cargo.isEmpty())continue;
                var station=data.device(cargo.destinationStationId());
                if(station==null||station.type()!=DeviceType.STATION||!station.dimension().equals(dimension))continue;
                BlockPos stationPos=new BlockPos(station.x(),station.y(),station.z());
                Vec3 center=Vec3.atCenterOf(stationPos);
                if(!CargoDestinationRules.atStation(cargo.getX(),cargo.getY(),cargo.getZ(),center.x,center.y,center.z))continue;
                CargoTransferService.unloadAtStation(level,stationPos,cargo);
                if(cargo.isEmpty())cargo.setDestinationStationId(0L);
            }
        }
    }
}
