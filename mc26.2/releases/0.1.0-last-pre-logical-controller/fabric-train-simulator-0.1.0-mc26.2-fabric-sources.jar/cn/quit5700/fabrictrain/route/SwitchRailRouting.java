package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;

public final class SwitchRailRouting {
    private SwitchRailRouting() {}

    public static RailShape shapeFor(Direction travel, int choice) {
        int safeChoice = Math.clamp(choice, 0, 2);
        if (safeChoice == 1) {
            return travel.getAxis() == Direction.Axis.X ? RailShape.EAST_WEST : RailShape.NORTH_SOUTH;
        }
        boolean left = safeChoice == 0;
        return switch (travel) {
            case EAST -> left ? RailShape.NORTH_EAST : RailShape.SOUTH_EAST;
            case WEST -> left ? RailShape.SOUTH_WEST : RailShape.NORTH_WEST;
            case NORTH -> left ? RailShape.NORTH_WEST : RailShape.NORTH_EAST;
            case SOUTH -> left ? RailShape.SOUTH_EAST : RailShape.SOUTH_WEST;
            default -> RailShape.NORTH_SOUTH;
        };
    }

    public static void applyChoice(ServerLevel level, RailwayDevice before, int newChoice) {
        BlockPos pos = new BlockPos(before.x(), before.y(), before.z());
        BlockState state = level.getBlockState(pos);
        if (!state.is(ModBlocks.SWITCH_RAIL) || !state.hasProperty(RailBlock.SHAPE)) return;
        level.setBlock(pos, state.setValue(DeviceRailBlock.SWITCH_CHOICE, Math.clamp(newChoice, 0, 2)), 3);
    }

    private static Direction canonicalTravel(RailShape current, int currentChoice) {
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            if (shapeFor(direction, currentChoice) == current) return direction;
        }
        return switch (current) {
            case EAST_WEST, ASCENDING_EAST, ASCENDING_WEST -> Direction.EAST;
            default -> Direction.SOUTH;
        };
    }
}
