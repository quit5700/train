package cn.quit5700.fabrictrain.data;

import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Dynamic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.SavedDataType;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.train.SpeedRules;

public final class RailwaySavedData extends SavedData {
    public static final Codec<RailwaySavedData> CODEC = Codec.PASSTHROUGH.xmap(
            RailwaySavedData::fromDynamic, RailwaySavedData::toDynamic);
    public static final SavedDataType<RailwaySavedData> TYPE = new SavedDataType<>(
            FabricTrainMod.id("railway_data"), RailwaySavedData::new, CODEC, null);

    private final Map<Long, RailwayDevice> devices = new LinkedHashMap<>();
    private final Map<Long, RailwayLine> lines = new LinkedHashMap<>();
    private final Map<UUID, Long> activeTrains = new LinkedHashMap<>();
    private final Map<UUID, TrainRecord> trainRegistry = new LinkedHashMap<>();
    private long nextDeviceId = 1L;
    private long nextLineId = 1L;
    private long nextStationNumber = 1L;
    private long nextSwitchNumber = 1L;
    private long nextDepotNumber = 1L;
    private long nextTrainNumber = 1L;
    private double freightSpeedLimitKmh = SpeedRules.FREIGHT_LIMIT_KMH;
    private double passengerSpeedLimitKmh = SpeedRules.PASSENGER_LIMIT_KMH;
    private double expressSpeedLimitKmh = SpeedRules.EXPRESS_LIMIT_KMH;

    public synchronized RailwayDevice find(String dimension, int x, int y, int z) {
        return devices.values().stream().filter(device ->
                device.dimension().equals(dimension) && device.x() == x && device.y() == y && device.z() == z)
                .findFirst().orElse(null);
    }

    public synchronized RailwayDevice register(DeviceType type, String dimension, int x, int y, int z) {
        RailwayDevice existing = find(dimension, x, y, z);
        if (existing != null) {
            return existing;
        }
        long id = nextDeviceId++;
        RailwayDevice device = new RailwayDevice(id, type, dimension, x, y, z,
                defaultName(type, nextDefaultNumber(type)), 30, 1);
        devices.put(id, device);
        setDirty();
        return device;
    }

    public synchronized void remove(String dimension, int x, int y, int z) {
        if (devices.values().removeIf(device -> device.dimension().equals(dimension)
                && device.x() == x && device.y() == y && device.z() == z)) {
            setDirty();
        }
    }

    public synchronized Map<Long, RailwayDevice> devices() {
        return Map.copyOf(devices);
    }

    public synchronized RailwayDevice device(long id) {
        return devices.get(id);
    }

    public synchronized RailwayDevice updateDevice(long id, String name, int dwellSeconds, int switchShapeOrdinal) {
        RailwayDevice device = devices.get(id);
        if (device == null) return null;
        String safeName = name == null || name.isBlank() ? device.name()
                : name.strip().substring(0, Math.min(64, name.strip().length()));
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), safeName, Math.clamp(dwellSeconds, 0, 3600), Math.max(0, switchShapeOrdinal),
                device.announcement(), device.manualUnload());
        devices.put(id, updated);
        setDirty();
        return updated;
    }

    public synchronized RailwayDevice updateDevice(long id, String name, int dwellSeconds, int switchShapeOrdinal, String announcement) {
        RailwayDevice updated=updateDevice(id,name,dwellSeconds,switchShapeOrdinal);
        if(updated==null)return null;
        String safe=announcement==null?"":announcement.strip().substring(0,Math.min(128,announcement.strip().length()));
        updated=new RailwayDevice(updated.id(),updated.type(),updated.dimension(),updated.x(),updated.y(),updated.z(),updated.name(),updated.dwellSeconds(),updated.switchShapeOrdinal(),safe,updated.manualUnload());
        devices.put(id,updated);setDirty();return updated;
    }

    public synchronized RailwayDevice updateManualUnload(long id, boolean manualUnload) {
        RailwayDevice device = devices.get(id);
        if (device == null) return null;
        RailwayDevice updated = new RailwayDevice(device.id(), device.type(), device.dimension(), device.x(), device.y(),
                device.z(), device.name(), device.dwellSeconds(), device.switchShapeOrdinal(), device.announcement(), manualUnload);
        devices.put(id, updated); setDirty(); return updated;
    }

    public synchronized RailwayLine line(long id) {
        return lines.get(id);
    }

    public synchronized Map<Long, RailwayLine> lines() {
        return Map.copyOf(lines);
    }

    public synchronized void registerActiveTrain(UUID trainId, long lineId) {
        Long previous = activeTrains.put(trainId, lineId);
        if (previous == null || previous != lineId) setDirty();
    }

    public synchronized void unregisterActiveTrain(UUID trainId) {
        if (activeTrains.remove(trainId) != null) setDirty();
    }

    public synchronized long activeTrainCount(long lineId) {
        return activeTrains.values().stream().filter(value -> value == lineId).count();
    }

    public synchronized TrainRecord ensureTrain(UUID trainId, boolean depotGenerated, long lineId) {
        TrainRecord existing = trainRegistry.get(trainId);
        if (existing == null) {
            existing = new TrainRecord(trainId, nextTrainNumber++, depotGenerated, Math.max(0L, lineId));
            trainRegistry.put(trainId, existing);
            setDirty();
        } else if ((depotGenerated && !existing.depotGenerated()) || existing.lineId() != lineId) {
            existing = new TrainRecord(trainId, existing.number(),
                    existing.depotGenerated() || depotGenerated, Math.max(0L, lineId));
            trainRegistry.put(trainId, existing);
            setDirty();
        }
        return existing;
    }

    public synchronized TrainRecord trainRecord(UUID trainId) { return trainRegistry.get(trainId); }
    public synchronized Map<UUID, TrainRecord> trainRecords() { return Map.copyOf(trainRegistry); }
    public synchronized void removeTrainRecord(UUID trainId) {
        if (trainRegistry.remove(trainId) != null) setDirty();
    }

    public synchronized void clearActiveTrainsForRestart() {
        if (!activeTrains.isEmpty()) { activeTrains.clear(); setDirty(); }
    }

    public synchronized double classSpeedLimit(TrainClass trainClass) {
        return switch (trainClass) {
            case CARGO -> freightSpeedLimitKmh;
            case PASSENGER -> passengerSpeedLimitKmh;
            case EXPRESS -> expressSpeedLimitKmh;
        };
    }

    public synchronized void updateClassSpeedLimits(double freight, double passenger, double express) {
        if (Double.isFinite(freight) && freight >= 0) freightSpeedLimitKmh = freight;
        if (Double.isFinite(passenger) && passenger >= 0) passengerSpeedLimitKmh = passenger;
        if (Double.isFinite(express) && express >= 0) expressSpeedLimitKmh = express;
        setDirty();
    }

    public synchronized RailwayLine createLine(long depotId) {
        RailwayDevice depot = devices.get(depotId);
        if (depot == null || depot.type() != DeviceType.DEPOT) {
            throw new IllegalArgumentException("Line must start at an existing depot");
        }
        RailwayLine existing = lines.values().stream().filter(line -> line.depotId() == depotId).findFirst().orElse(null);
        if (existing != null) return existing;
        long id = nextLineId++;
        RailwayLine line = new RailwayLine(id, "line-" + id, depotId, java.util.List.of(depotId),
                30, 80.0D, 1, LineStatus.NEEDS_VALIDATION);
        lines.put(id, line);
        setDirty();
        return line;
    }

    public synchronized RailwayLine createEmptyLine(String requestedName) {
        String base = requestedName == null || requestedName.isBlank() ? "线路" + nextLineId : requestedName.strip();
        String safe = base.substring(0, Math.min(64, base.length()));
        if (lines.values().stream().anyMatch(line -> line.name().equalsIgnoreCase(safe))) {
            throw new IllegalArgumentException("Duplicate line name");
        }
        long id = nextLineId++;
        RailwayLine line = new RailwayLine(id, safe, 0L, java.util.List.of(), 30, 80.0D, 1,
                LineStatus.NEEDS_VALIDATION);
        lines.put(id, line);
        setDirty();
        return line;
    }

    public synchronized RailwayLine insertLineNode(long lineId, int index, long deviceId) {
        RailwayLine line = lines.get(lineId);
        RailwayDevice device = devices.get(deviceId);
        if (line == null || device == null) throw new IllegalArgumentException("Unknown line or device");
        if (!line.nodeIds().isEmpty()) {
            RailwayDevice first = devices.get(line.nodeIds().getFirst());
            if (first != null && !first.dimension().equals(device.dimension())) throw new IllegalArgumentException("A line cannot cross dimensions");
        }
        java.util.ArrayList<Long> nodes = new java.util.ArrayList<>(line.nodeIds());
        int insertion = Math.clamp(index, 0, nodes.size());
        nodes.add(insertion, deviceId);
        long depotId = nodes.stream().map(devices::get).filter(java.util.Objects::nonNull)
                .filter(d -> d.type() == DeviceType.DEPOT).mapToLong(RailwayDevice::id).findFirst().orElse(0L);
        java.util.HashMap<Integer,Integer> directions = shiftDirections(line.switchDirections(), insertion, 1);
        if (device.type() == DeviceType.SWITCH) directions.put(insertion, 1);
        RailwayLine updated = new RailwayLine(line.id(), line.name(), depotId, nodes, line.departureIntervalSeconds(),
                line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION, directions);
        lines.put(lineId, updated); setDirty(); return updated;
    }

    public synchronized RailwayLine setSwitchDirection(long lineId, int nodeIndex, int direction) {
        RailwayLine line = lines.get(lineId);
        if (line == null || nodeIndex < 0 || nodeIndex >= line.nodeIds().size()) return line;
        RailwayDevice device = devices.get(line.nodeIds().get(nodeIndex));
        if (device == null || device.type() != DeviceType.SWITCH) return line;
        java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>(line.switchDirections());
        directions.put(nodeIndex, Math.clamp(direction, 0, 2));
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), line.nodeIds(),
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION, directions);
        lines.put(lineId, updated); setDirty(); return updated;
    }

    private static java.util.HashMap<Integer,Integer> shiftDirections(java.util.Map<Integer,Integer> source, int from, int amount) {
        java.util.HashMap<Integer,Integer> result = new java.util.HashMap<>();
        source.forEach((index, direction) -> result.put(index >= from ? index + amount : index, direction));
        return result;
    }

    public synchronized RailwayLine appendLineNode(long lineId, long deviceId) {
        RailwayLine line = lines.get(lineId);
        RailwayDevice device = devices.get(deviceId);
        if (line == null || device == null) {
            throw new IllegalArgumentException("Unknown line or device");
        }
        RailwayDevice depot = devices.get(line.depotId());
        if (!depot.dimension().equals(device.dimension())) {
            throw new IllegalArgumentException("A line cannot cross dimensions");
        }
        RailwayLine updated = line.appendNode(deviceId);
        lines.put(lineId, updated);
        setDirty();
        return updated;
    }

    public synchronized RailwayLine modifyLineNode(long lineId, int index, int action) {
        RailwayLine line = lines.get(lineId);
        if (line == null || index <= 0 || index >= line.nodeIds().size()) return line;
        java.util.ArrayList<Long> nodes = new java.util.ArrayList<>(line.nodeIds());
        if (action == 0 && index > 1) java.util.Collections.swap(nodes, index, index - 1);
        else if (action == 1 && index < nodes.size() - 1) java.util.Collections.swap(nodes, index, index + 1);
        else if (action == 2) nodes.remove(index);
        else return line;
        java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>();
        line.switchDirections().forEach((oldIndex, direction) -> {
            int newIndex = oldIndex;
            if (action == 0 && index > 1) { if (oldIndex == index) newIndex = index - 1; else if (oldIndex == index - 1) newIndex = index; }
            else if (action == 1 && index < line.nodeIds().size() - 1) { if (oldIndex == index) newIndex = index + 1; else if (oldIndex == index + 1) newIndex = index; }
            else if (action == 2) { if (oldIndex == index) return; if (oldIndex > index) newIndex = oldIndex - 1; }
            directions.put(newIndex, direction);
        });
        long depotId = nodes.stream().map(devices::get).filter(java.util.Objects::nonNull)
                .filter(d -> d.type() == DeviceType.DEPOT).mapToLong(RailwayDevice::id).findFirst().orElse(0L);
        RailwayLine updated = new RailwayLine(line.id(), line.name(), depotId, nodes,
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), LineStatus.NEEDS_VALIDATION, directions);
        lines.put(lineId, updated);
        setDirty();
        return updated;
    }

    public synchronized boolean deleteLine(long lineId) {
        boolean removed = lines.remove(lineId) != null;
        if (removed) setDirty();
        return removed;
    }

    public synchronized RailwayLine setLineStatus(long lineId, LineStatus status) {
        RailwayLine line = lines.get(lineId);
        if (line == null) return null;
        RailwayLine updated = new RailwayLine(line.id(), line.name(), line.depotId(), line.nodeIds(),
                line.departureIntervalSeconds(), line.speedLimitKmh(), line.maximumTrains(), status, line.switchDirections());
        lines.put(lineId, updated);
        setDirty();
        return updated;
    }

    public synchronized RailwayLine updateLineSettings(long lineId, String name, int intervalSeconds, double speedKmh,
                                                        int maximumTrains, LineStatus status) {
        RailwayLine line = lines.get(lineId);
        if (line == null) return null;
        int interval = Math.clamp(intervalSeconds, 0, 3600);
        double speed = Double.isFinite(speedKmh) ? Math.max(0.0D, speedKmh) : line.speedLimitKmh();
        int maximum = Math.clamp(maximumTrains, 1, 1000);
        String safeName = name == null || name.isBlank() ? "line-" + line.id()
                : name.strip().substring(0, Math.min(64, name.strip().length()));
        RailwayLine updated = new RailwayLine(line.id(), safeName, line.depotId(), line.nodeIds(),
                interval, speed, maximum, status, line.switchDirections());
        lines.put(lineId, updated);
        setDirty();
        return updated;
    }

    private static String defaultName(DeviceType type, long id) {
        return switch (type) {
            case STATION -> "站点" + id;
            case DEPOT -> "车辆段" + id;
            case SWITCH -> "道岔" + id;
        };
    }

    private long nextDefaultNumber(DeviceType type) {
        return switch (type) {
            case STATION -> nextStationNumber++;
            case SWITCH -> nextSwitchNumber++;
            case DEPOT -> nextDepotNumber++;
        };
    }

    private static RailwaySavedData fromDynamic(Dynamic<?> dynamic) {
        CompoundTag tag = (CompoundTag) dynamic.convert(NbtOps.INSTANCE).getValue();
        RailwaySavedData data = new RailwaySavedData();
        data.nextDeviceId = Math.max(1L, tag.getLongOr("NextDeviceId", 1L));
        data.nextLineId = Math.max(1L, tag.getLongOr("NextLineId", 1L));
        data.nextStationNumber = Math.max(1L, tag.getLongOr("NextStationNumber", 1L));
        data.nextSwitchNumber = Math.max(1L, tag.getLongOr("NextSwitchNumber", 1L));
        data.nextDepotNumber = Math.max(1L, tag.getLongOr("NextDepotNumber", 1L));
        data.freightSpeedLimitKmh = validSpeed(tag.getDoubleOr("FreightSpeedLimitKmh", SpeedRules.FREIGHT_LIMIT_KMH), SpeedRules.FREIGHT_LIMIT_KMH);
        data.passengerSpeedLimitKmh = validSpeed(tag.getDoubleOr("PassengerSpeedLimitKmh", SpeedRules.PASSENGER_LIMIT_KMH), SpeedRules.PASSENGER_LIMIT_KMH);
        data.expressSpeedLimitKmh = validSpeed(tag.getDoubleOr("ExpressSpeedLimitKmh", SpeedRules.EXPRESS_LIMIT_KMH), SpeedRules.EXPRESS_LIMIT_KMH);
        ListTag list = tag.getListOrEmpty("Devices");
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompoundOrEmpty(i);
            long id = entry.getLongOr("Id", 0L);
            try {
                DeviceType type = DeviceType.valueOf(entry.getStringOr("Type", "STATION"));
                RailwayDevice device = new RailwayDevice(id, type,
                        entry.getStringOr("Dimension", "minecraft:overworld"),
                        entry.getIntOr("X", 0), entry.getIntOr("Y", 0), entry.getIntOr("Z", 0),
                        migrateDefaultName(type, id, entry.getStringOr("Name", defaultName(type, id))),
                        Math.clamp(entry.getIntOr("DwellSeconds", 30), 0, 3600),
                        Math.max(0, entry.getIntOr("SwitchShapeOrdinal", 0)), entry.getStringOr("Announcement", ""),
                        entry.getBooleanOr("ManualUnload", false));
                if (id > 0) data.devices.put(id, device);
            } catch (IllegalArgumentException ignored) {
                // Unknown future device types are skipped instead of corrupting the world load.
            }
        }
        if (!tag.contains("NextStationNumber")) data.nextStationNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.STATION).count();
        if (!tag.contains("NextSwitchNumber")) data.nextSwitchNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.SWITCH).count();
        if (!tag.contains("NextDepotNumber")) data.nextDepotNumber = 1L + data.devices.values().stream().filter(d -> d.type() == DeviceType.DEPOT).count();
        ListTag lineList = tag.getListOrEmpty("Lines");
        for (int i = 0; i < lineList.size(); i++) {
            CompoundTag entry = lineList.getCompoundOrEmpty(i);
            java.util.ArrayList<Long> nodes = new java.util.ArrayList<>();
            ListTag nodeList = entry.getListOrEmpty("Nodes");
            for (int j = 0; j < nodeList.size(); j++) {
                nodes.add(nodeList.getCompoundOrEmpty(j).getLongOr("Id", 0L));
            }
            java.util.HashMap<Integer,Integer> directions = new java.util.HashMap<>();
            ListTag directionList = entry.getListOrEmpty("SwitchDirections");
            for (int j = 0; j < directionList.size(); j++) {
                CompoundTag direction = directionList.getCompoundOrEmpty(j);
                directions.put(direction.getIntOr("Index", -1), direction.getIntOr("Direction", -1));
            }
            try {
                RailwayLine line = new RailwayLine(
                        entry.getLongOr("Id", 0L), entry.getStringOr("Name", "line"),
                        entry.getLongOr("DepotId", 0L), nodes,
                        entry.getIntOr("DepartureIntervalSeconds", 30),
                        entry.getDoubleOr("SpeedLimitKmh", 80.0D),
                        entry.getIntOr("MaximumTrains", 1),
                        LineStatus.valueOf(entry.getStringOr("Status", "NEEDS_VALIDATION")), directions);
                data.lines.put(line.id(), line);
            } catch (IllegalArgumentException ignored) {
                // Invalid lines are skipped so one bad record cannot prevent world loading.
            }
        }
        ListTag trainList = tag.getListOrEmpty("ActiveTrains");
        for (int i = 0; i < trainList.size(); i++) {
            CompoundTag entry = trainList.getCompoundOrEmpty(i);
            try {
                UUID trainId = UUID.fromString(entry.getStringOr("TrainId", ""));
                long lineId = entry.getLongOr("LineId", 0L);
                if (lineId > 0) data.activeTrains.put(trainId, lineId);
            } catch (IllegalArgumentException ignored) { }
        }
        data.nextTrainNumber = Math.max(1L, tag.getLongOr("NextTrainNumber", 1L));
        ListTag registryList = tag.getListOrEmpty("TrainRegistry");
        for (int i = 0; i < registryList.size(); i++) {
            CompoundTag entry = registryList.getCompoundOrEmpty(i);
            try {
                UUID trainId = UUID.fromString(entry.getStringOr("TrainId", ""));
                long number = Math.max(1L, entry.getLongOr("Number", 1L));
                data.trainRegistry.put(trainId, new TrainRecord(trainId, number,
                        entry.getBooleanOr("DepotGenerated", false), entry.getLongOr("LineId", 0L)));
                data.nextTrainNumber = Math.max(data.nextTrainNumber, number + 1L);
            } catch (IllegalArgumentException ignored) { }
        }
        return data;
    }

    private Dynamic<?> toDynamic() {
        CompoundTag tag = new CompoundTag();
        tag.putLong("NextDeviceId", nextDeviceId);
        tag.putLong("NextLineId", nextLineId);
        tag.putLong("NextStationNumber", nextStationNumber);
        tag.putLong("NextSwitchNumber", nextSwitchNumber);
        tag.putLong("NextDepotNumber", nextDepotNumber);
        tag.putLong("NextTrainNumber", nextTrainNumber);
        tag.putDouble("FreightSpeedLimitKmh", freightSpeedLimitKmh);
        tag.putDouble("PassengerSpeedLimitKmh", passengerSpeedLimitKmh);
        tag.putDouble("ExpressSpeedLimitKmh", expressSpeedLimitKmh);
        ListTag list = new ListTag();
        devices.values().forEach(device -> {
            CompoundTag entry = new CompoundTag();
            entry.putLong("Id", device.id());
            entry.putString("Type", device.type().name());
            entry.putString("Dimension", device.dimension());
            entry.putInt("X", device.x());
            entry.putInt("Y", device.y());
            entry.putInt("Z", device.z());
            entry.putString("Name", device.name());
            entry.putInt("DwellSeconds", device.dwellSeconds());
            entry.putInt("SwitchShapeOrdinal", device.switchShapeOrdinal());
            entry.putString("Announcement", device.announcement());
            entry.putBoolean("ManualUnload", device.manualUnload());
            list.add(entry);
        });
        tag.put("Devices", list);
        ListTag lineList = new ListTag();
        lines.values().forEach(line -> {
            CompoundTag entry = new CompoundTag();
            entry.putLong("Id", line.id());
            entry.putString("Name", line.name());
            entry.putLong("DepotId", line.depotId());
            entry.putInt("DepartureIntervalSeconds", line.departureIntervalSeconds());
            entry.putDouble("SpeedLimitKmh", line.speedLimitKmh());
            entry.putInt("MaximumTrains", line.maximumTrains());
            entry.putString("Status", line.status().name());
            ListTag nodes = new ListTag();
            line.nodeIds().forEach(nodeId -> {
                CompoundTag node = new CompoundTag();
                node.putLong("Id", nodeId);
                nodes.add(node);
            });
            entry.put("Nodes", nodes);
            ListTag directions = new ListTag();
            line.switchDirections().forEach((index, direction) -> {
                CompoundTag value = new CompoundTag();
                value.putInt("Index", index); value.putInt("Direction", direction); directions.add(value);
            });
            entry.put("SwitchDirections", directions);
            lineList.add(entry);
        });
        tag.put("Lines", lineList);
        ListTag trainList = new ListTag();
        activeTrains.forEach((trainId, lineId) -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("TrainId", trainId.toString());
            entry.putLong("LineId", lineId);
            trainList.add(entry);
        });
        tag.put("ActiveTrains", trainList);
        ListTag registryList = new ListTag();
        trainRegistry.values().forEach(record -> {
            CompoundTag entry = new CompoundTag();
            entry.putString("TrainId", record.trainId().toString());
            entry.putLong("Number", record.number());
            entry.putBoolean("DepotGenerated", record.depotGenerated());
            entry.putLong("LineId", record.lineId());
            registryList.add(entry);
        });
        tag.put("TrainRegistry", registryList);
        return new Dynamic<>(NbtOps.INSTANCE, tag);
    }

    private static String migrateDefaultName(DeviceType type, long id, String name) {
        if (name.equals("station-" + id) || name.equals("switch-" + id) || name.equals("depot-" + id)) {
            return defaultName(type, id);
        }
        return name;
    }

    private static double validSpeed(double value, double fallback) { return Double.isFinite(value) && value >= 0 ? value : fallback; }
}
