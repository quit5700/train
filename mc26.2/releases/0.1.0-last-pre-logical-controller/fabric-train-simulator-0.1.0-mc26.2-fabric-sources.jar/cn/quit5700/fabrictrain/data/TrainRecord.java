package cn.quit5700.fabrictrain.data;

import java.util.UUID;

public record TrainRecord(UUID trainId, long number, boolean depotGenerated, long lineId) {}
