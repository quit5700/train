package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.network.DepotNetworking;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.registry.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

public final class DeviceInteractionService {
    private DeviceInteractionService() {}

    public static InteractionResult interact(Player player, Level level, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND || player.getItemInHand(hand).is(ModItems.LINE_SETTER)) {
            return InteractionResult.PASS;
        }
        var state = level.getBlockState(hit.getBlockPos());
        DeviceType type;
        if (state.is(ModBlocks.STATION_MARKER)) type = DeviceType.STATION;
        else if (state.is(ModBlocks.SWITCH_RAIL)) type = DeviceType.SWITCH;
        else if (state.is(ModBlocks.TRAIN_DEPOT)) type = DeviceType.DEPOT;
        else return InteractionResult.PASS;
        if (level.isClientSide()) return InteractionResult.SUCCESS;
        ServerLevel serverLevel = (ServerLevel) level;
        ServerPlayer serverPlayer = (ServerPlayer) player;
        RailwayDevice device = RailwayDataManager.register(serverLevel, hit.getBlockPos(), type);
        if (type == DeviceType.DEPOT && level.getBlockEntity(hit.getBlockPos()) instanceof TrainDepotBlockEntity depot) {
            if (player.isShiftKeyDown()) DepotNetworking.open(serverPlayer, hit.getBlockPos(), depot);
            else serverPlayer.openMenu(depot);
        } else {
            DeviceSettingsNetworking.open(serverPlayer, device);
        }
        return InteractionResult.SUCCESS;
    }
}
