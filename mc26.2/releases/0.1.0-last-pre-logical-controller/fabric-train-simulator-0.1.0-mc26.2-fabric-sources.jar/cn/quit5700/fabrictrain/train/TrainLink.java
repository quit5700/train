package cn.quit5700.fabrictrain.train;

import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import java.util.UUID;

public final class TrainLink {
    private UUID trainId;
    private UUID locomotiveId;
    private int carIndex;
    private long lineId;
    private TrainClass trainClass = TrainClass.PASSENGER;
    private boolean loadedFromSave;
    private UUID savedSessionId = TrainSession.current();
    private int nextNodeIndex = 1;
    private long lastDeviceId;
    private long lockedSwitchId;
    private boolean automaticRunning;
    private long destinationStationId;
    private boolean parked=true;
    private boolean locomotivePresent;
    private boolean depotGenerated;

    public TrainLink() {
        UUID standalone = UUID.randomUUID();
        trainId = standalone;
        locomotiveId = standalone;
    }

    public void assign(UUID trainId, UUID locomotiveId, int carIndex) {
        assign(trainId, locomotiveId, carIndex, lineId);
    }

    public void assign(UUID trainId, UUID locomotiveId, int carIndex, long lineId) {
        if (carIndex < 0) throw new IllegalArgumentException("Car index cannot be negative");
        if (lineId < 0) throw new IllegalArgumentException("Line id cannot be negative");
        this.trainId = trainId;
        this.locomotiveId = locomotiveId;
        this.carIndex = carIndex;
        this.lineId = lineId;
        this.locomotivePresent = true;
    }

    public void assignWithoutLocomotive(UUID trainId, int carIndex) {
        if (carIndex < 0) throw new IllegalArgumentException("Car index cannot be negative");
        this.trainId = trainId;
        this.locomotiveId = new UUID(0L, 0L);
        this.carIndex = carIndex;
        this.lineId = 0L;
        this.locomotivePresent = false;
        this.automaticRunning = false;
    }

    public UUID trainId() { return trainId; }
    public UUID locomotiveId() { return locomotiveId; }
    public int carIndex() { return carIndex; }
    public long lineId() { return lineId; }
    public void detachFromLine() {
        lineId = 0L;
        automaticRunning = false;
        nextNodeIndex = 1;
        lastDeviceId = 0L;
        lockedSwitchId = 0L;
    }
    public TrainClass trainClass() { return trainClass; }
    public void setTrainClass(TrainClass requested) { trainClass = requested == null ? TrainClass.PASSENGER : requested; }
    public boolean loadedFromSave() { return loadedFromSave; }
    public void markStartupRecovered() { loadedFromSave = false; }
    public int nextNodeIndex() { return nextNodeIndex; }
    public long lastDeviceId() { return lastDeviceId; }
    public long lockedSwitchId() { return lockedSwitchId; }
    public void updateRouteProgress(int nextNodeIndex, long lastDeviceId, long lockedSwitchId) {
        this.nextNodeIndex = Math.max(1, nextNodeIndex);
        this.lastDeviceId = Math.max(0L, lastDeviceId);
        this.lockedSwitchId = Math.max(0L, lockedSwitchId);
    }
    public boolean automaticRunning() { return automaticRunning; }
    public void setAutomaticRunning(boolean value) { automaticRunning = value;if(value)parked=false; }
    public boolean parked(){return parked;}
    public void setParked(boolean value){parked=value;if(value)automaticRunning=false;}
    public boolean hasLocomotive(){return locomotivePresent;}
    public boolean depotGenerated(){return depotGenerated;}
    public void setDepotGenerated(boolean value){depotGenerated=value;}
    public boolean standalone(){return !locomotivePresent&&carIndex==0;}
    public long destinationStationId(){return destinationStationId;}
    public void setDestinationStationId(long value){destinationStationId=Math.max(0,value);}
    public void detach(UUID entityId){trainId=entityId;locomotiveId=new UUID(0L,0L);carIndex=0;lineId=0;locomotivePresent=false;automaticRunning=false;nextNodeIndex=1;lastDeviceId=0;lockedSwitchId=0;destinationStationId=0;}

    public void load(ValueInput input) {
        trainId = parse(input.getStringOr("TrainId", trainId.toString()), trainId);
        locomotiveId = parse(input.getStringOr("LocomotiveId", locomotiveId.toString()), locomotiveId);
        carIndex = Math.max(0, input.getIntOr("CarIndex", 0));
        lineId = Math.max(0L, input.getLongOr("LineId", 0L));
        try { trainClass = TrainClass.valueOf(input.getStringOr("TrainClass", TrainClass.PASSENGER.name())); }
        catch (IllegalArgumentException ignored) { trainClass = TrainClass.PASSENGER; }
        savedSessionId = parse(input.getStringOr("ServerSessionId", new UUID(0L, 0L).toString()), new UUID(0L, 0L));
        loadedFromSave = !savedSessionId.equals(TrainSession.current());
        nextNodeIndex = Math.max(1, input.getIntOr("NextNodeIndex", 1));
        lastDeviceId = Math.max(0L, input.getLongOr("LastDeviceId", 0L));
        lockedSwitchId = Math.max(0L, input.getLongOr("LockedSwitchId", 0L));
        automaticRunning = input.getBooleanOr("AutomaticRunning", false);
        destinationStationId=Math.max(0,input.getLongOr("DestinationStationId",0L));
        parked=input.getBooleanOr("Parked",false);
        locomotivePresent=input.getBooleanOr("LocomotivePresent", !locomotiveId.equals(new UUID(0L,0L)));
        depotGenerated=input.getBooleanOr("DepotGenerated",false);
    }

    public void save(ValueOutput output) {
        output.putString("TrainId", trainId.toString());
        output.putString("LocomotiveId", locomotiveId.toString());
        output.putInt("CarIndex", carIndex);
        output.putLong("LineId", lineId);
        output.putString("TrainClass", trainClass.name());
        output.putString("ServerSessionId", TrainSession.current().toString());
        output.putInt("NextNodeIndex", nextNodeIndex);
        output.putLong("LastDeviceId", lastDeviceId);
        output.putLong("LockedSwitchId", lockedSwitchId);
        output.putBoolean("AutomaticRunning", automaticRunning);
        output.putLong("DestinationStationId",destinationStationId);
        output.putBoolean("Parked",parked);
        output.putBoolean("LocomotivePresent",locomotivePresent);
        output.putBoolean("DepotGenerated",depotGenerated);
    }

    private static UUID parse(String value, UUID fallback) {
        try { return UUID.fromString(value); } catch (IllegalArgumentException ignored) { return fallback; }
    }
}
