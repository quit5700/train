package cn.quit5700.fabrictrain.train;

public final class TrainRegistryRules {
    private TrainRegistryRules() {}

    public static boolean canMerge(boolean firstDepotGenerated, boolean secondDepotGenerated) {
        return firstDepotGenerated == secondDepotGenerated;
    }

    public static int inheritedSide(boolean frontHasLocomotive, boolean rearHasLocomotive) {
        return rearHasLocomotive && !frontHasLocomotive ? 1 : 0;
    }
}
