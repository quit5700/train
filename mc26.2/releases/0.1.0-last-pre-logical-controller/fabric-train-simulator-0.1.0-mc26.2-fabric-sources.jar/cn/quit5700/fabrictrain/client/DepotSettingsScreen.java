package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.network.DepotNetworking;
import cn.quit5700.fabrictrain.train.CarType;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class DepotSettingsScreen extends Screen {
    private final BlockPos depotPos;
    private final ArrayList<CarType> cars;
    private final List<DepotNetworking.LineOption> lines;
    private int lineIndex = -1;
    private TrainClass trainClass;
    private int interval;
    private int maximum;
    private final long active;
    private Button lineButton;
    private Button dispatchButton;

    public DepotSettingsScreen(DepotNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                Component.translatable("screen.fabric_train_simulator.depot.title"));
        depotPos = payload.pos();
        cars = new ArrayList<>(DepotTemplate.decode(payload.template()).cars());
        lines = payload.lines();
        for (int i = 0; i < lines.size(); i++) if (lines.get(i).id() == payload.lineId()) lineIndex = i;
        trainClass = TrainClass.values()[Math.clamp(payload.trainClass(), 0, TrainClass.values().length - 1)];
        interval = payload.interval();
        maximum = payload.maximum();
        active = payload.active();
    }

    @Override protected void init() {
        int left=width/2-110,top=height/2-125;
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.passenger"),b->choose(TrainClass.PASSENGER)).bounds(left+10,top+32,62,20).build()).active=!hasCargo();
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.cargo"),b->choose(TrainClass.CARGO)).bounds(left+79,top+32,62,20).build());
        addRenderableWidget(Button.builder(Component.translatable("class.fabric_train_simulator.express"),b->choose(TrainClass.EXPRESS)).bounds(left+148,top+32,62,20).build()).active=!hasCargo();
        lineButton=addRenderableWidget(Button.builder(lineLabel(),b->{
            lineIndex = lines.isEmpty() ? -1 : (lineIndex >= lines.size()-1 ? -1 : lineIndex+1);
            b.setMessage(lineLabel()); updateDispatchButton();
        }).bounds(left+10,top+61,200,20).build());
        addRenderableWidget(Button.builder(Component.literal("-5"),b->interval=Math.max(1,interval-5)).bounds(left+10,top+90,55,20).build());
        addRenderableWidget(Button.builder(Component.literal("+5"),b->interval=Math.min(3600,interval+5)).bounds(left+70,top+90,55,20).build());
        addRenderableWidget(Button.builder(Component.literal("-1"),b->maximum=Math.max(1,maximum-1)).bounds(left+130,top+90,38,20).build());
        addRenderableWidget(Button.builder(Component.literal("+1"),b->maximum=Math.min(1000,maximum+1)).bounds(left+172,top+90,38,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.add_passenger"),b->add(CarType.PASSENGER)).bounds(left+10,top+137,96,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.add_cargo"),b->add(CarType.CARGO)).bounds(left+114,top+137,96,20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.remove"),b->{if(cars.size()>1)cars.removeLast();}).bounds(left+10,top+163,96,20).build());
        dispatchButton=addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.dispatch_now"),b->send(true)).bounds(left+114,top+163,96,20).build());
        updateDispatchButton();
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.save"),b->send(false)).bounds(left+75,top+211,70,20).build());
    }
    private boolean hasCargo(){return cars.contains(CarType.CARGO);}
    private void choose(TrainClass value){trainClass=hasCargo()?TrainClass.CARGO:value;}
    private void add(CarType type){if(cars.size()<100){cars.add(type);if(type==CarType.CARGO)trainClass=TrainClass.CARGO;}}
    private Component lineLabel(){return lineIndex<0?Component.translatable("screen.fabric_train_simulator.depot.no_line"):Component.literal(lines.get(lineIndex).name()+" ▼");}
    private void updateDispatchButton(){if(dispatchButton!=null)dispatchButton.active=lineIndex>=0;}
    private void send(boolean now){long line=lineIndex<0?0:lines.get(lineIndex).id();ClientPlayNetworking.send(new DepotNetworking.UpdatePayload(depotPos,new DepotTemplate(cars).encode(),line,trainClass.ordinal(),interval,maximum,now));if(!now)onClose();}

    @Override public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float tickProgress){
        int left=width/2-110,top=height/2-125;g.fill(left,top,left+220,top+250,0xE020232A);g.outline(left,top,220,250,0xFF66CCFF);g.centeredText(font,title,width/2,top+10,0xFFFFFFFF);
        g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.interval",interval),width/2-45,top+116,0xFFE6E6E6);
        g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.active",active,maximum),width/2+55,top+116,0xFFE6E6E6);
        long passengers=cars.stream().filter(t->t==CarType.PASSENGER).count();g.centeredText(font,Component.translatable("screen.fabric_train_simulator.depot.summary",cars.size(),passengers,cars.size()-passengers),width/2,top+190,0xFFE6E6E6);
        super.extractRenderState(g,mouseX,mouseY,tickProgress);
    }
}
