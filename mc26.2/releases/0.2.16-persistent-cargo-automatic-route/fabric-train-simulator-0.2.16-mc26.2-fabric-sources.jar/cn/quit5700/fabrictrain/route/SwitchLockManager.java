package cn.quit5700.fabrictrain.route;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SwitchLockManager {
    private final Map<Long, UUID> owners = new HashMap<>();

    public boolean tryAcquire(long switchId, UUID trainId) {
        UUID current = owners.get(switchId);
        if (current == null || current.equals(trainId)) {
            owners.put(switchId, trainId);
            return true;
        }
        return false;
    }

    public boolean release(long switchId, UUID trainId) {
        return owners.remove(switchId, trainId);
    }

    public void releaseAll(UUID trainId) {
        owners.values().removeIf(trainId::equals);
    }

    public void clearOnWorldRestart() {
        owners.clear();
    }
}
