package cn.quit5700.fabrictrain.route;

public final class SwitchPassageState {
    private static final double ENTER_DISTANCE_SQUARED = 4.0D;
    private static final double CLEAR_DISTANCE_SQUARED = 16.0D;
    private boolean entered;

    public boolean observe(double... vehicleDistanceSquared) {
        if (!entered) {
            for (double distance : vehicleDistanceSquared) {
                if (distance <= ENTER_DISTANCE_SQUARED) {
                    entered = true;
                    break;
                }
            }
        }
        if (!entered || vehicleDistanceSquared.length == 0) return false;
        for (double distance : vehicleDistanceSquared) {
            if (distance <= CLEAR_DISTANCE_SQUARED) return false;
        }
        return true;
    }
}
