package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.network.DeviceSettingsNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.core.Direction;

public final class DeviceSettingsScreen extends Screen {
    private final long deviceId;
    private final DeviceType type;
    private int dwellSeconds;
    private int cargoDwellSeconds;
    private int switchShape;
    private int switchEntryOrdinal;
    private EditBox name;
    private EditBox announcement;
    private final boolean containerConnected;
    private int scrollOffset;

    public DeviceSettingsScreen(DeviceSettingsNetworking.OpenPayload payload) {
        super(Minecraft.getInstance(), Minecraft.getInstance().font,
                titleFor(payload));
        deviceId = payload.deviceId();
        type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        dwellSeconds = payload.dwellSeconds();
        cargoDwellSeconds = payload.cargoDwellSeconds();
        switchShape = Math.clamp(payload.switchShapeOrdinal(), 0, 2);
        switchEntryOrdinal = payload.switchEntryOrdinal();
        if(switchEntry().getAxis()==Direction.Axis.Y)switchEntryOrdinal=Direction.NORTH.ordinal();
        name = new EditBox(font, 190, 20, Component.translatable("screen.fabric_train_simulator.device.name"));
        name.setMaxLength(64);
        name.setValue(payload.name());
        announcement = new EditBox(font, 190, 20, Component.translatable("screen.fabric_train_simulator.station.announcement"));
        announcement.setMaxLength(128); announcement.setValue(payload.announcement());
        containerConnected = payload.containerConnected();
    }

    @Override protected void init() {
        boolean compact = height < 304;
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(width, height, 220, compact ? 242 : 304, 20);
        int left = layout.left();
        int top = layout.top();
        int nameY = top + (compact ? 38 : 48) - scrollOffset;
        name.setX(left + 15); name.setY(nameY); addRenderableWidget(name);
        name.visible = insideContent(nameY, layout, type == DeviceType.STATION ? layout.footerY() - 28 : layout.footerY());
        if(type==DeviceType.STATION){
            int announcementY=top+(compact?142:192)-scrollOffset;
            announcement.setX(left+15);announcement.setY(announcementY);addRenderableWidget(announcement);
            announcement.visible=insideContent(announcementY,layout,layout.footerY()-28);
        }
        if (type == DeviceType.STATION) {
            int dwellY=top+(compact?76:102)-scrollOffset,cargoY=top+(compact?110:146)-scrollOffset;
            addContentButton(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.minus_five"), b -> dwellSeconds = Math.max(0, dwellSeconds - 5)).bounds(left + 15, dwellY, 70, 20).build(),layout,layout.footerY()-28);
            addContentButton(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.plus_five"), b -> dwellSeconds = Math.min(3600, dwellSeconds + 5)).bounds(left + 135, dwellY, 70, 20).build(),layout,layout.footerY()-28);
            addContentButton(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.minus_five"), b -> cargoDwellSeconds = Math.max(0, cargoDwellSeconds - 5)).bounds(left + 15, cargoY, 70, 20).build(),layout,layout.footerY()-28);
            addContentButton(Button.builder(Component.translatable("screen.fabric_train_simulator.depot.plus_five"), b -> cargoDwellSeconds = Math.min(3600, cargoDwellSeconds + 5)).bounds(left + 135, cargoY, 70, 20).build(),layout,layout.footerY()-28);
        }
        if (type == DeviceType.SWITCH) {
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.left"), b -> switchShape = 0).bounds(left + 10, top + 90, 62, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.straight"), b -> switchShape = 1).bounds(left + 79, top + 90, 62, 20).build());
            addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.switch.right"), b -> switchShape = 2).bounds(left + 148, top + 90, 62, 20).build());
            addRenderableWidget(entryButton(Direction.NORTH,left+10,top+145));
            addRenderableWidget(entryButton(Direction.EAST,left+61,top+145));
            addRenderableWidget(entryButton(Direction.SOUTH,left+112,top+145));
            addRenderableWidget(entryButton(Direction.WEST,left+163,top+145));
        }
        addRenderableWidget(Button.builder(Component.translatable("screen.fabric_train_simulator.device.save"), b -> save()).bounds(left + 75, layout.footerY(), 70, 20).build());
    }

    private void addContentButton(Button button, ResponsiveScreenLayout layout, int bottom) {
        button.visible = insideContent(button.getY(), layout, bottom);
        addRenderableWidget(button);
    }

    private static boolean insideContent(int y, ResponsiveScreenLayout layout, int bottom) {
        return y >= layout.scrollTop() && y + 20 <= bottom;
    }

    @Override public boolean mouseScrolled(double mouseX,double mouseY,double horizontal,double vertical) {
        boolean compact=height<304;ResponsiveScreenLayout layout=ResponsiveScreenLayout.of(width,height,220,compact?242:304,20);
        if(!layout.scrollRequired())return super.mouseScrolled(mouseX,mouseY,horizontal,vertical);
        int maximum=compact?Math.max(0,242-layout.panelHeight()):Math.max(0,304-layout.panelHeight());
        int next=Math.clamp(scrollOffset-(int)Math.signum(vertical)*20,0,maximum);
        if(next==scrollOffset)return false;scrollOffset=next;rebuildWidgets();return true;
    }

    private static Component titleFor(DeviceSettingsNetworking.OpenPayload payload) {
        DeviceType type = DeviceType.values()[Math.clamp(payload.typeOrdinal(), 0, DeviceType.values().length - 1)];
        return Component.translatable(type == DeviceType.STATION
                ? "screen.fabric_train_simulator.station.named_title"
                : "screen.fabric_train_simulator.switch.named_title", payload.name());
    }
    private void save() {
        ClientPlayNetworking.send(new DeviceSettingsNetworking.UpdatePayload(deviceId, name.getValue(), dwellSeconds,
                cargoDwellSeconds, switchShape, switchEntryOrdinal, announcement.getValue()));
        onClose();
    }

    @Override public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float tickProgress) {
        boolean compact=height<304;ResponsiveScreenLayout layout=ResponsiveScreenLayout.of(width,height,220,compact?242:304,20);
        int left = layout.left();
        int top = layout.top();
        graphics.fill(left, top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.outline(left, top, layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.centeredText(font, title, width / 2, top + 10, 0xFFFFFFFF);
        int nameLabelY=top+(compact?26:35)-scrollOffset;
        if(insideContent(nameLabelY,layout,type==DeviceType.STATION?layout.footerY()-28:layout.footerY()))graphics.text(font, Component.translatable("screen.fabric_train_simulator.device.name"), left + 15, nameLabelY, 0xFFCCCCCC);
        int dwellLabelY=top+(compact?62:87)-scrollOffset;
        if (type == DeviceType.STATION&&insideContent(dwellLabelY,layout,layout.footerY()-28)) graphics.centeredText(font,
                Component.translatable("screen.fabric_train_simulator.device.dwell", dwellSeconds), width / 2, dwellLabelY, 0xFFE6E6E6);
        if(type==DeviceType.STATION) {
            int cargoLabelY=top+(compact?96:131)-scrollOffset,announcementLabelY=top+(compact?130:179)-scrollOffset,containerY=top+(compact?166:218)-scrollOffset;
            if(insideContent(cargoLabelY,layout,layout.footerY()-28))graphics.centeredText(font, Component.translatable("screen.fabric_train_simulator.station.cargo_dwell", cargoDwellSeconds), width / 2, cargoLabelY, 0xFFE6E6E6);
            if(insideContent(announcementLabelY,layout,layout.footerY()-28))graphics.text(font,Component.translatable("screen.fabric_train_simulator.station.announcement"),left+15,announcementLabelY,0xFFCCCCCC);
            if(insideContent(containerY,layout,layout.footerY()-28))graphics.centeredText(font, Component.translatable(containerConnected
                    ? "screen.fabric_train_simulator.station.container_connected"
                    : "screen.fabric_train_simulator.station.container_disconnected"), width / 2, containerY, 0xFFE6E6E6);
        }
        if (type == DeviceType.SWITCH) graphics.centeredText(font,
                Component.translatable("screen.fabric_train_simulator.device.shape",
                        Component.translatable("screen.fabric_train_simulator.switch." + switchName())), width / 2, top + 120, 0xFFE6E6E6);
        if(type==DeviceType.SWITCH)graphics.centeredText(font,
                Component.translatable("screen.fabric_train_simulator.switch.entry",
                        Component.translatable("screen.fabric_train_simulator.direction."+switchEntry().getSerializedName())),
                width/2,top+132,0xFFE6E6E6);
        super.extractRenderState(graphics, mouseX, mouseY, tickProgress);
    }

    private String switchName() { return switch (switchShape) { case 0 -> "left"; case 2 -> "right"; default -> "straight"; }; }
    private Direction switchEntry(){
        if(switchEntryOrdinal<0||switchEntryOrdinal>=Direction.values().length)return Direction.NORTH;
        return Direction.values()[switchEntryOrdinal];
    }
    private Button entryButton(Direction direction,int x,int y){
        return Button.builder(Component.translatable("screen.fabric_train_simulator.direction."+direction.getSerializedName()),
                b->switchEntryOrdinal=direction.ordinal()).bounds(x,y,47,20).build();
    }
}
