package cn.quit5700.fabrictrain.mixin.client;

import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.train.DepotSettingsGesture;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = Minecraft.class, priority = 2000)
abstract class MinecraftUseItemMixin {
    @Inject(method = "startUseItem", at = @At("HEAD"), cancellable = true)
    private void fabricTrain$openDepotSettingsBeforeOtherInteractions(CallbackInfo callback) {
        Minecraft minecraft = (Minecraft) (Object) this;
        if (minecraft.level == null || minecraft.player == null
                || !(minecraft.hitResult instanceof BlockHitResult hit)) return;
        boolean control = InputConstants.isKeyDown(minecraft.getWindow(), InputConstants.KEY_LCONTROL)
                || InputConstants.isKeyDown(minecraft.getWindow(), InputConstants.KEY_RCONTROL);
        if (!control || !minecraft.level.getBlockState(hit.getBlockPos()).is(ModBlocks.TRAIN_DEPOT)) return;
        if (DepotSettingsGesture.tryOpen(hit.getBlockPos())) callback.cancel();
    }
}
