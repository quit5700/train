package cn.quit5700.fabrictrain.block;

import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class SignalRailBlock extends RailBlock {
    public SignalRailBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }
}
