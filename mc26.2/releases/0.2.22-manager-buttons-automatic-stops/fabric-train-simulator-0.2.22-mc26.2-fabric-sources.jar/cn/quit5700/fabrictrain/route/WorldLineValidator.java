package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BaseRailBlock;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.power.RailPowerService;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.core.Vec3i;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import cn.quit5700.fabrictrain.depot.DepotDirectionRules;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import net.minecraft.core.Direction;

public final class WorldLineValidator {
    public static final int MAXIMUM_VISITED_TRACKS_PER_SEGMENT = 20_000;

    private WorldLineValidator() {
    }

    public static boolean validate(ServerLevel level, RailwayLine line, RailwaySavedData data) {
        return validateDetailed(level, line, data).valid();
    }

    public static LineValidationResult validateDetailed(ServerLevel level, RailwayLine line, RailwaySavedData data) {
        if (line.nodeIds().size() < 2) {
            RuntimePathCache.remove(line.id());
            return new LineValidationResult(false, -1, -1, LineValidationFailure.INVALID_NODE);
        }
        ArrayList<TrackPoint> complete = new ArrayList<>();
        java.util.HashMap<Integer, StopTrack> automaticStops = new java.util.HashMap<>();
        for (int i = 1; i < line.nodeIds().size(); i++) {
            RailwayDevice from = data.device(line.nodeIds().get(i - 1));
            RailwayDevice to = data.device(line.nodeIds().get(i));
            if (from == null || to == null || !from.dimension().equals(to.dimension())) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i, LineValidationFailure.INVALID_NODE);
            }
            List<TrackPoint> starts = trackCandidates(level, from, i - 1, automaticStops);
            List<TrackPoint> destinations = trackCandidates(level, to, i, automaticStops);
            if (starts.isEmpty() || destinations.isEmpty()) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i, LineValidationFailure.STATION_STOP_UNBOUND);
            }
            int sourceChoice = line.switchDirection(i - 1) >= 0
                    ? line.switchDirection(i - 1) : from.switchShapeOrdinal();
            PathScanResult result = bestSegment(level, starts, destinations, from, to, sourceChoice);
            if (result.status() != PathScanResult.Status.FOUND) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i, LineValidationFailure.TRACK_BROKEN);
            }
            rememberAutomaticStop(from, i - 1, result.path(), automaticStops);
            rememberAutomaticStop(to, i, result.path(), automaticStops);
            if (!complete.isEmpty()) complete.removeLast();
            complete.addAll(result.path());
        }
        data.replaceStationStopTracks(line.id(), automaticStops);
        RuntimePathCache.put(line.id(), complete);
        return new LineValidationResult(true, -1, -1, LineValidationFailure.NONE);
    }

    public enum LineValidationFailure { NONE, INVALID_NODE, STATION_STOP_UNBOUND, TRACK_BROKEN }
    public record LineValidationResult(boolean valid, int fromIndex, int toIndex, LineValidationFailure failure) {}

    public static ImmediateDispatchStatus validateForImmediateDispatch(ServerLevel level, BlockPos depotPos,
                                                                       RailwayLine line, RailwaySavedData data) {
        return validateForImmediateDispatchDetailed(level, depotPos, line, data).status();
    }

    public static ImmediateDispatchResult validateForImmediateDispatchDetailed(ServerLevel level, BlockPos depotPos,
                                                                                RailwayLine line, RailwaySavedData data) {
        if (line.nodeIds().isEmpty()) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        RailwayDevice first = data.device(line.nodeIds().getFirst());
        if (first == null || !first.dimension().equals(RailwayDataManager.dimension(level)))
            return new ImmediateDispatchResult(ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        LineValidationResult validation = validateDetailed(level, line, data);
        if (!validation.valid()) return new ImmediateDispatchResult(
                validation.failure() == LineValidationFailure.STATION_STOP_UNBOUND
                        ? ImmediateDispatchStatus.STATION_STOP_UNBOUND : ImmediateDispatchStatus.TRACK_BROKEN,
                validation.fromIndex(), validation.toIndex());
        line = data.line(line.id());
        DispatchAccess access = validateDispatchAccess(level, depotPos, line, data);
        if (access.status() == DispatchAccessStatus.NO_PATH) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        if (access.status() == DispatchAccessStatus.UNPOWERED) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.UNPOWERED, -1, -1);
        boolean powered = RuntimePathCache.get(line.id()).stream().allMatch(point -> RailPowerService.isPowered(level,
                new BlockPos(point.x(), point.y(), point.z())));
        return new ImmediateDispatchResult(powered ? ImmediateDispatchStatus.READY
                : ImmediateDispatchStatus.UNPOWERED, -1, -1);
    }

    public enum ImmediateDispatchStatus { READY, FIRST_NODE_NOT_FOUND, STATION_STOP_UNBOUND, TRACK_BROKEN, UNPOWERED }
    public record ImmediateDispatchResult(ImmediateDispatchStatus status, int fromIndex, int toIndex) {}

    public static DispatchAccess validateDispatchAccess(ServerLevel level, RailwayLine line,
                                                        RailwaySavedData data) {
        RailwayDevice depot = data.device(line.depotId());
        if (depot == null || depot.type() != DeviceType.DEPOT
                || !depot.dimension().equals(RailwayDataManager.dimension(level))) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        return validateDispatchAccess(level, new BlockPos(depot.x(), depot.y(), depot.z()), line, data);
    }

    public static DispatchAccess validateDispatchAccess(ServerLevel level, BlockPos depotPos, RailwayLine line,
                                                        RailwaySavedData data) {
        RailwayLine currentLine = data.line(line.id());
        if (currentLine != null) line = currentLine;
        TrackPoint start = new TrackPoint(depotPos.getX(), depotPos.getY() + 1, depotPos.getZ());
        RailwayDevice firstNode = null;
        TrackPoint destination = null;
        for (int nodeIndex = 0; nodeIndex < line.nodeIds().size(); nodeIndex++) {
            RailwayDevice candidate = data.device(line.nodeIds().get(nodeIndex));
            if (candidate == null || !candidate.dimension().equals(RailwayDataManager.dimension(level))) continue;
            TrackPoint candidateTrack = trackPoint(level, line, nodeIndex, candidate, data);
            if (candidateTrack != null && !candidateTrack.equals(start)) {
                firstNode = candidate;
                destination = candidateTrack;
                break;
            }
        }
        if (firstNode == null || !isRail(level, start)) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        if (!isRail(level, destination)) return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        BlockState startState = level.getBlockState(new BlockPos(start.x(), start.y(), start.z()));
        if (!startState.hasProperty(RailBlock.SHAPE)) return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        var exits = AbstractMinecart.exits(startState.getValue(RailBlock.SHAPE));
        TrackPoint first = step(level, start, exits.getFirst());
        TrackPoint second = step(level, start, exits.getSecond());
        PathScanResult firstResult = scanBranch(level, start, first, destination);
        PathScanResult secondResult = scanBranch(level, start, second, destination);
        int chosen = DepotDirectionRules.frontIndex(distance(firstResult), distance(secondResult));
        if (chosen < 0) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        PathScanResult result = chosen == 0 ? firstResult : secondResult;
        ArrayList<TrackPoint> path = new ArrayList<>(); path.add(start); path.addAll(result.path());
        boolean powered = path.stream().allMatch(point -> RailPowerService.isPowered(level,
                new BlockPos(point.x(), point.y(), point.z())));
        return powered ? new DispatchAccess(DispatchAccessStatus.READY, path)
                : new DispatchAccess(DispatchAccessStatus.UNPOWERED, path);
    }

    private static int distance(PathScanResult result) {
        return result.status() == PathScanResult.Status.FOUND ? result.path().size() : -1;
    }

    private static PathScanResult scanBranch(ServerLevel level, TrackPoint origin, TrackPoint first,
                                             TrackPoint destination) {
        if (!isRail(level, first)) return new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
        return TrackPathScanner.scan(first, destination, MAXIMUM_VISITED_TRACKS_PER_SEGMENT,
                point -> neighbours(level, point).stream().filter(candidate -> !candidate.equals(origin)).toList());
    }

    private static TrackPoint step(ServerLevel level, TrackPoint origin, Vec3i exit) {
        TrackPoint candidate = new TrackPoint(origin.x() + exit.getX(), origin.y() + exit.getY(), origin.z() + exit.getZ());
        if (!isRail(level, candidate) && exit.getY() == 0) {
            TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
            TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
            if (isRail(level, below)) return below;
            if (isRail(level, above)) return above;
        }
        return candidate;
    }

    public enum DispatchAccessStatus { READY, NO_PATH, UNPOWERED }

    public record DispatchAccess(DispatchAccessStatus status, List<TrackPoint> path) {
        public DispatchAccess { path = List.copyOf(path); }
    }

    private static TrackPoint trackPoint(ServerLevel level, RailwayLine line, int nodeIndex,
                                         RailwayDevice device, RailwaySavedData data) {
        int y = device.type() == DeviceType.DEPOT ? device.y() + 1 : device.y();
        if (device.type() == DeviceType.STATION) {
            StopTrack stop = resolveStationStopTrack(level, line, nodeIndex, device, data);
            return stop == null ? null : new TrackPoint(stop.x(), stop.y(), stop.z());
        }
        return new TrackPoint(device.x(), y, device.z());
    }

    private static List<TrackPoint> trackCandidates(ServerLevel level, RailwayDevice device, int nodeIndex,
                                                    java.util.Map<Integer, StopTrack> selectedStops) {
        if (device.type() != DeviceType.STATION) {
            int y = device.type() == DeviceType.DEPOT ? device.y() + 1 : device.y();
            TrackPoint point = new TrackPoint(device.x(), y, device.z());
            return isRail(level, point) ? List.of(point) : List.of();
        }
        StopTrack selected = selectedStops.get(nodeIndex);
        if (selected != null) return List.of(new TrackPoint(selected.x(), selected.y(), selected.z()));
        return stationTrackCandidates(level, device);
    }

    private static List<TrackPoint> stationTrackCandidates(ServerLevel level, RailwayDevice station) {
        BlockPos origin = new BlockPos(station.x(), station.y(), station.z());
        ArrayList<TrackPoint> candidates = new ArrayList<>();
        for (BlockPos candidate : BlockPos.betweenClosed(origin.offset(-8, -8, -8), origin.offset(8, 8, 8))) {
            if (level.getBlockState(candidate).is(ModBlocks.SIGNAL_RAIL))
                candidates.add(new TrackPoint(candidate.getX(), candidate.getY(), candidate.getZ()));
        }
        candidates.sort(java.util.Comparator
                .comparingDouble((TrackPoint point) -> distanceSquared(station, point))
                .thenComparingInt(TrackPoint::x).thenComparingInt(TrackPoint::y).thenComparingInt(TrackPoint::z));
        return List.copyOf(candidates.subList(0, Math.min(32, candidates.size())));
    }

    private static PathScanResult bestSegment(ServerLevel level, List<TrackPoint> starts,
                                              List<TrackPoint> destinations, RailwayDevice sourceDevice,
                                              RailwayDevice destinationDevice, int sourceChoice) {
        PathScanResult best = new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
        double bestScore = Double.MAX_VALUE;
        for (TrackPoint start : starts) {
            PathScanResult candidate = TrackPathScanner.scanAny(start, destinations,
                    MAXIMUM_VISITED_TRACKS_PER_SEGMENT,
                    point -> segmentNeighbours(level, point, start, sourceDevice, sourceChoice));
            if (candidate.status() != PathScanResult.Status.FOUND) continue;
            List<TrackPoint> route = stationBoundedPath(sourceDevice, destinationDevice, candidate.path());
            if (route.isEmpty()) continue;
            double score = route.size()
                    + distanceSquared(sourceDevice, route.getFirst()) * 10_000.0D
                    + distanceSquared(destinationDevice, route.getLast()) * 10_000.0D;
            if (score < bestScore) {
                best = new PathScanResult(PathScanResult.Status.FOUND, route);
                bestScore = score;
            }
        }
        return best;
    }

    private static List<TrackPoint> stationBoundedPath(RailwayDevice source, RailwayDevice destination,
                                                       List<TrackPoint> route) {
        if (route.isEmpty()) return List.of();
        TrackPoint first = source.type() == DeviceType.STATION
                ? AutomaticStationStopSelector.nearestOnPath(source.x(), source.y(), source.z(), route)
                : route.getFirst();
        TrackPoint last = destination.type() == DeviceType.STATION
                ? AutomaticStationStopSelector.nearestOnPath(destination.x(), destination.y(), destination.z(), route)
                : route.getLast();
        int firstIndex = route.indexOf(first);
        int lastIndex = route.lastIndexOf(last);
        if (firstIndex < 0 || lastIndex < firstIndex) return List.of();
        return List.copyOf(route.subList(firstIndex, lastIndex + 1));
    }

    private static void rememberAutomaticStop(RailwayDevice device, int nodeIndex, List<TrackPoint> path,
                                              java.util.Map<Integer, StopTrack> stops) {
        if (device.type() != DeviceType.STATION || stops.containsKey(nodeIndex)) return;
        TrackPoint selected = AutomaticStationStopSelector.nearestOnPath(
                device.x(), device.y(), device.z(), path);
        if (selected != null) stops.put(nodeIndex, new StopTrack(selected.x(), selected.y(), selected.z()));
    }

    private static double distanceSquared(RailwayDevice device, TrackPoint point) {
        double dx = point.x() - device.x(), dy = point.y() - device.y(), dz = point.z() - device.z();
        return dx * dx + dy * dy + dz * dz;
    }

    /**
     * Runtime uses the stop selected from the most recently validated route; it never guesses a
     * nearby height or changes the route while a train is moving.
     */
    public static StopTrack resolveStationStopTrack(ServerLevel level, RailwayLine line, int nodeIndex,
                                                    RailwayDevice station, RailwaySavedData data) {
        RailwayLine current = data.line(line.id());
        return current == null ? null : current.stationStopTrack(nodeIndex);
    }

    private static boolean isRail(ServerLevel level, TrackPoint point) {
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        return state.is(ModBlocks.SIGNAL_RAIL) || state.is(ModBlocks.SWITCH_RAIL);
    }

    private static Collection<TrackPoint> neighbours(ServerLevel level, TrackPoint point) {
        ArrayList<TrackPoint> result = new ArrayList<>(2);
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        if (!state.hasProperty(RailBlock.SHAPE)) return result;
        var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
        for (Vec3i exit : java.util.List.of(exits.getFirst(), exits.getSecond())) {
            TrackPoint candidate = new TrackPoint(point.x() + exit.getX(), point.y() + exit.getY(), point.z() + exit.getZ());
            if (!isRail(level, candidate) && exit.getY() == 0) {
                TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
                TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
                if (isRail(level, below)) candidate = below; else if (isRail(level, above)) candidate = above;
            }
            if (isRail(level, candidate)) result.add(candidate);
        }
        return result;
    }

    private static Collection<TrackPoint> segmentNeighbours(ServerLevel level, TrackPoint point,
                                                            TrackPoint source, RailwayDevice sourceDevice,
                                                            int sourceChoice) {
        if (sourceDevice.type() != DeviceType.SWITCH || !point.equals(source)) return neighbours(level, point);
        BlockState state = level.getBlockState(new BlockPos(source.x(), source.y(), source.z()));
        if (!state.hasProperty(DeviceRailBlock.ENTRY_DIRECTION)) return List.of();
        Direction exit = SwitchRailRouting.exitFor(SwitchRailRouting.entryFor(sourceDevice, state), sourceChoice);
        TrackPoint next = step(level, source, exit);
        return isRail(level, next) ? List.of(next) : List.of();
    }

    private static TrackPoint step(ServerLevel level, TrackPoint origin, Direction direction) {
        BlockPos next = new BlockPos(origin.x(), origin.y(), origin.z()).relative(direction);
        TrackPoint candidate = new TrackPoint(next.getX(), next.getY(), next.getZ());
        if (!isRail(level, candidate)) {
            TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
            TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
            if (isRail(level, below)) return below;
            if (isRail(level, above)) return above;
        }
        return candidate;
    }
}
