package cn.quit5700.fabrictrain.route;

import java.util.*;
import java.util.function.Function;

public final class TrackPathScanner {
    private TrackPathScanner() {
    }

    public static PathScanResult scan(
            TrackPoint start,
            TrackPoint destination,
            int maximumVisitedPoints,
            Function<TrackPoint, Collection<TrackPoint>> connectedNeighbours) {
        if (maximumVisitedPoints < 1) {
            throw new IllegalArgumentException("Maximum visited points must be positive");
        }
        ArrayDeque<TrackPoint> queue = new ArrayDeque<>();
        Map<TrackPoint, TrackPoint> previous = new HashMap<>();
        queue.add(start);
        previous.put(start, start);

        while (!queue.isEmpty()) {
            TrackPoint current = queue.removeFirst();
            if (current.equals(destination)) {
                return new PathScanResult(PathScanResult.Status.FOUND, rebuild(previous, start, destination));
            }
            if (previous.size() >= maximumVisitedPoints) {
                return new PathScanResult(PathScanResult.Status.TOO_LONG, List.of());
            }
            for (TrackPoint neighbour : connectedNeighbours.apply(current)) {
                if (!previous.containsKey(neighbour)) {
                    previous.put(neighbour, current);
                    queue.addLast(neighbour);
                }
            }
        }
        return new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
    }

    public static PathScanResult scanAny(
            TrackPoint start,
            Collection<TrackPoint> destinations,
            int maximumVisitedPoints,
            Function<TrackPoint, Collection<TrackPoint>> connectedNeighbours) {
        if (destinations == null || destinations.isEmpty())
            return new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
        Set<TrackPoint> targets = Set.copyOf(destinations);
        if (maximumVisitedPoints < 1)
            throw new IllegalArgumentException("Maximum visited points must be positive");
        ArrayDeque<TrackPoint> queue = new ArrayDeque<>();
        Map<TrackPoint, TrackPoint> previous = new HashMap<>();
        queue.add(start);
        previous.put(start, start);
        while (!queue.isEmpty()) {
            TrackPoint current = queue.removeFirst();
            if (targets.contains(current))
                return new PathScanResult(PathScanResult.Status.FOUND, rebuild(previous, start, current));
            if (previous.size() >= maximumVisitedPoints)
                return new PathScanResult(PathScanResult.Status.TOO_LONG, List.of());
            for (TrackPoint neighbour : connectedNeighbours.apply(current)) {
                if (!previous.containsKey(neighbour)) {
                    previous.put(neighbour, current);
                    queue.addLast(neighbour);
                }
            }
        }
        return new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
    }

    private static List<TrackPoint> rebuild(
            Map<TrackPoint, TrackPoint> previous,
            TrackPoint start,
            TrackPoint destination) {
        ArrayList<TrackPoint> reversed = new ArrayList<>();
        TrackPoint current = destination;
        while (!current.equals(start)) {
            reversed.add(current);
            current = previous.get(current);
        }
        reversed.add(start);
        Collections.reverse(reversed);
        return reversed;
    }
}
