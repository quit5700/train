package cn.quit5700.fabrictrain.route;

import java.util.Comparator;
import java.util.List;

/** Selects a station stop only from points already proven to belong to the validated route. */
public final class AutomaticStationStopSelector {
    private AutomaticStationStopSelector() {}

    public static TrackPoint nearestOnPath(int stationX, int stationY, int stationZ, List<TrackPoint> path) {
        if (path == null || path.isEmpty()) return null;
        return path.stream().min(Comparator
                .comparingDouble((TrackPoint point) -> distanceSquared(stationX, stationY, stationZ, point))
                .thenComparingInt(TrackPoint::x)
                .thenComparingInt(TrackPoint::y)
                .thenComparingInt(TrackPoint::z)).orElse(null);
    }

    private static double distanceSquared(int x, int y, int z, TrackPoint point) {
        double dx = point.x() - x;
        double dy = point.y() - y;
        double dz = point.z() - z;
        return dx * dx + dy * dy + dz * dz;
    }
}
