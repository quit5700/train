package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.data.RailwayLine;
import cn.quit5700.fabrictrain.data.RailwaySavedData;
import cn.quit5700.fabrictrain.depot.DepotDispatchService;
import cn.quit5700.fabrictrain.depot.DepotDispatchResult;
import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public final class DepotNetworking {
    private DepotNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.clientboundPlay().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(RequestOpenPayload.ID,RequestOpenPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(RequestOpenPayload.ID,(payload,context)->context.server().execute(()->{
            ServerPlayer player=context.player();BlockPos pos=payload.pos();
            if(player.distanceToSqr(pos.getX()+0.5D,pos.getY()+0.5D,pos.getZ()+0.5D)>64D)return;
            if(player.level().getBlockEntity(pos) instanceof TrainDepotBlockEntity depot)open(player,pos,depot);
        }));
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) ->
                context.server().execute(() -> update(context.player(), payload)));
    }

    public static void open(ServerPlayer player, BlockPos pos, TrainDepotBlockEntity depot) {
        var data = RailwayDataManager.state(player.level());
        List<LineOption> lines = data.lines().values().stream()
                .sorted(java.util.Comparator.comparingLong(RailwayLine::id))
                .map(line -> new LineOption(line.id(), line.name())).toList();
        long depotId = deviceIdAt(player, pos);
        long selectedLineId = depotId == 0L ? 0L : data.dispatchLineIdForDepot(depotId);
        if (depot.selectedLineId() != selectedLineId) depot.setSelectedLineId(selectedLineId);
        long active = selectedLineId == 0 ? 0 : data.activeTrainCount(selectedLineId);
        ServerPlayNetworking.send(player, new OpenPayload(pos, depot.template().encode(), selectedLineId,
                depot.trainClass().ordinal(), depot.dispatchIntervalSeconds(), depot.maximumTrains(),
                active,depot.speedLimitKmh(TrainClass.CARGO),depot.speedLimitKmh(TrainClass.PASSENGER),
                depot.speedLimitKmh(TrainClass.EXPRESS), lines));
    }

    private static long deviceIdAt(ServerPlayer player, BlockPos pos) {
        var device = RailwayDataManager.state(player.level()).find(RailwayDataManager.dimension(player.level()),
                pos.getX(), pos.getY(), pos.getZ());
        return device == null ? 0 : device.id();
    }

    private static void update(ServerPlayer player, UpdatePayload payload) {
        if(player.distanceToSqr(payload.pos().getX()+0.5D,payload.pos().getY()+0.5D,payload.pos().getZ()+0.5D)>64D)return;
        if (!(player.level().getBlockEntity(payload.pos()) instanceof TrainDepotBlockEntity depot)) return;
        ServerLevel level = (ServerLevel) player.level();
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayDevice device = RailwayDataManager.register(level, payload.pos(), DeviceType.DEPOT);
        long displacedDepotId;
        try {
            displacedDepotId = data.bindDispatchDepot(device.id(), payload.lineId());
        } catch (IllegalArgumentException invalidBinding) {
            open(player, payload.pos(), depot);
            return;
        }
        clearDisplacedDepotBinding(player, data, displacedDepotId, payload.lineId());
        depot.setTemplate(DepotTemplate.decode(payload.template()));
        TrainClass trainClass = TrainClass.values()[Math.clamp(payload.trainClass(), 0, TrainClass.values().length - 1)];
        depot.configure(payload.lineId(), trainClass, payload.interval(), payload.maximum(),payload.cargoSpeedKmh(),
                payload.passengerSpeedKmh(),payload.expressSpeedKmh());
        if (payload.dispatchNow()) {
            RailwayLine line = data.line(payload.lineId());
            DepotDispatchResult result = DepotDispatchService.dispatchNowDetailed(
                    level, payload.pos(), line, depot,
                    !player.isCreative());
            player.sendSystemMessage(Component.translatable(result.translationKey()));
        }
    }

    private static void clearDisplacedDepotBinding(ServerPlayer player, RailwaySavedData data,
                                                    long displacedDepotId, long lineId) {
        if (displacedDepotId == 0L) return;
        RailwayDevice displaced = data.device(displacedDepotId);
        if (displaced == null) return;
        for (ServerLevel level : player.level().getServer().getAllLevels()) {
            if (!RailwayDataManager.dimension(level).equals(displaced.dimension())) continue;
            BlockPos displacedPos = new BlockPos(displaced.x(), displaced.y(), displaced.z());
            if (level.hasChunkAt(displacedPos)
                    && level.getBlockEntity(displacedPos) instanceof TrainDepotBlockEntity oldDepot
                    && oldDepot.selectedLineId() == lineId) {
                oldDepot.setSelectedLineId(0L);
            }
            return;
        }
    }

    public record LineOption(long id, String name) {}

    public record RequestOpenPayload(BlockPos pos) implements CustomPacketPayload{
        public static final Type<RequestOpenPayload> ID=new Type<>(FabricTrainMod.id("request_open_depot_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf,RequestOpenPayload> CODEC=CustomPacketPayload.codec(
                (payload,buffer)->buffer.writeBlockPos(payload.pos),buffer->new RequestOpenPayload(buffer.readBlockPos()));
        @Override public Type<? extends CustomPacketPayload> type(){return ID;}
    }

    public record OpenPayload(BlockPos pos, String template, long lineId, int trainClass, int interval, int maximum,
                              long active,double cargoSpeedKmh,double passengerSpeedKmh,double expressSpeedKmh,
                              List<LineOption> lines) implements CustomPacketPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_depot_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenPayload> CODEC = CustomPacketPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(RegistryFriendlyByteBuf b) {
            b.writeBlockPos(pos); b.writeUtf(template, 100); b.writeVarLong(lineId); b.writeVarInt(trainClass);
            b.writeVarInt(interval); b.writeVarInt(maximum); b.writeVarLong(active);
            b.writeDouble(cargoSpeedKmh);b.writeDouble(passengerSpeedKmh);b.writeDouble(expressSpeedKmh);b.writeVarInt(lines.size());
            for (LineOption line : lines) { b.writeVarLong(line.id()); b.writeUtf(line.name(), 64); }
        }
        private static OpenPayload read(RegistryFriendlyByteBuf b) {
            BlockPos pos=b.readBlockPos();String template=b.readUtf(100);long line=b.readVarLong();int type=b.readVarInt();
            int interval=b.readVarInt(),maximum=b.readVarInt();long active=b.readVarLong();
            double cargoSpeed=b.readDouble(),passengerSpeed=b.readDouble(),expressSpeed=b.readDouble();int size=Math.clamp(b.readVarInt(),0,1000);
            ArrayList<LineOption> lines=new ArrayList<>();for(int i=0;i<size;i++)lines.add(new LineOption(b.readVarLong(),b.readUtf(64)));
            return new OpenPayload(pos,template,line,type,interval,maximum,active,cargoSpeed,passengerSpeed,expressSpeed,List.copyOf(lines));
        }
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }

    public record UpdatePayload(BlockPos pos, String template, long lineId, int trainClass, int interval,
                                int maximum,double cargoSpeedKmh,double passengerSpeedKmh,double expressSpeedKmh,
                                boolean dispatchNow) implements CustomPacketPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_depot_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UpdatePayload> CODEC = CustomPacketPayload.codec(
                (p,b)->{b.writeBlockPos(p.pos);b.writeUtf(p.template,100);b.writeVarLong(p.lineId);b.writeVarInt(p.trainClass);b.writeVarInt(p.interval);b.writeVarInt(p.maximum);b.writeDouble(p.cargoSpeedKmh);b.writeDouble(p.passengerSpeedKmh);b.writeDouble(p.expressSpeedKmh);b.writeBoolean(p.dispatchNow);},
                b->new UpdatePayload(b.readBlockPos(),b.readUtf(100),b.readVarLong(),b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readDouble(),b.readDouble(),b.readDouble(),b.readBoolean()));
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }
}
