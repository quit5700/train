package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BaseRailBlock;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.power.RailPowerService;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.core.Vec3i;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class WorldLineValidator {
    public static final int MAXIMUM_VISITED_TRACKS_PER_SEGMENT = 20_000;

    private WorldLineValidator() {
    }

    public static boolean validate(ServerLevel level, RailwayLine line, RailwaySavedData data) {
        if (line.nodeIds().size() < 2) { RuntimePathCache.remove(line.id()); return false; }
        ArrayList<TrackPoint> complete = new ArrayList<>();
        for (int i = 1; i < line.nodeIds().size(); i++) {
            RailwayDevice from = data.device(line.nodeIds().get(i - 1));
            RailwayDevice to = data.device(line.nodeIds().get(i));
            if (from == null || to == null || !from.dimension().equals(to.dimension())) { RuntimePathCache.remove(line.id()); return false; }
            TrackPoint start = trackPoint(level, from);
            TrackPoint destination = trackPoint(level, to);
            if (!isRail(level, start) || !isRail(level, destination)) { RuntimePathCache.remove(line.id()); return false; }
            PathScanResult result = TrackPathScanner.scan(start, destination,
                    MAXIMUM_VISITED_TRACKS_PER_SEGMENT, point -> neighbours(level, point));
            if (result.status() != PathScanResult.Status.FOUND) { RuntimePathCache.remove(line.id()); return false; }
            if (!complete.isEmpty()) complete.removeLast();
            complete.addAll(result.path());
        }
        RuntimePathCache.put(line.id(), complete);
        return true;
    }

    public static DispatchAccess validateDispatchAccess(ServerLevel level, RailwayLine line,
                                                        RailwaySavedData data) {
        RailwayDevice depot = data.device(line.depotId());
        if (depot == null || depot.type() != DeviceType.DEPOT
                || !depot.dimension().equals(RailwayDataManager.dimension(level))) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        TrackPoint start = trackPoint(level, depot);
        RailwayDevice firstNode = null;
        for (long nodeId : line.nodeIds()) {
            RailwayDevice candidate = data.device(nodeId);
            if (candidate == null || !candidate.dimension().equals(depot.dimension())) continue;
            if (!trackPoint(level, candidate).equals(start)) {
                firstNode = candidate;
                break;
            }
        }
        if (firstNode == null || !isRail(level, start)) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        TrackPoint destination = trackPoint(level, firstNode);
        if (!isRail(level, destination)) return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        PathScanResult result = TrackPathScanner.scan(start, destination,
                MAXIMUM_VISITED_TRACKS_PER_SEGMENT, point -> neighbours(level, point));
        if (result.status() != PathScanResult.Status.FOUND || result.path().size() < 2) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        boolean powered = result.path().stream().allMatch(point -> RailPowerService.isPowered(level,
                new BlockPos(point.x(), point.y(), point.z())));
        return powered ? new DispatchAccess(DispatchAccessStatus.READY, result.path())
                : new DispatchAccess(DispatchAccessStatus.UNPOWERED, result.path());
    }

    public enum DispatchAccessStatus { READY, NO_PATH, UNPOWERED }

    public record DispatchAccess(DispatchAccessStatus status, List<TrackPoint> path) {
        public DispatchAccess { path = List.copyOf(path); }
    }

    private static TrackPoint trackPoint(ServerLevel level, RailwayDevice device) {
        int y = device.type() == DeviceType.DEPOT ? device.y() + 1 : device.y();
        if (device.type() == DeviceType.STATION) {
            BlockPos station = new BlockPos(device.x(), device.y(), device.z());
            for (net.minecraft.core.Direction direction : net.minecraft.core.Direction.Plane.HORIZONTAL) {
                BlockPos candidate = station.relative(direction);
                if (isRail(level, new TrackPoint(candidate.getX(), candidate.getY(), candidate.getZ()))) {
                    return new TrackPoint(candidate.getX(), candidate.getY(), candidate.getZ());
                }
            }
        }
        return new TrackPoint(device.x(), y, device.z());
    }

    private static boolean isRail(ServerLevel level, TrackPoint point) {
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        return state.is(ModBlocks.SIGNAL_RAIL) || state.is(ModBlocks.SWITCH_RAIL);
    }

    private static Collection<TrackPoint> neighbours(ServerLevel level, TrackPoint point) {
        ArrayList<TrackPoint> result = new ArrayList<>(2);
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        if (!state.hasProperty(RailBlock.SHAPE)) return result;
        var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
        for (Vec3i exit : java.util.List.of(exits.getFirst(), exits.getSecond())) {
            TrackPoint candidate = new TrackPoint(point.x() + exit.getX(), point.y() + exit.getY(), point.z() + exit.getZ());
            if (!isRail(level, candidate) && exit.getY() == 0) {
                TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
                TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
                if (isRail(level, below)) candidate = below; else if (isRail(level, above)) candidate = above;
            }
            if (isRail(level, candidate)) result.add(candidate);
        }
        return result;
    }
}
