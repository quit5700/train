package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.data.*;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BaseRailBlock;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.power.RailPowerService;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.core.Vec3i;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import cn.quit5700.fabrictrain.depot.DepotDirectionRules;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import net.minecraft.core.Direction;

public final class WorldLineValidator {
    public static final int MAXIMUM_VISITED_TRACKS_PER_SEGMENT = 20_000;

    private WorldLineValidator() {
    }

    public static boolean validate(ServerLevel level, RailwayLine line, RailwaySavedData data) {
        return validateDetailed(level, line, data).valid();
    }

    public static LineValidationResult validateDetailed(ServerLevel level, RailwayLine line, RailwaySavedData data) {
        if (line.nodeIds().size() < 2) {
            RuntimePathCache.remove(line.id());
            return new LineValidationResult(false, -1, -1);
        }
        ArrayList<TrackPoint> complete = new ArrayList<>();
        for (int i = 1; i < line.nodeIds().size(); i++) {
            RailwayDevice from = data.device(line.nodeIds().get(i - 1));
            RailwayDevice to = data.device(line.nodeIds().get(i));
            if (from == null || to == null || !from.dimension().equals(to.dimension())) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i);
            }
            TrackPoint start = trackPoint(level, from);
            TrackPoint destination = trackPoint(level, to);
            if (!isRail(level, start) || !isRail(level, destination)) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i);
            }
            int sourceChoice = line.switchDirection(i - 1) >= 0
                    ? line.switchDirection(i - 1) : from.switchShapeOrdinal();
            PathScanResult result = TrackPathScanner.scan(start, destination,
                    MAXIMUM_VISITED_TRACKS_PER_SEGMENT,
                    point -> segmentNeighbours(level, point, start, from, sourceChoice));
            if (result.status() != PathScanResult.Status.FOUND) {
                RuntimePathCache.remove(line.id());
                return new LineValidationResult(false, i - 1, i);
            }
            if (!complete.isEmpty()) complete.removeLast();
            complete.addAll(result.path());
        }
        RuntimePathCache.put(line.id(), complete);
        return new LineValidationResult(true, -1, -1);
    }

    public record LineValidationResult(boolean valid, int fromIndex, int toIndex) {}

    public static ImmediateDispatchStatus validateForImmediateDispatch(ServerLevel level, BlockPos depotPos,
                                                                       RailwayLine line, RailwaySavedData data) {
        return validateForImmediateDispatchDetailed(level, depotPos, line, data).status();
    }

    public static ImmediateDispatchResult validateForImmediateDispatchDetailed(ServerLevel level, BlockPos depotPos,
                                                                                RailwayLine line, RailwaySavedData data) {
        if (line.nodeIds().isEmpty()) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        RailwayDevice first = data.device(line.nodeIds().getFirst());
        if (first == null || !first.dimension().equals(RailwayDataManager.dimension(level)))
            return new ImmediateDispatchResult(ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        LineValidationResult validation = validateDetailed(level, line, data);
        if (!validation.valid()) return new ImmediateDispatchResult(ImmediateDispatchStatus.TRACK_BROKEN,
                validation.fromIndex(), validation.toIndex());
        DispatchAccess access = validateDispatchAccess(level, depotPos, line, data);
        if (access.status() == DispatchAccessStatus.NO_PATH) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.FIRST_NODE_NOT_FOUND, -1, -1);
        if (access.status() == DispatchAccessStatus.UNPOWERED) return new ImmediateDispatchResult(
                ImmediateDispatchStatus.UNPOWERED, -1, -1);
        boolean powered = RuntimePathCache.get(line.id()).stream().allMatch(point -> RailPowerService.isPowered(level,
                new BlockPos(point.x(), point.y(), point.z())));
        return new ImmediateDispatchResult(powered ? ImmediateDispatchStatus.READY
                : ImmediateDispatchStatus.UNPOWERED, -1, -1);
    }

    public enum ImmediateDispatchStatus { READY, FIRST_NODE_NOT_FOUND, TRACK_BROKEN, UNPOWERED }
    public record ImmediateDispatchResult(ImmediateDispatchStatus status, int fromIndex, int toIndex) {}

    public static DispatchAccess validateDispatchAccess(ServerLevel level, RailwayLine line,
                                                        RailwaySavedData data) {
        RailwayDevice depot = data.device(line.depotId());
        if (depot == null || depot.type() != DeviceType.DEPOT
                || !depot.dimension().equals(RailwayDataManager.dimension(level))) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        return validateDispatchAccess(level, new BlockPos(depot.x(), depot.y(), depot.z()), line, data);
    }

    public static DispatchAccess validateDispatchAccess(ServerLevel level, BlockPos depotPos, RailwayLine line,
                                                        RailwaySavedData data) {
        TrackPoint start = new TrackPoint(depotPos.getX(), depotPos.getY() + 1, depotPos.getZ());
        RailwayDevice firstNode = null;
        for (long nodeId : line.nodeIds()) {
            RailwayDevice candidate = data.device(nodeId);
            if (candidate == null || !candidate.dimension().equals(RailwayDataManager.dimension(level))) continue;
            if (!trackPoint(level, candidate).equals(start)) {
                firstNode = candidate;
                break;
            }
        }
        if (firstNode == null || !isRail(level, start)) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        TrackPoint destination = trackPoint(level, firstNode);
        if (!isRail(level, destination)) return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        BlockState startState = level.getBlockState(new BlockPos(start.x(), start.y(), start.z()));
        if (!startState.hasProperty(RailBlock.SHAPE)) return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        var exits = AbstractMinecart.exits(startState.getValue(RailBlock.SHAPE));
        TrackPoint first = step(level, start, exits.getFirst());
        TrackPoint second = step(level, start, exits.getSecond());
        PathScanResult firstResult = scanBranch(level, start, first, destination);
        PathScanResult secondResult = scanBranch(level, start, second, destination);
        int chosen = DepotDirectionRules.frontIndex(distance(firstResult), distance(secondResult));
        if (chosen < 0) {
            return new DispatchAccess(DispatchAccessStatus.NO_PATH, List.of());
        }
        PathScanResult result = chosen == 0 ? firstResult : secondResult;
        ArrayList<TrackPoint> path = new ArrayList<>(); path.add(start); path.addAll(result.path());
        boolean powered = path.stream().allMatch(point -> RailPowerService.isPowered(level,
                new BlockPos(point.x(), point.y(), point.z())));
        return powered ? new DispatchAccess(DispatchAccessStatus.READY, path)
                : new DispatchAccess(DispatchAccessStatus.UNPOWERED, path);
    }

    private static int distance(PathScanResult result) {
        return result.status() == PathScanResult.Status.FOUND ? result.path().size() : -1;
    }

    private static PathScanResult scanBranch(ServerLevel level, TrackPoint origin, TrackPoint first,
                                             TrackPoint destination) {
        if (!isRail(level, first)) return new PathScanResult(PathScanResult.Status.NOT_FOUND, List.of());
        return TrackPathScanner.scan(first, destination, MAXIMUM_VISITED_TRACKS_PER_SEGMENT,
                point -> neighbours(level, point).stream().filter(candidate -> !candidate.equals(origin)).toList());
    }

    private static TrackPoint step(ServerLevel level, TrackPoint origin, Vec3i exit) {
        TrackPoint candidate = new TrackPoint(origin.x() + exit.getX(), origin.y() + exit.getY(), origin.z() + exit.getZ());
        if (!isRail(level, candidate) && exit.getY() == 0) {
            TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
            TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
            if (isRail(level, below)) return below;
            if (isRail(level, above)) return above;
        }
        return candidate;
    }

    public enum DispatchAccessStatus { READY, NO_PATH, UNPOWERED }

    public record DispatchAccess(DispatchAccessStatus status, List<TrackPoint> path) {
        public DispatchAccess { path = List.copyOf(path); }
    }

    private static TrackPoint trackPoint(ServerLevel level, RailwayDevice device) {
        int y = device.type() == DeviceType.DEPOT ? device.y() + 1 : device.y();
        if (device.type() == DeviceType.STATION) {
            BlockPos station = new BlockPos(device.x(), device.y(), device.z());
            for (net.minecraft.core.Direction direction : net.minecraft.core.Direction.Plane.HORIZONTAL) {
                BlockPos candidate = station.relative(direction);
                if (isRail(level, new TrackPoint(candidate.getX(), candidate.getY(), candidate.getZ()))) {
                    return new TrackPoint(candidate.getX(), candidate.getY(), candidate.getZ());
                }
            }
        }
        return new TrackPoint(device.x(), y, device.z());
    }

    private static boolean isRail(ServerLevel level, TrackPoint point) {
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        return state.is(ModBlocks.SIGNAL_RAIL) || state.is(ModBlocks.SWITCH_RAIL);
    }

    private static Collection<TrackPoint> neighbours(ServerLevel level, TrackPoint point) {
        ArrayList<TrackPoint> result = new ArrayList<>(2);
        BlockState state = level.getBlockState(new BlockPos(point.x(), point.y(), point.z()));
        if (!state.hasProperty(RailBlock.SHAPE)) return result;
        var exits = AbstractMinecart.exits(state.getValue(RailBlock.SHAPE));
        for (Vec3i exit : java.util.List.of(exits.getFirst(), exits.getSecond())) {
            TrackPoint candidate = new TrackPoint(point.x() + exit.getX(), point.y() + exit.getY(), point.z() + exit.getZ());
            if (!isRail(level, candidate) && exit.getY() == 0) {
                TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
                TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
                if (isRail(level, below)) candidate = below; else if (isRail(level, above)) candidate = above;
            }
            if (isRail(level, candidate)) result.add(candidate);
        }
        return result;
    }

    private static Collection<TrackPoint> segmentNeighbours(ServerLevel level, TrackPoint point,
                                                            TrackPoint source, RailwayDevice sourceDevice,
                                                            int sourceChoice) {
        if (sourceDevice.type() != DeviceType.SWITCH || !point.equals(source)) return neighbours(level, point);
        BlockState state = level.getBlockState(new BlockPos(source.x(), source.y(), source.z()));
        if (!state.hasProperty(DeviceRailBlock.ENTRY_DIRECTION)) return List.of();
        Direction exit = SwitchRailRouting.exitFor(state.getValue(DeviceRailBlock.ENTRY_DIRECTION), sourceChoice);
        TrackPoint next = step(level, source, exit);
        return isRail(level, next) ? List.of(next) : List.of();
    }

    private static TrackPoint step(ServerLevel level, TrackPoint origin, Direction direction) {
        BlockPos next = new BlockPos(origin.x(), origin.y(), origin.z()).relative(direction);
        TrackPoint candidate = new TrackPoint(next.getX(), next.getY(), next.getZ());
        if (!isRail(level, candidate)) {
            TrackPoint below = new TrackPoint(candidate.x(), candidate.y() - 1, candidate.z());
            TrackPoint above = new TrackPoint(candidate.x(), candidate.y() + 1, candidate.z());
            if (isRail(level, below)) return below;
            if (isRail(level, above)) return above;
        }
        return candidate;
    }
}
