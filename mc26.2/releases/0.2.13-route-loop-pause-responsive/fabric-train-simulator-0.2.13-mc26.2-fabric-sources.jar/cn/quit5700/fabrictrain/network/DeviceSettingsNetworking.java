package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.data.*;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.Container;
import net.minecraft.core.Direction;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;

public final class DeviceSettingsNetworking {
    private DeviceSettingsNetworking() {}

    public static void registerServer() {
        PayloadTypeRegistry.clientboundPlay().register(OpenPayload.ID, OpenPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            RailwaySavedData data = RailwayDataManager.state(context.player().level());
            RailwayDevice before = data.device(payload.deviceId());
            if (before == null) return;
            int shape = Math.clamp(payload.switchShapeOrdinal(), 0, 2);
            RailwayDevice updated = data.updateDevice(payload.deviceId(), payload.name(), payload.dwellSeconds(), shape, payload.announcement());
            data.updateCargoDwell(payload.deviceId(), payload.cargoDwellSeconds());
            data.updateManualUnload(payload.deviceId(), payload.manualUnload());
            if (updated != null && before.type() == DeviceType.SWITCH) {
                for (ServerLevel level : context.player().level().getServer().getAllLevels()) {
                    if (RailwayDataManager.dimension(level).equals(before.dimension())) {
                        SwitchRailRouting.applyChoice(level, before, shape);
                        break;
                    }
                }
            }
        }));
    }

    public static void open(net.minecraft.server.level.ServerPlayer player, RailwayDevice device) {
        boolean connected = false;
        for (ServerLevel level : player.level().getServer().getAllLevels()) {
            if (!RailwayDataManager.dimension(level).equals(device.dimension())) continue;
            BlockPos pos = new BlockPos(device.x(), device.y(), device.z());
            for (Direction direction : Direction.values()) {
                if (level.getBlockEntity(pos.relative(direction)) instanceof Container) { connected = true; break; }
            }
        }
        ServerPlayNetworking.send(player, new OpenPayload(device.id(), device.type().ordinal(), device.name(),
                device.dwellSeconds(), device.cargoDwellSeconds(), device.switchShapeOrdinal(), device.announcement(), device.manualUnload(), connected));
    }

    private static double squaredDistance(double x, double y, double z, RailwayDevice d) {
        double dx = x - d.x(), dy = y - d.y(), dz = z - d.z(); return dx * dx + dy * dy + dz * dz;
    }

    public record OpenPayload(long deviceId, int typeOrdinal, String name, int dwellSeconds, int cargoDwellSeconds, int switchShapeOrdinal,
                              String announcement, boolean manualUnload, boolean containerConnected) implements CustomPacketPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_device_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenPayload> CODEC = CustomPacketPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(RegistryFriendlyByteBuf b) { b.writeVarLong(deviceId); b.writeVarInt(typeOrdinal); b.writeUtf(name, 64); b.writeVarInt(dwellSeconds); b.writeVarInt(cargoDwellSeconds); b.writeVarInt(switchShapeOrdinal);b.writeUtf(announcement,128);b.writeBoolean(manualUnload);b.writeBoolean(containerConnected); }
        private static OpenPayload read(RegistryFriendlyByteBuf b) { return new OpenPayload(b.readVarLong(), b.readVarInt(), b.readUtf(64), b.readVarInt(), b.readVarInt(), b.readVarInt(),b.readUtf(128),b.readBoolean(),b.readBoolean()); }
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }

    public record UpdatePayload(long deviceId, String name, int dwellSeconds, int cargoDwellSeconds, int switchShapeOrdinal, String announcement,
                                boolean manualUnload) implements CustomPacketPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_device_settings"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UpdatePayload> CODEC = CustomPacketPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(RegistryFriendlyByteBuf b) { b.writeVarLong(deviceId); b.writeUtf(name, 64); b.writeVarInt(dwellSeconds); b.writeVarInt(cargoDwellSeconds); b.writeVarInt(switchShapeOrdinal);b.writeUtf(announcement,128);b.writeBoolean(manualUnload); }
        private static UpdatePayload read(RegistryFriendlyByteBuf b) { return new UpdatePayload(b.readVarLong(), b.readUtf(64), b.readVarInt(), b.readVarInt(), b.readVarInt(),b.readUtf(128),b.readBoolean()); }
        @Override public Type<? extends CustomPacketPayload> type() { return ID; }
    }
}
