package cn.quit5700.fabrictrain.data;

public record RailwayDevice(long id, DeviceType type, String dimension, int x, int y, int z, String name,
                            int dwellSeconds, int cargoDwellSeconds, int switchShapeOrdinal, String announcement, boolean manualUnload) {
    public RailwayDevice(long id, DeviceType type, String dimension, int x, int y, int z, String name,
                         int dwellSeconds, int switchShapeOrdinal) {
        this(id,type,dimension,x,y,z,name,dwellSeconds,120,switchShapeOrdinal,"",false);
    }
    public RailwayDevice(long id, DeviceType type, String dimension, int x, int y, int z, String name,
                         int dwellSeconds, int switchShapeOrdinal, String announcement) {
        this(id,type,dimension,x,y,z,name,dwellSeconds,120,switchShapeOrdinal,announcement,false);
    }
    public RailwayDevice(long id, DeviceType type, String dimension, int x, int y, int z, String name,
                         int dwellSeconds, int switchShapeOrdinal, String announcement, boolean manualUnload) {
        this(id,type,dimension,x,y,z,name,dwellSeconds,120,switchShapeOrdinal,announcement,manualUnload);
    }
}
