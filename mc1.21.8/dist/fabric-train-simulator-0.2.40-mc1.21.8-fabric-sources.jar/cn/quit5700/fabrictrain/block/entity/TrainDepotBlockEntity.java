package cn.quit5700.fabrictrain.block.entity;

import cn.quit5700.fabrictrain.registry.ModBlockEntities;
import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2624;
import net.minecraft.class_2680;
import cn.quit5700.fabrictrain.train.SpeedRules;
import cn.quit5700.fabrictrain.depot.DepotDispatchResult;

public final class TrainDepotBlockEntity extends class_2624 {
    public static final int SIZE = 54;
    private class_2371<class_1799> items = class_2371.method_10213(SIZE, class_1799.field_8037);
    private DepotTemplate template = DepotTemplate.defaultTemplate();
    private long selectedLineId;
    private TrainClass trainClass = TrainClass.PASSENGER;
    private int dispatchIntervalSeconds = 30;
    private int maximumTrains = 1;
    private double cargoSpeedKmh = SpeedRules.FREIGHT_LIMIT_KMH;
    private double passengerSpeedKmh = SpeedRules.PASSENGER_LIMIT_KMH;
    private double expressSpeedKmh = SpeedRules.EXPRESS_LIMIT_KMH;
    private boolean automaticDispatchEnabled;
    private boolean creativeAutomaticDispatch;
    private int lastAutomaticDispatchResult = -1;

    public TrainDepotBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.TRAIN_DEPOT, pos, state);
    }

    @Override public int method_5439() { return SIZE; }
    @Override protected class_2371<class_1799> method_11282() { return items; }
    @Override protected void method_11281(class_2371<class_1799> value) { items = value; }
    @Override protected class_2561 method_17823() { return class_2561.method_43471("container.fabric_train_simulator.train_depot"); }
    @Override protected class_1703 method_5465(int syncId, class_1661 inventory) { return class_1707.method_19247(syncId, inventory, this); }
    public DepotTemplate template() { return template; }
    public void setTemplate(DepotTemplate value) { template = value; method_5431(); }
    public long selectedLineId() { return selectedLineId; }
    public void setSelectedLineId(long lineId) {
        long next = Math.max(0L, lineId);
        if (selectedLineId != next) {
            automaticDispatchEnabled = false;
            creativeAutomaticDispatch = false;
        }
        selectedLineId = next;
        method_5431();
    }
    public boolean automaticDispatchEnabled() { return automaticDispatchEnabled; }
    public void setAutomaticDispatchEnabled(boolean enabled) {
        automaticDispatchEnabled = enabled && selectedLineId > 0L;
        if (!automaticDispatchEnabled) creativeAutomaticDispatch = false;
        method_5431();
    }
    public boolean creativeAutomaticDispatch() { return creativeAutomaticDispatch; }
    public void setCreativeAutomaticDispatch(boolean creative) {
        creativeAutomaticDispatch = automaticDispatchEnabled && creative;
        method_5431();
    }
    public int lastAutomaticDispatchResultOrdinal() { return lastAutomaticDispatchResult; }
    public void setLastAutomaticDispatchResult(DepotDispatchResult result) {
        lastAutomaticDispatchResult = result == null ? -1 : result.ordinal();
        method_5431();
    }
    public TrainClass trainClass() { return template.cars().contains(cn.quit5700.fabrictrain.train.CarType.CARGO) ? TrainClass.CARGO : trainClass; }
    public int dispatchIntervalSeconds() { return dispatchIntervalSeconds; }
    public int maximumTrains() { return maximumTrains; }
    public double speedLimitKmh(TrainClass value) { return switch(value){
        case CARGO -> cargoSpeedKmh;
        case PASSENGER -> passengerSpeedKmh;
        case EXPRESS -> expressSpeedKmh;
    }; }
    public void configure(long lineId, TrainClass value, int interval, int maximum) {
        configure(lineId,value,interval,maximum,cargoSpeedKmh,passengerSpeedKmh,expressSpeedKmh);
    }
    public void configure(long lineId, TrainClass value, int interval, int maximum,
                          double cargoSpeed,double passengerSpeed,double expressSpeed) {
        if (selectedLineId != Math.max(0L, lineId)) {
            automaticDispatchEnabled = false;
            creativeAutomaticDispatch = false;
        }
        selectedLineId = Math.max(0, lineId);
        trainClass = value == null ? TrainClass.PASSENGER : value;
        dispatchIntervalSeconds = Math.clamp(interval, 1, 3600);
        maximumTrains = Math.clamp(maximum, 1, 1000);
        cargoSpeedKmh=SpeedRules.sanitizeConfiguredLimit(cargoSpeed,SpeedRules.FREIGHT_LIMIT_KMH);
        passengerSpeedKmh=SpeedRules.sanitizeConfiguredLimit(passengerSpeed,SpeedRules.PASSENGER_LIMIT_KMH);
        expressSpeedKmh=SpeedRules.sanitizeConfiguredLimit(expressSpeed,SpeedRules.EXPRESS_LIMIT_KMH);
        method_5431();
    }

    @Override protected void method_11007(class_11372 output) {
        super.method_11007(output);
        class_1262.method_5426(output, items);
        output.method_71469("TrainTemplate", template.encode());
        output.method_71466("SelectedLineId", selectedLineId);
        output.method_71469("TrainClass", trainClass.name());
        output.method_71465("DispatchIntervalSeconds", dispatchIntervalSeconds);
        output.method_71465("MaximumTrains", maximumTrains);
        output.method_71463("CargoSpeedKmh",cargoSpeedKmh);
        output.method_71463("PassengerSpeedKmh",passengerSpeedKmh);
        output.method_71463("ExpressSpeedKmh",expressSpeedKmh);
        output.method_71472("AutomaticDispatchEnabled", automaticDispatchEnabled);
        output.method_71472("CreativeAutomaticDispatch", creativeAutomaticDispatch);
        output.method_71465("LastAutomaticDispatchResult", lastAutomaticDispatchResult);
    }

    @Override protected void method_11014(class_11368 input) {
        super.method_11014(input);
        items = class_2371.method_10213(SIZE, class_1799.field_8037);
        class_1262.method_5429(input, items);
        template = DepotTemplate.decode(input.method_71428("TrainTemplate", DepotTemplate.defaultTemplate().encode()));
        selectedLineId = Math.max(0, input.method_71425("SelectedLineId", 0));
        try { trainClass = TrainClass.valueOf(input.method_71428("TrainClass", "PASSENGER")); }
        catch (IllegalArgumentException ignored) { trainClass = TrainClass.PASSENGER; }
        dispatchIntervalSeconds = Math.clamp(input.method_71424("DispatchIntervalSeconds", 30), 1, 3600);
        maximumTrains = Math.clamp(input.method_71424("MaximumTrains", 1), 1, 1000);
        cargoSpeedKmh=SpeedRules.sanitizeConfiguredLimit(input.method_71422("CargoSpeedKmh",SpeedRules.FREIGHT_LIMIT_KMH),SpeedRules.FREIGHT_LIMIT_KMH);
        passengerSpeedKmh=SpeedRules.sanitizeConfiguredLimit(input.method_71422("PassengerSpeedKmh",SpeedRules.PASSENGER_LIMIT_KMH),SpeedRules.PASSENGER_LIMIT_KMH);
        expressSpeedKmh=SpeedRules.sanitizeConfiguredLimit(input.method_71422("ExpressSpeedKmh",SpeedRules.EXPRESS_LIMIT_KMH),SpeedRules.EXPRESS_LIMIT_KMH);
        automaticDispatchEnabled=input.method_71433("AutomaticDispatchEnabled", false) && selectedLineId > 0L;
        creativeAutomaticDispatch=input.method_71433("CreativeAutomaticDispatch", false) && automaticDispatchEnabled;
        lastAutomaticDispatchResult=Math.clamp(input.method_71424("LastAutomaticDispatchResult", -1), -1,
                DepotDispatchResult.values().length - 1);
    }
}
