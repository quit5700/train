package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.LineStatus;
import cn.quit5700.fabrictrain.depot.DepotSettingsAction;
import cn.quit5700.fabrictrain.depot.DepotDispatchResult;
import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.network.DepotNetworking;
import cn.quit5700.fabrictrain.train.CarType;
import cn.quit5700.fabrictrain.train.SpeedRules;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DepotSettingsScreen extends class_437 {
    private static final int PANEL_WIDTH = 280;
    private final class_2338 depotPos;
    private final ArrayList<CarType> cars;
    private final List<DepotNetworking.LineOption> lines;
    private int lineIndex = -1;
    private int lineStatus = -1;
    private int pauseState = -1;
    private final boolean automaticDispatchEnabled;
    private final int lastAutomaticDispatchResult;
    private final String operationMessageKey;
    private TrainClass trainClass;
    private int interval;
    private int maximum;
    private final long active;
    private class_4185 lineButton;
    private class_4185 dispatchButton;
    private class_4185 passengerButton;
    private class_4185 expressButton;
    private class_4185 removeButton;
    private class_4185 pauseButton;
    private class_4185 trainListButton;
    private class_342 speedInput;
    private class_342 nameInput;
    private final String initialName;
    private final double[] speeds = new double[TrainClass.values().length];
    private int scrollOffset;

    public DepotSettingsScreen(DepotNetworking.OpenPayload payload) {
        super(class_2561.method_43471("screen.fabric_train_simulator.depot.title"));
        depotPos = payload.pos();
        cars = new ArrayList<>(DepotTemplate.decode(payload.template()).cars());
        lines = payload.lines();
        for (int i = 0; i < lines.size(); i++) if (lines.get(i).id() == payload.lineId()) lineIndex = i;
        lineStatus = payload.lineStatus();
        pauseState = payload.pauseState();
        automaticDispatchEnabled = payload.automaticDispatchEnabled();
        lastAutomaticDispatchResult = payload.lastAutomaticDispatchResult();
        operationMessageKey = payload.operationMessageKey();
        trainClass = TrainClass.values()[Math.clamp(payload.trainClass(), 0, TrainClass.values().length - 1)];
        interval = payload.interval();
        maximum = payload.maximum();
        active = payload.active();
        speeds[TrainClass.CARGO.ordinal()] = payload.cargoSpeedKmh();
        speeds[TrainClass.PASSENGER.ordinal()] = payload.passengerSpeedKmh();
        speeds[TrainClass.EXPRESS.ordinal()] = payload.expressSpeedKmh();
        initialName = payload.name();
    }

    private int desiredHeight() {
        return Math.max(334, 314 + cars.size() * 11);
    }

    private ResponsiveScreenLayout layout() {
        return ResponsiveScreenLayout.of(field_22789, field_22790, PANEL_WIDTH, desiredHeight(), 20);
    }

    @Override
    protected void method_25426() {
        ResponsiveScreenLayout layout = layout();
        int top = layout.top();
        int contentWidth = layout.panelWidth() - 20;
        if (nameInput == null) {
            nameInput = new class_342(field_22793, 240, 20, class_2561.method_43471("screen.fabric_train_simulator.device.name"));
            nameInput.method_1880(64);
            nameInput.method_1852(initialName);
        }
        int nameY = top + 36 - scrollOffset;
        nameInput.method_48229(layout.left() + 10, nameY);
        nameInput.method_25358(contentWidth);
        addContent(nameInput, layout);

        int classY = top + 62 - scrollOffset;
        int classWidth = Math.max(48, (contentWidth - 12) / 3);
        passengerButton = addContent(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.passenger"),
                button -> choose(TrainClass.PASSENGER)).method_46434(layout.left() + 10, classY, classWidth, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.cargo"),
                button -> choose(TrainClass.CARGO)).method_46434(layout.left() + 16 + classWidth, classY, classWidth, 20).method_46431(), layout);
        expressButton = addContent(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.express"),
                button -> choose(TrainClass.EXPRESS)).method_46434(layout.left() + 22 + classWidth * 2, classY, classWidth, 20).method_46431(), layout);

        if (speedInput == null) {
            speedInput = new class_342(field_22793, contentWidth, 20, class_2561.method_43471("screen.fabric_train_simulator.depot.speed"));
            speedInput.method_1880(12);
            speedInput.method_1852(speedText(trainClass));
        }
        int speedY = top + 100 - scrollOffset;
        speedInput.method_48229(layout.left() + 10, speedY);
        speedInput.method_25358(contentWidth);
        addContent(speedInput, layout);

        int lineY = top + 126 - scrollOffset;
        lineButton = addContent(class_4185.method_46430(lineLabel(), button -> {
            lineIndex = lines.isEmpty() ? -1 : (lineIndex >= lines.size() - 1 ? -1 : lineIndex + 1);
            lineStatus = lineIndex < 0 ? -1 : lines.get(lineIndex).status();
            pauseState = lineStatus == LineStatus.PAUSED.ordinal() ? 1
                    : lineStatus == LineStatus.RUNNING.ordinal() ? 0 : -1;
            button.method_25355(lineLabel());
            updateButtons();
        }).method_46434(layout.left() + 10, lineY, contentWidth, 20).method_46431(), layout);

        int controlsY = top + 152 - scrollOffset;
        int quarter = Math.max(40, (contentWidth - 12) / 4);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.minus_five"),
                button -> interval = Math.max(1, interval - 5)).method_46434(layout.left() + 10, controlsY, quarter, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.plus_five"),
                button -> interval = Math.min(3600, interval + 5)).method_46434(layout.left() + 14 + quarter, controlsY, quarter, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.minus_one"),
                button -> maximum = Math.max(1, maximum - 1)).method_46434(layout.left() + 18 + quarter * 2, controlsY, quarter, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.plus_one"),
                button -> maximum = Math.min(1000, maximum + 1)).method_46434(layout.left() + 22 + quarter * 3, controlsY, quarter, 20).method_46431(), layout);

        int addY = top + 208 - scrollOffset;
        int half = (contentWidth - 6) / 2;
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.add_passenger"),
                button -> add(CarType.PASSENGER)).method_46434(layout.left() + 10, addY, half, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.add_cargo"),
                button -> add(CarType.CARGO)).method_46434(layout.left() + 16 + half, addY, half, 20).method_46431(), layout);

        int actionY = top + 234 - scrollOffset;
        int third = (contentWidth - 12) / 3;
        removeButton = addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.remove"),
                button -> removeLast()).method_46434(layout.left() + 10, actionY, third, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.generate_now"),
                button -> send(DepotSettingsAction.GENERATE_MANUAL)).method_46434(layout.left() + 16 + third, actionY, third, 20).method_46431(), layout);
        dispatchButton = addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.dispatch_now"),
                button -> send(DepotSettingsAction.DISPATCH_AUTOMATIC)).method_46434(layout.left() + 22 + third * 2, actionY, third, 20).method_46431(), layout);

        int footerThird = (contentWidth - 12) / 3;
        pauseButton = method_37063(class_4185.method_46430(pauseLabel(),
                button -> send(DepotSettingsAction.TOGGLE_PAUSE))
                .method_46434(layout.left() + 10, layout.footerY(), footerThird, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.save"),
                button -> send(DepotSettingsAction.SAVE))
                .method_46434(layout.left() + 16 + footerThird, layout.footerY(), footerThird, 20).method_46431());
        trainListButton = method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.depot.train_list"),
                button -> ClientPlayNetworking.send(new DepotNetworking.RequestTrainListPayload(depotPos)))
                .method_46434(layout.left() + 22 + footerThird * 2, layout.footerY(), footerThird, 20).method_46431());
        updateButtons();
    }

    private <T extends class_339> T addContent(T widget, ResponsiveScreenLayout layout) {
        widget.field_22764 = insideContent(widget.method_46427(), layout);
        return method_37063(widget);
    }

    private static boolean insideContent(int y, ResponsiveScreenLayout layout) {
        return y >= layout.scrollTop() && y + 20 <= layout.scrollBottom();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
        ResponsiveScreenLayout layout = layout();
        if (!layout.scrollRequired()) return super.method_25401(mouseX, mouseY, horizontal, vertical);
        commitSpeed();
        int maximumOffset = Math.max(0, desiredHeight() - layout.panelHeight());
        int next = Math.clamp(scrollOffset - (int) Math.signum(vertical) * 20, 0, maximumOffset);
        if (next == scrollOffset) return false;
        scrollOffset = next;
        method_41843();
        return true;
    }

    private boolean hasCargo() { return cars.contains(CarType.CARGO); }

    private void choose(TrainClass value) {
        commitSpeed();
        trainClass = hasCargo() ? TrainClass.CARGO : value;
        speedInput.method_1852(speedText(trainClass));
        updateButtons();
    }

    private void add(CarType type) {
        if (cars.size() < 100) {
            cars.add(type);
            if (type == CarType.CARGO) choose(TrainClass.CARGO);
            method_41843();
        }
    }

    private void removeLast() {
        if (!cars.isEmpty()) {
            cars.removeLast();
            if (!hasCargo() && trainClass == TrainClass.CARGO) choose(TrainClass.PASSENGER);
            scrollOffset = Math.min(scrollOffset, Math.max(0, desiredHeight() - layout().panelHeight()));
            method_41843();
        }
    }

    private class_2561 lineLabel() {
        return lineIndex < 0 ? class_2561.method_43471("screen.fabric_train_simulator.depot.no_line")
                : class_2561.method_43470(lines.get(lineIndex).name() + " ▼");
    }

    private class_2561 pauseLabel() {
        return class_2561.method_43471(lineStatus == LineStatus.PAUSED.ordinal()
                ? "screen.fabric_train_simulator.depot.continue"
                : "screen.fabric_train_simulator.depot.pause");
    }

    private String speedText(TrainClass value) {
        return String.format(Locale.ROOT, "%.1f", speeds[value.ordinal()]);
    }

    private void commitSpeed() {
        if (speedInput == null) return;
        try {
            speeds[trainClass.ordinal()] = SpeedRules.sanitizeConfiguredLimit(
                    Double.parseDouble(speedInput.method_1882()), speeds[trainClass.ordinal()]);
        } catch (NumberFormatException ignored) {}
        speedInput.method_1852(speedText(trainClass));
    }

    private void updateButtons() {
        if (passengerButton != null) passengerButton.field_22763 = !hasCargo();
        if (expressButton != null) expressButton.field_22763 = !hasCargo();
        if (removeButton != null) removeButton.field_22763 = !cars.isEmpty();
        if (pauseButton != null) {
            pauseButton.field_22763 = lineIndex >= 0 && (lineStatus == LineStatus.RUNNING.ordinal()
                    || lineStatus == LineStatus.PAUSED.ordinal());
            pauseButton.method_25355(pauseLabel());
        }
        if (dispatchButton != null) dispatchButton.field_22763 = lineIndex >= 0;
        if (trainListButton != null) trainListButton.field_22763 = lineIndex >= 0;
    }

    private void send(DepotSettingsAction action) {
        commitSpeed();
        long line = lineIndex < 0 ? 0 : lines.get(lineIndex).id();
        ClientPlayNetworking.send(new DepotNetworking.UpdatePayload(depotPos, nameInput.method_1882(),
                new DepotTemplate(cars).encode(), line, trainClass.ordinal(), interval, maximum,
                speeds[TrainClass.CARGO.ordinal()], speeds[TrainClass.PASSENGER.ordinal()],
                speeds[TrainClass.EXPRESS.ordinal()], action.ordinal()));
    }

    @Override
    public void method_25419() {
        ClientPlayNetworking.send(new DepotNetworking.ClosePayload(depotPos));
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = layout();
        int top = layout.top();
        graphics.method_25294(layout.left(), top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_49601(layout.left(), top, layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 9, 0xFFFFFFFF);
        renderText(graphics, class_2561.method_43471("screen.fabric_train_simulator.device.name"),
                layout.left() + 10, top + 24 - scrollOffset, layout, false);
        renderText(graphics, class_2561.method_43469("screen.fabric_train_simulator.depot.speed",
                        class_2561.method_43471("class.fabric_train_simulator." + trainClass.name().toLowerCase(Locale.ROOT))),
                layout.left() + 10, top + 88 - scrollOffset, layout, false);
        int statusY = top + 178 - scrollOffset;
        if (insideContent(statusY, layout)) {
            graphics.method_27534(field_22793, class_2561.method_43469("screen.fabric_train_simulator.depot.interval", interval),
                    field_22789 / 2 - layout.panelWidth() / 4, statusY, 0xFFE6E6E6);
            graphics.method_27534(field_22793, class_2561.method_43469("screen.fabric_train_simulator.depot.active", active, maximum),
                    field_22789 / 2 + layout.panelWidth() / 4, statusY, 0xFFE6E6E6);
        }
        int lineStateY = top + 181 - scrollOffset;
        if (insideContent(lineStateY, layout) && automaticDispatchEnabled && lastAutomaticDispatchResult >= 0
                && lastAutomaticDispatchResult < DepotDispatchResult.values().length) {
            DepotDispatchResult result = DepotDispatchResult.values()[lastAutomaticDispatchResult];
            graphics.method_27534(field_22793, class_2561.method_43469(
                    "screen.fabric_train_simulator.depot.automatic_status",
                    class_2561.method_43471(result.translationKey())), field_22789 / 2,
                    lineStateY + 11, result.succeeded() ? 0xFFBFE7FF : 0xFFFFCC66);
        } else if (insideContent(lineStateY, layout) && pauseState >= 0) {
            String stateKey = pauseState == 2 ? "paused" : pauseState == 1 ? "waiting" : "running";
            graphics.method_27534(field_22793, class_2561.method_43471(
                    "screen.fabric_train_simulator.depot.operation_" + stateKey), field_22789 / 2,
                    lineStateY + 11, 0xFFBFE7FF);
        }
        int operationY = layout.footerY() - 12;
        if (!operationMessageKey.isBlank()) {
            graphics.method_27534(field_22793, class_2561.method_43469(
                    "screen.fabric_train_simulator.depot.operation_result",
                    class_2561.method_43471(operationMessageKey)), field_22789 / 2, operationY, 0xFFFFCC66);
        }
        int sequenceY = top + 260 - scrollOffset;
        renderText(graphics, class_2561.method_43471("screen.fabric_train_simulator.depot.carriage_sequence"),
                layout.left() + 10, sequenceY, layout, false);
        if (cars.isEmpty()) {
            renderText(graphics, class_2561.method_43471("screen.fabric_train_simulator.depot.empty_hint"),
                    layout.left() + 18, sequenceY + 13, layout, false);
        } else {
            for (int i = 0; i < cars.size(); i++) {
                class_2561 type = class_2561.method_43471(cars.get(i) == CarType.CARGO
                        ? "item.fabric_train_simulator.cargo_car" : "item.fabric_train_simulator.passenger_car");
                renderText(graphics, class_2561.method_43469("screen.fabric_train_simulator.depot.carriage_item", i + 1, type),
                        layout.left() + 18, sequenceY + 13 + i * 11, layout, false);
            }
        }
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }

    private void renderText(class_332 graphics, class_2561 text, int x, int y,
                            ResponsiveScreenLayout layout, boolean centered) {
        if (!insideContent(y, layout)) return;
        if (centered) graphics.method_27534(field_22793, text, field_22789 / 2, y, 0xFFE6E6E6);
        else graphics.method_27535(field_22793, text, x, y, 0xFFE6E6E6);
    }
}
