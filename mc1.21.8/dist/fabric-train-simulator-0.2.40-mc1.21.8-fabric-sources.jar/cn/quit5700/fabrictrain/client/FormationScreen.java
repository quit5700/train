package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.FormationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;

public final class FormationScreen extends class_437 {
    private final int seedEntityId;
    private final ArrayList<FormationNetworking.Car> cars;
    private int selected;

    public FormationScreen(FormationNetworking.OpenPayload payload) {
        super(class_2561.method_43471("screen.fabric_train_simulator.formation.title"));
        seedEntityId = payload.seedEntityId();
        cars = new ArrayList<>(payload.cars());
    }

    @Override protected void method_25426() {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 280, 210, 20);
        int left = layout.left() + 10, bottom = layout.footerY();
        int contentWidth = layout.panelWidth() - 20;
        int quarter = (contentWidth - 15) / 4;
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.previous"),
                b -> selected = Math.max(0, selected - 1)).method_46434(left, bottom - 24, quarter, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.up"),
                b -> move(-1)).method_46434(left + 5 + quarter, bottom - 24, quarter, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.down"),
                b -> move(1)).method_46434(left + 10 + quarter * 2, bottom - 24, quarter, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.next"),
                b -> selected = Math.min(cars.size() - 1, selected + 1)).method_46434(left + 15 + quarter * 3, bottom - 24, quarter, 20).method_46431());
        int half = (contentWidth - 10) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.save"),
                b -> save(false)).method_46434(left, bottom, half, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.formation.dissolve"),
                b -> save(true)).method_46434(left + 10 + half, bottom, half, 20).method_46431());
    }

    private void move(int amount) {
        int target = selected + amount;
        if (target < 0 || target >= cars.size()) return;
        var car = cars.remove(selected); cars.add(target, car); selected = target;
    }

    private void save(boolean dissolve) {
        ClientPlayNetworking.send(new FormationNetworking.UpdatePayload(seedEntityId, dissolve,
                cars.stream().map(FormationNetworking.Car::entityId).toList()));
        method_25419();
    }

    @Override public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 280, 210, 20);
        int left = layout.left(), top = layout.top();
        graphics.method_25294(left, top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_49601(left, top, layout.panelWidth(), layout.panelHeight(), 0xFF55DDEE);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 9, 0xFFFFFFFF);
        int first = Math.max(0, Math.min(selected - 4, Math.max(0, cars.size() - 9)));
        for (int i = first; i < Math.min(cars.size(), first + 9); i++) {
            int y = top + 30 + (i - first) * 15;
            if (i == selected) graphics.method_25294(left + 15, y - 2, layout.right() - 15, y + 12, 0xAA2C6B78);
            graphics.method_27535(field_22793, class_2561.method_43469("screen.fabric_train_simulator.formation.row",
                    i + 1, cars.get(i).name()), left + 22, y, 0xFFE6E6E6);
        }
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }
}
