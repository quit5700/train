package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_2561;
import net.minecraft.class_2768;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import cn.quit5700.fabrictrain.entity.PassengerCarEntity;
import cn.quit5700.fabrictrain.data.*;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.cargo.CargoTransferService;
import cn.quit5700.fabrictrain.cargo.CargoUnloadRules;
import cn.quit5700.fabrictrain.cargo.CargoLedgerService;
import cn.quit5700.fabrictrain.depot.DepotRecoveryService;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.route.RuntimePathCache;
import cn.quit5700.fabrictrain.route.TrackPoint;
import cn.quit5700.fabrictrain.route.LineLoopRules;
import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.power.PowerSectionCache;
import cn.quit5700.fabrictrain.route.SwitchRailRouting;
import cn.quit5700.fabrictrain.route.RealtimeSwitchTraffic;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import cn.quit5700.fabrictrain.registry.ModBlocks;

import java.util.*;

public final class TrainControllerManager {
    private static final double CAR_SPACING = FormationSpacing.BLOCKS;
    private static final Map<UUID, TrackTrail> TRAILS = new HashMap<>();
    private static final Map<UUID, PausedTrain> PAUSED = new HashMap<>();
    private static final Map<UUID, RouteProgress> ROUTES = new HashMap<>();
    private static final Map<UUID, LogicalMotion> LOGICAL_MOTIONS = new HashMap<>();
    private static final Map<UUID, AutomaticPath> AUTOMATIC_PATHS = new HashMap<>();
    private static long ticks;
    private static final Set<Long> EMERGENCY_STATIONS=new HashSet<>();
    private static final Map<UUID, Integer> CAR_ONLY_INPUT = new HashMap<>();
    private static final Map<UUID, UUID> DIAGNOSTIC_DRIVERS = new HashMap<>();
    private static final Map<UUID, String> LAST_DIAGNOSTIC_REASON = new HashMap<>();
    private static final Map<UUID,ManualInput> MANUAL=new HashMap<>();
    private static final Map<SwitchTrafficKey, UUID> REALTIME_SWITCH_RIGHTS = new HashMap<>();
    private static final Map<UUID, class_3218> PENDING_DESTROYED_TRAINS = new HashMap<>();
    private static final Set<UUID> OFFLINE_REMOVALS = new HashSet<>();

    private TrainControllerManager() {
    }

    public static void tick(MinecraftServer server) {
        ticks++;
        Set<UUID> active = new HashSet<>();
        Set<UUID> observed = new HashSet<>();
        for (class_3218 level : server.method_3738()) {
            Map<UUID, List<class_1297>> trains = new HashMap<>();
            for (class_1297 entity : level.method_27909()) {
                if (entity instanceof LinkedTrainCar linked && !entity.method_31481()) {
                    trains.computeIfAbsent(linked.trainLink().trainId(), ignored -> new ArrayList<>()).add(entity);
                }
            }
            retireDestroyedTrainsMissingFromLevel(level, trains);
            RailwaySavedData levelData = RailwayDataManager.state(level);
            trains.entrySet().removeIf(entry -> {
                if (!levelData.isTrainPendingDeletion(entry.getKey())) return false;
                entry.getValue().forEach(entity -> {
                    entity.method_5772();
                    entity.method_31472();
                });
                retireTrainResources(level, entry.getKey());
                return true;
            });
            observed.addAll(trains.keySet());
            rebuildRealtimeSwitchRights(level, trains);
            trains.forEach((trainId, cars) -> {
                LinkedTrainCar sample = (LinkedTrainCar) cars.getFirst();
                RailwaySavedData registryData = RailwayDataManager.state(level);
                boolean firstMembershipObservation = registryData.trainManifest(trainId) == null;
                registryData.ensureTrain(trainId,
                        sample.trainLink().depotGenerated(), sample.trainLink().lineId(),sample.trainLink().controlMode());
                cars.forEach(entity -> TrainRegistryService.observeLoadedVehicle(
                        level, entity, (LinkedTrainCar) entity));
                if (firstMembershipObservation)
                    TrainRegistryService.replaceFormation(level, trainId,
                            TrainRegistryService.stableOrder(cars));
                boolean hasLocomotive = cars.stream().anyMatch(LocomotiveEntity.class::isInstance);
                boolean controlled = hasLocomotive || cars.size() > 1;
                cars.forEach(entity -> {
                    if (entity instanceof LogicallyControlledVehicle vehicle)
                        vehicle.fabricTrain$setLogicallyControlled(controlled);
                });
                if (hasLocomotive) tickTrain(level, trainId, cars, active);
                else if (cars.size() > 1) tickCarOnlyGroup(level, trainId, cars, active);
            });
        }
        ArrayList<Map.Entry<UUID, class_3218>> destroyed = new ArrayList<>(PENDING_DESTROYED_TRAINS.entrySet());
        for (Map.Entry<UUID, class_3218> entry : destroyed) {
            if (observed.contains(entry.getKey())) continue;
            retireTrainResources(entry.getValue(), entry.getKey());
        }
        TRAILS.keySet().removeIf(id -> !active.contains(id));
        LOGICAL_MOTIONS.keySet().removeIf(id -> !active.contains(id));
        AUTOMATIC_PATHS.keySet().removeIf(id -> !active.contains(id));
        ROUTES.keySet().removeIf(id -> !active.contains(id));
        REALTIME_SWITCH_RIGHTS.entrySet().removeIf(entry -> !active.contains(entry.getValue()));
        PAUSED.entrySet().removeIf(entry -> {
            if (entry.getValue().resumeAtTick() > ticks) return false;
            class_1297 entity = findEntity(server, entry.getKey());
            if (entity instanceof LocomotiveEntity locomotive) {
                if(EMERGENCY_STATIONS.contains(locomotive.trainLink().lastDeviceId()))return false;
                RailwayLine line = RailwayDataManager.state((class_3218) locomotive.method_37908())
                        .line(locomotive.trainLink().lineId());
                if (AutomaticLinePauseRules.holdAtStation(locomotive.trainLink().controlMode(),
                        line == null ? null : line.status())) return false;
                locomotive.method_18799(entry.getValue().resumeVelocity());
                locomotive.trainLink().setAutomaticRunning(true);
            }
            return true;
        });
    }

    public static void noteVehicleDestroyed(class_3218 level, UUID trainId) {
        if (level == null || trainId == null) return;
        if (OFFLINE_REMOVALS.contains(trainId)) return;
        PENDING_DESTROYED_TRAINS.put(trainId, level);
    }

    public static void noteVehicleRemoved(class_3218 level, UUID trainId, UUID entityId,
                                          class_1297.class_5529 reason) {
        if (level == null || trainId == null || entityId == null || reason == null) return;
        if (reason.method_31486()) {
            if (OFFLINE_REMOVALS.contains(trainId)) return;
            RailwaySavedData.MemberRemovalResult result = TrainRegistryService.removeVehicle(
                    level, trainId, entityId);
            if (result == RailwaySavedData.MemberRemovalResult.TRAIN_EMPTY)
                retireTrainResources(level, trainId);
            else if (result == RailwaySavedData.MemberRemovalResult.UNKNOWN_MEMBER)
                noteVehicleDestroyed(level, trainId);
        }
        else if (!OFFLINE_REMOVALS.contains(trainId))
            RailwayDataManager.state(level).updateTrainPresence(trainId, TrainPresence.UNLOADED);
    }

    static void beginOfflineRemoval(UUID trainId) { OFFLINE_REMOVALS.add(trainId); }
    static void finishOfflineRemoval(class_3218 level, UUID trainId) {
        OFFLINE_REMOVALS.remove(trainId);
        releaseTrainSwitches(trainId);
        TRAILS.remove(trainId); LOGICAL_MOTIONS.remove(trainId); AUTOMATIC_PATHS.remove(trainId);
        ROUTES.remove(trainId); PAUSED.entrySet().removeIf(entry -> entry.getKey().equals(trainId));
    }

    static void restoreOfflinePath(OfflineTrainState state, LocomotiveEntity locomotive) {
        AUTOMATIC_PATHS.put(state.trainId(), new AutomaticPath(state.path(), state.loop(),
                state.loopStartIndex(), state.loopStartIndex()));
        LogicalMotion motion = new LogicalMotion();
        motion.speed.restore(state.speed());
        LOGICAL_MOTIONS.put(state.trainId(), motion);
        ROUTES.put(state.trainId(), new RouteProgress(state.nextNodeIndex(), state.lastDeviceId(), 0L));
    }

    private static void retireDestroyedTrainsMissingFromLevel(class_3218 level,
                                                              Map<UUID, List<class_1297>> trains) {
        new ArrayList<>(PENDING_DESTROYED_TRAINS.entrySet()).stream()
                .filter(entry -> entry.getValue() == level && !trains.containsKey(entry.getKey()))
                .map(Map.Entry::getKey)
                .toList()
                .forEach(trainId -> retireTrainResources(level, trainId));
    }

    public static void retireTrainResources(class_3218 level, UUID trainId) {
        if (level == null || trainId == null) return;
        releaseTrainSwitches(trainId);
        TRAILS.remove(trainId);
        LOGICAL_MOTIONS.remove(trainId);
        AUTOMATIC_PATHS.remove(trainId);
        ROUTES.remove(trainId);
        CAR_ONLY_INPUT.remove(trainId);
        DIAGNOSTIC_DRIVERS.remove(trainId);
        LAST_DIAGNOSTIC_REASON.remove(trainId);
        PENDING_DESTROYED_TRAINS.remove(trainId);
        RailwaySavedData data = RailwayDataManager.state(level);
        data.markTrainForDeletion(trainId);
        OfflineTrainService.state(level.method_8503()).remove(trainId);
    }

    /** Administrative deletion: removes the physical formation and every server-side resource without drops. */
    public static boolean deleteTrainEverywhere(MinecraftServer server, UUID trainId) {
        if (server == null || trainId == null) return false;
        boolean found = false;
        for (class_3218 level : server.method_3738()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            if (data.trainRecord(trainId) != null) found = true;
            data.markTrainForDeletion(trainId);
            List<class_1297> vehicles = new ArrayList<>();
            for (class_1297 entity : level.method_27909()) {
                if (entity instanceof LinkedTrainCar car && car.trainLink().trainId().equals(trainId))
                    vehicles.add(entity);
            }
            if (!vehicles.isEmpty()) found = true;
            vehicles.forEach(entity -> { entity.method_5772(); entity.method_31472(); });
            retireTrainResources(level, trainId);
        }
        return found;
    }

    public static Set<UUID> automaticTrainIds(class_3218 level, long lineId) {
        Set<UUID> result = new HashSet<>();
        RailwaySavedData data = RailwayDataManager.state(level);
        data.presentTrainRecords().forEach((trainId, record) -> {
            if (record.lineId() == lineId && record.controlMode() == ControlMode.ROUTE_AUTOMATIC)
                result.add(trainId);
        });
        for (class_1297 entity : level.method_27909()) {
            if (entity instanceof LinkedTrainCar car
                    && car.trainLink().lineId() == lineId
                    && car.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC)
                result.add(car.trainLink().trainId());
        }
        return Set.copyOf(result);
    }

    /** Removes only the previous automatic formations after their replacement was spawned successfully. */
    public static void refreshAutomaticLine(class_3218 level, long lineId, UUID replacementTrainId,
                                            Set<UUID> previousAutomaticTrains) {
        if (level == null || previousAutomaticTrains == null) return;
        Set<UUID> retired = new HashSet<>(previousAutomaticTrains);
        retired.remove(replacementTrainId);
        if (retired.isEmpty()) return;
        for (UUID trainId : retired) RailwayDataManager.state(level).markTrainForDeletion(trainId);
        for (class_1297 entity : level.method_27909()) {
            if (!(entity instanceof LinkedTrainCar car) || !retired.contains(car.trainLink().trainId())) continue;
            entity.method_5772();
            entity.method_31472();
        }
        retired.forEach(trainId -> retireTrainResources(level, trainId));
    }

    public static void drive(class_3222 player, class_1297 occupiedVehicle, boolean forward, boolean brake) {
        if (!(occupiedVehicle instanceof LinkedTrainCar occupiedCar)) return;
        UUID trainId = occupiedCar.trainLink().trainId();
        List<class_1297> diagnosticFormation = TrainFormationService.formation(occupiedVehicle);
        class_1297 diagnosticLeader = diagnosticFormation.isEmpty() ? occupiedVehicle : diagnosticFormation.getFirst();
        UUID winner = closestDriverId(player, trainId, diagnosticLeader);
        if (forward || brake) {
            DIAGNOSTIC_DRIVERS.put(trainId, player.method_5667());
            LAST_DIAGNOSTIC_REASON.remove(trainId);
        }
        if (!occupiedCar.trainLink().controlMode().playerDriveAllowed()) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.train.depot_controlled"));
            diagnostic(player, "message.fabric_train_simulator.diagnostic.rejected",
                    class_2561.method_43471("message.fabric_train_simulator.diagnostic.reason.depot"));
            return;
        }
        UUID locomotiveId = occupiedCar.trainLink().locomotiveId();
        class_1297 found = findEntity(player.method_5682(), locomotiveId);
        if (!(found instanceof LocomotiveEntity locomotive)) {
            if (occupiedCar.trainLink().hasLocomotive()) {
                if (forward || brake) diagnostic(player,
                        "message.fabric_train_simulator.diagnostic.rejected",
                        class_2561.method_43471("message.fabric_train_simulator.diagnostic.reason.locomotive_missing"));
                return;
            }
            List<class_1297> formation = TrainFormationService.formation(occupiedVehicle);
            if (formation.isEmpty()) return;
            class_1297 leader = formation.getFirst();
            if (!isClosestDriver(player, occupiedCar.trainLink().trainId(), leader)) {
                if (forward || brake) cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(
                        "message.fabric_train_simulator.train.no_control"));
                if (forward || brake) diagnostic(player,
                        "message.fabric_train_simulator.diagnostic.rejected",
                        class_2561.method_43471("message.fabric_train_simulator.diagnostic.reason.authority"));
                return;
            }
            int input = forward ? 1 : brake ? -1 : 0;
            CAR_ONLY_INPUT.put(occupiedCar.trainLink().trainId(), input);
            formation.forEach(entity -> {
                if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
                if (entity instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            });
            return;
        }
        if (!isClosestDriver(player, occupiedCar.trainLink().trainId(), locomotive)) {
            if (forward || brake) cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(
                    "message.fabric_train_simulator.train.no_control"));
            if (forward || brake) diagnostic(player,
                    "message.fabric_train_simulator.diagnostic.rejected",
                    class_2561.method_43471("message.fabric_train_simulator.diagnostic.reason.authority"));
            return;
        }
        if (forward && railDirection(locomotive) == null) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.train.not_on_rail"));
            diagnostic(player, "message.fabric_train_simulator.diagnostic.rejected",
                    class_2561.method_43471("message.fabric_train_simulator.diagnostic.reason.not_on_rail"));
            return;
        }
        locomotive.trainLink().setParked(false);
        for (class_1297 entity : player.method_51469().method_27909()) {
            if (entity instanceof LinkedTrainCar car
                    && car.trainLink().trainId().equals(occupiedCar.trainLink().trainId())) {
                car.trainLink().setParked(false);
                if (entity instanceof PassengerCarEntity passenger) passenger.releasePlacementBrake();
                if (entity instanceof CargoCarEntity cargo) cargo.releasePlacementBrake();
            }
        }
        PAUSED.remove(locomotiveId);
        if(forward){MANUAL.remove(locomotiveId);locomotive.trainLink().setAutomaticRunning(true);}
        else if(brake){locomotive.trainLink().setAutomaticRunning(false);MANUAL.put(locomotiveId,new ManualInput(false,true,ticks));}
        else if(MANUAL.remove(locomotiveId)!=null){locomotive.method_18799(class_243.field_1353);PAUSED.put(locomotiveId,new PausedTrain(ticks+AutoResumeTimer.DEFAULT_DELAY_TICKS,direction(locomotive).method_1021(targetSpeed(locomotive))));}
    }

    public static void registerAutomaticPath(UUID trainId, List<cn.quit5700.fabrictrain.route.TrackPoint> path,
                                             boolean loop, int loopStartIndex) {
        if (trainId == null || path == null || path.size() < 2) return;
        AUTOMATIC_PATHS.put(trainId, new AutomaticPath(List.copyOf(path), loop,
                Math.clamp(loopStartIndex, 0, path.size() - 2), Math.max(0, loopStartIndex)));
        LOGICAL_MOTIONS.remove(trainId);
    }

    private static void diagnostic(class_3222 player, String key, Object... arguments) {
        // End-of-development diagnostics are intentionally no longer player-visible.
    }

    public static void emergencyStopAt(long stationId){EMERGENCY_STATIONS.add(stationId);}
    public static void releaseEmergencyAt(long stationId){EMERGENCY_STATIONS.remove(stationId);}
    public static void continueAutomaticLine(MinecraftServer server, long lineId) {
        PAUSED.replaceAll((locomotiveId, paused) -> {
            class_1297 entity = findEntity(server, locomotiveId);
            if (entity instanceof LocomotiveEntity locomotive
                    && locomotive.trainLink().lineId() == lineId
                    && locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC) {
                return new PausedTrain(ticks, paused.resumeVelocity());
            }
            return paused;
        });
    }
    public static void departStation(MinecraftServer server,long stationId){
        EMERGENCY_STATIONS.remove(stationId);
        for(class_3218 level:server.method_3738())for(class_1297 entity:level.method_27909())if(entity instanceof LocomotiveEntity locomotive&&locomotive.trainLink().lastDeviceId()==stationId){
            PausedTrain paused=PAUSED.remove(locomotive.method_5667());class_243 velocity=paused==null?direction(locomotive).method_1021(targetSpeed(locomotive)):paused.resumeVelocity();locomotive.method_18799(velocity);locomotive.trainLink().setAutomaticRunning(true);
        }
    }
    public static void startLine(MinecraftServer server,long lineId){for(class_3218 level:server.method_3738())for(class_1297 entity:level.method_27909())if(entity instanceof LocomotiveEntity locomotive&&locomotive.trainLink().lineId()==lineId){locomotive.trainLink().setAutomaticRunning(true);PAUSED.remove(locomotive.method_5667());}}

    private static boolean isClosestDriver(class_3222 player, UUID trainId, class_1297 leader) {
        return player.method_5667().equals(closestDriverId(player, trainId, leader));
    }

    private static UUID closestDriverId(class_3222 player, UUID trainId, class_1297 leader) {
        ArrayList<TrainDriverAuthority.Rider> riders = new ArrayList<>();
        for (class_1297 vehicle : player.method_51469().method_27909()) {
            if (!(vehicle instanceof LinkedTrainCar linked) || !linked.trainLink().trainId().equals(trainId)) continue;
            for (class_1297 passenger : vehicle.method_5685()) {
                if (passenger instanceof class_3222 rider)
                    riders.add(new TrainDriverAuthority.Rider(rider.method_5667(), rider.method_5858(leader)));
            }
        }
        return TrainDriverAuthority.closest(riders);
    }

    private static class_243 direction(LocomotiveEntity locomotive) {
        return locomotive.trainLink().formationForward()
                .map(value->new class_243(value.method_10148(),0,value.method_10165()))
                .orElseGet(()->direction((class_1297)locomotive));
    }

    private static class_243 railDirection(LocomotiveEntity locomotive) {
        class_2338 railPos = locomotive.method_62825();
        if (!class_2241.method_9479(locomotive.method_37908(), railPos)) return null;
        var state = locomotive.method_37908().method_8320(railPos);
        if (!state.method_28498(class_2443.field_11369)) return null;
        var exits = class_1688.method_22864(state.method_11654(class_2443.field_11369));
        return RailStartDirection.choose(exits.getFirst(), exits.getSecond(), direction(locomotive));
    }

    private static void rebuildRealtimeSwitchRights(class_3218 level, Map<UUID, List<class_1297>> trains) {
        String dimension = RailwayDataManager.dimension(level);
        REALTIME_SWITCH_RIGHTS.keySet().removeIf(key -> key.dimension().equals(dimension));
        RailwaySavedData data = RailwayDataManager.state(level);
        Map<Long, List<RealtimeSwitchTraffic.Candidate>> candidates = new HashMap<>();
        List<RailwayDevice> switches = data.devices().values().stream()
                .filter(device -> device.type() == DeviceType.SWITCH && device.dimension().equals(dimension))
                .toList();

        for (RailwayDevice device : switches) {
            class_243 center = class_243.method_24953(new class_2338(device.x(), device.y(), device.z()));
            for (Map.Entry<UUID, List<class_1297>> train : trains.entrySet()) {
                double nearest = train.getValue().stream().mapToDouble(entity -> entity.method_5707(center))
                        .min().orElse(Double.MAX_VALUE);
                if (nearest <= 16.0D) candidates.computeIfAbsent(device.id(), ignored -> new ArrayList<>())
                        .add(new RealtimeSwitchTraffic.Candidate(train.getKey(), nearest, true));
            }
        }

        trains.forEach((trainId, cars) -> cars.stream().filter(LocomotiveEntity.class::isInstance)
                .map(LocomotiveEntity.class::cast).findFirst().ifPresent(locomotive -> {
                    RailwayDevice target = locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC
                            ? nextAutomaticSwitch(data, locomotive) : nextManualSwitch(level, data, locomotive);
                    if (target == null) return;
                    double distanceSquared = locomotive.method_5707(
                            class_243.method_24953(new class_2338(target.x(), target.y(), target.z())));
                    double reservation = RealtimeSwitchTraffic.reservationDistance(currentLogicalSpeed(trainId));
                    if (distanceSquared <= reservation * reservation) {
                        candidates.computeIfAbsent(target.id(), ignored -> new ArrayList<>())
                                .add(new RealtimeSwitchTraffic.Candidate(trainId, distanceSquared, false));
                    }
                }));

        candidates.forEach((deviceId, values) -> RealtimeSwitchTraffic.chooseWinner(values)
                .ifPresent(trainId -> REALTIME_SWITCH_RIGHTS.put(
                        new SwitchTrafficKey(dimension, deviceId), trainId)));
    }

    private static RailwayDevice nextAutomaticSwitch(RailwaySavedData data, LocomotiveEntity locomotive) {
        RailwayLine line = data.line(locomotive.trainLink().lineId());
        if (line == null || line.nodeIds().isEmpty()) return null;
        RouteProgress progress = routeProgress(locomotive);
        int index = Math.min(progress.nextNodeIndex, line.nodeIds().size() - 1);
        RailwayDevice device = data.device(line.nodeIds().get(index));
        return device != null && device.type() == DeviceType.SWITCH ? device : null;
    }

    private static RailwayDevice nextManualSwitch(class_3218 level, RailwaySavedData data,
                                                   LocomotiveEntity locomotive) {
        net.minecraft.class_2350 travel = travelDirection(locomotive);
        class_2338 railPos = locomotive.method_62825();
        for (int distance = 0; distance <= 2; distance++) {
            class_2338 switchPos = switchAt(level, railPos.method_10079(travel, distance));
            if (switchPos == null) continue;
            return data.find(RailwayDataManager.dimension(level),
                    switchPos.method_10263(), switchPos.method_10264(), switchPos.method_10260());
        }
        return null;
    }

    private static double currentLogicalSpeed(UUID trainId) {
        LogicalMotion motion = LOGICAL_MOTIONS.get(trainId);
        return motion == null ? 0.0D : Math.abs(motion.speed.speed());
    }

    private static boolean hasSwitchRight(class_3218 level, long deviceId, UUID trainId) {
        UUID winner = REALTIME_SWITCH_RIGHTS.get(
                new SwitchTrafficKey(RailwayDataManager.dimension(level), deviceId));
        return winner == null || winner.equals(trainId);
    }

    private static FollowingTrainDecision automaticFollowingDecision(class_3218 level,
                                                                     LocomotiveEntity locomotive) {
        if (locomotive.trainLink().controlMode() != ControlMode.ROUTE_AUTOMATIC)
            return FollowingTrainDecision.clear();
        UUID trainId = locomotive.trainLink().trainId();
        net.minecraft.class_2350 direction = travelDirection(locomotive);
        double forwardX = direction.method_10148();
        double forwardZ = direction.method_10165();
        double required = TrainTrafficSafety.stoppingDistance(currentLogicalSpeed(trainId));
        FollowingTrainDecision result = FollowingTrainDecision.clear();
        for (class_1297 other : level.method_27909()) {
            if (!(other instanceof LinkedTrainCar linked) || other.method_31481()
                    || linked.trainLink().trainId().equals(trainId)) continue;
            double dx = other.method_23317() - locomotive.method_23317();
            double dz = other.method_23321() - locomotive.method_23321();
            double forward = dx * forwardX + dz * forwardZ;
            double lateralSquared = Math.max(0.0D, dx * dx + dz * dz - forward * forward);
            if (!TrainTrafficSafety.blocks(forward, lateralSquared,
                    other.method_23318() - locomotive.method_23318(), required)) continue;
            LocomotiveEntity otherLocomotive = locomotiveForTrain(level, linked.trainLink().trainId());
            boolean sameDirection = otherLocomotive != null
                    && travelDirection(locomotive).method_62676().method_1026(
                    travelDirection(otherLocomotive).method_62676()) > 0.5D;
            FollowingTrainDecision candidate = FollowingTrainDecision.evaluate(true, sameDirection,
                    currentLogicalSpeed(linked.trainLink().trainId()));
            result = result.restrictWith(candidate);
            if (result.hardStop()) {
                notifyDiagnostic(level, trainId, "waiting_train", currentLogicalSpeed(trainId),
                        locomotive.method_24515());
                return result;
            }
        }
        return result;
    }

    private static LocomotiveEntity locomotiveForTrain(class_3218 level, UUID trainId) {
        for (class_1297 entity : level.method_27909()) {
            if (entity instanceof LocomotiveEntity locomotive
                    && locomotive.trainLink().trainId().equals(trainId) && !entity.method_31481()) return locomotive;
        }
        return null;
    }

    private static void tickTrain(class_3218 level, UUID trainId, List<class_1297> cars, Set<UUID> active) {
        LocomotiveEntity locomotive = cars.stream()
                .filter(LocomotiveEntity.class::isInstance)
                .map(LocomotiveEntity.class::cast)
                .findFirst().orElse(null);
        if (locomotive == null) return;
        active.add(trainId);
        RouteProgress persistedProgress = routeProgress(locomotive);
        if (persistedProgress.lockedSwitchId != 0L) {
            persistedProgress.lockedSwitchId = 0L;
            syncRouteProgress(locomotive, persistedProgress);
        }
        LogicalMotion motion = LOGICAL_MOTIONS.get(trainId);
        class_2338 actualRail = motion != null && motion.cursor != null
                && class_2241.method_9479(level, motion.cursor.currentRail())
                ? motion.cursor.currentRail() : RailPositionResolver.resolve(level, locomotive);
        if (locomotive.trainLink().lineId() > 0 && actualRail == null) {
            releaseTrainSwitches(trainId);
            DerailedTrainRecoveryService.dropAsItems(level, cars);
            return;
        }
        if (locomotive.trainLink().loadedFromSave() && tryStartupRecovery(level, locomotive, cars)) return;
        RailwayLine operatingLine = RailwayDataManager.state(level).line(locomotive.trainLink().lineId());
        if (operatingLine == null && !prepareManualSwitch(level, locomotive, cars)) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return;
        }
        if (operatingLine != null && operatingLine.status() == LineStatus.MAINTENANCE) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return;
        }
        if (operatingLine != null && locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC
                && !ensureAutomaticCursor(level, trainId, locomotive)) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return;
        }
        motion = LOGICAL_MOTIONS.get(trainId);
        boolean nextLoaded = motion != null && motion.cursor != null
                ? nextRouteChunkLoaded(level, motion.cursor)
                : nextTrainChunkLoaded(level, locomotive);
        if (!nextLoaded) {
            AutomaticPath path = AUTOMATIC_PATHS.get(trainId);
            LogicalMotion offlineMotion = LOGICAL_MOTIONS.get(trainId);
            if (path != null && offlineMotion != null && offlineMotion.cursor != null
                    && locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC
                    && OfflineTrainService.transition(level, locomotive, cars, path.points(), path.loop(),
                    path.loopStartIndex(), offlineMotion.cursor.routeIndex(), offlineMotion.cursor.segmentProgress(),
                    Math.max(offlineMotion.speed.speed(), targetSpeed(locomotive)))) return;
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return;
        }
        motion = LOGICAL_MOTIONS.get(trainId);
        AutomaticPath activePath = AUTOMATIC_PATHS.get(trainId);
        boolean powered = operatingLine == null || (motion != null && motion.cursor != null && activePath != null
                ? motion.cursor.routeIndex() < activePath.linePathStartIndex()
                    ? actualRail != null && RailPowerService.isPowered(level, actualRail)
                    : PowerSectionCache.canProceed(operatingLine.id(),
                        motion.cursor.routeIndex() - activePath.linePathStartIndex())
                : actualRail != null && RailPowerService.isPowered(level, actualRail));
        if (!powered) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return;
        }
        FollowingTrainDecision following = automaticFollowingDecision(level, locomotive);
        boolean routeClear = !following.hardStop() && prepareNextSwitch(level, locomotive, cars);
        if (routeClear) {
            if (operatingLine == null) processManualStationAnnouncement(level, locomotive);
            else processLineNode(level, locomotive, cars);
        }
        TrackTrail trail = TRAILS.computeIfAbsent(trainId, ignored -> new TrackTrail(140.0D));
        if (!advanceLogicalTrain(level, trainId, locomotive, routeClear, following.speedLimit(), trail)) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
        }
        cars.stream()
                .filter(entity -> entity != locomotive)
                .sorted(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()))
                .forEach(entity -> follow(level, locomotive, entity, trail));
    }

    private static boolean advanceLogicalTrain(class_3218 level, UUID trainId, LocomotiveEntity locomotive,
                                               boolean routeClear, double followingSpeedLimit, TrackTrail trail) {
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(trainId, ignored -> new LogicalMotion());
        ManualInput manual = MANUAL.get(locomotive.method_5667());
        double target = 0;
        if (routeClear && !PAUSED.containsKey(locomotive.method_5667())) {
            if (manual != null && manual.backward()) target = -targetSpeed(locomotive);
            else if (manual != null && manual.forward()) target = targetSpeed(locomotive);
            else if (locomotive.trainLink().automaticRunning()) target = targetSpeed(locomotive);
            if (Double.isFinite(followingSpeedLimit))
                target = Math.copySign(Math.min(Math.abs(target), followingSpeedLimit), target);
        }
        double acceleration = routeClear ? 0.015D : TrainTrafficSafety.EMERGENCY_DECELERATION;
        double speed = motion.speed.approach(target, acceleration);
        if (Math.abs(speed) < 0.0001D) {
            locomotive.method_18799(class_243.field_1353);
            return true;
        }
        if (motion.cursor == null) {
            AutomaticPath automaticPath = locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC
                    ? AUTOMATIC_PATHS.get(trainId) : null;
            motion.cursor = automaticPath == null
                    ? RailMotionCursor.create(level, locomotive, direction(locomotive))
                    : RailMotionCursor.createRoute(level, locomotive, automaticPath.points(), automaticPath.loop(),
                    automaticPath.loopStartIndex());
            if (motion.cursor == null) {
                motion.speed.stop();
                locomotive.trainLink().setAutomaticRunning(false);
                releaseTrainSwitches(trainId);
                notifyDiagnostic(level, trainId, "cursor_missing", motion.speed.speed(), locomotive.method_24515());
                return false;
            }
        }
        RailMotionCursor.Pose pose = motion.cursor.advance(level, speed);
        if (pose == null || !level.method_22340(class_2338.method_49638(pose.position()))) {
            motion.speed.stop();
            locomotive.trainLink().setAutomaticRunning(false);
            if (pose == null) releaseTrainSwitches(trainId);
            notifyDiagnostic(level, trainId, pose == null ? "rail_ended" : "chunk_unloaded",
                    motion.speed.speed(), locomotive.method_24515());
            return false;
        }
        locomotive.method_33574(pose.position());
        locomotive.method_36456(pose.yaw());
        FormationDirection.fromPositions(-Math.sin(Math.toRadians(pose.yaw())),
                Math.cos(Math.toRadians(pose.yaw())),0,0).ifPresent(locomotive.trainLink()::setFormationForward);
        locomotive.method_36457(0);
        locomotive.method_18799(class_243.field_1353);
        trail.record(pose.position().field_1352, pose.position().field_1351, pose.position().field_1350);
        notifyDiagnostic(level, trainId, "moving", speed, class_2338.method_49638(pose.position()));
        return true;
    }

    private static boolean ensureAutomaticCursor(class_3218 level, UUID trainId, LocomotiveEntity locomotive) {
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(trainId, ignored -> new LogicalMotion());
        if (motion.cursor != null) return true;
        AutomaticPath automaticPath = AUTOMATIC_PATHS.get(trainId);
        if (automaticPath == null) return false;
        motion.cursor = RailMotionCursor.createRoute(level, locomotive, automaticPath.points(), automaticPath.loop(),
                automaticPath.loopStartIndex());
        if (motion.cursor != null) return true;
        motion.speed.stop();
        locomotive.trainLink().setAutomaticRunning(false);
        releaseTrainSwitches(trainId);
        notifyDiagnostic(level, trainId, "cursor_missing", motion.speed.speed(), locomotive.method_24515());
        return false;
    }

    private static void notifyDiagnostic(class_3218 level, UUID trainId, String reason, double speed, class_2338 pos) {
        LAST_DIAGNOSTIC_REASON.put(trainId, reason);
    }

    private static void applyManual(LocomotiveEntity locomotive){ManualInput input=MANUAL.get(locomotive.method_5667());if(input==null||(!input.forward&&!input.backward))return;class_243 forward=direction(locomotive);double signed=locomotive.method_18798().method_1026(forward);double target=(input.forward?1:-1)*targetSpeed(locomotive);double acceleration=0.015;double next=signed<target?Math.min(target,signed+acceleration):Math.max(target,signed-acceleration);if(Math.abs(next)<0.005)next=0;locomotive.method_18799(forward.method_1021(next));}

    private static void tickCarOnlyGroup(class_3218 level, UUID trainId, List<class_1297> cars, Set<UUID> active) {
        class_1297 leader = cars.stream().min(Comparator.comparingInt(entity ->
                ((LinkedTrainCar) entity).trainLink().carIndex())).orElse(null);
        if (leader == null) return;
        active.add(trainId);
        TrackTrail trail = TRAILS.computeIfAbsent(trainId, ignored -> new TrackTrail(140.0D));
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(trainId, ignored -> new LogicalMotion());
        int input = CAR_ONLY_INPUT.getOrDefault(trainId, 0);
        double limit = SpeedRules.blocksPerTick(SpeedRules.classLimit(
                ((LinkedTrainCar) leader).trainLink().trainClass()));
        double speed = motion.speed.approach(input * limit, 0.015D);
        if (Math.abs(speed) > 0.0001D && leader instanceof class_1688 minecart) {
            if (motion.cursor == null) motion.cursor = RailMotionCursor.create(level, minecart, direction(leader));
            RailMotionCursor.Pose pose = motion.cursor == null ? null : motion.cursor.advance(level, speed);
            if (pose == null || !level.method_22340(class_2338.method_49638(pose.position()))) {
                motion.speed.stop();
                CAR_ONLY_INPUT.put(trainId, 0);
                notifyDiagnostic(level, trainId, pose == null ? "cursor_missing" : "chunk_unloaded",
                        motion.speed.speed(), leader.method_24515());
            } else {
                leader.method_33574(pose.position());
                leader.method_36456(pose.yaw());
                leader.method_18799(class_243.field_1353);
                trail.record(pose.position().field_1352, pose.position().field_1351, pose.position().field_1350);
                notifyDiagnostic(level, trainId, "moving", speed, class_2338.method_49638(pose.position()));
            }
        } else {
            leader.method_18799(class_243.field_1353);
            trail.record(leader.method_23317(), leader.method_23318(), leader.method_23321());
        }
        cars.stream().filter(entity -> entity != leader)
                .sorted(Comparator.comparingInt(entity -> ((LinkedTrainCar) entity).trainLink().carIndex()))
                .forEach(entity -> {
                    int index = Math.max(1, ((LinkedTrainCar) entity).trainLink().carIndex());
                    TrackTrail.Point target = trail.pointBehind(index * CAR_SPACING);
                    if (target == null) {
                        class_243 anchor = FormationGeometry.anchor(leader.method_19538(), entity.method_19538(), index * CAR_SPACING);
                        entity.method_33574(anchor);
                    } else entity.method_5814(target.x(), target.y(), target.z());
                    if (entity instanceof CargoCarEntity cargo) {
                        cargo.beginAuthorizedPush();
                        try { entity.method_18799(leader.method_18798()); }
                        finally { cargo.endAuthorizedPush(); }
                    } else entity.method_18799(leader.method_18798());
                });
    }

    private static class_243 direction(class_1297 entity) {
        double radians = Math.toRadians(entity.method_36454());
        return new class_243(-Math.sin(radians), 0, Math.cos(radians));
    }

    private static void maintainAutomaticSpeed(LocomotiveEntity locomotive) {
        if (!locomotive.trainLink().automaticRunning() || PAUSED.containsKey(locomotive.method_5667())) return;
        double target = targetSpeed(locomotive);
        class_243 velocity = locomotive.method_18798();
        double horizontal = Math.sqrt(velocity.method_37268());
        class_243 travelDirection = horizontal > 0.001D
                ? new class_243(velocity.field_1352 / horizontal, 0, velocity.field_1350 / horizontal)
                : railDirection(locomotive);
        if (travelDirection == null) {
            locomotive.method_18799(class_243.field_1353);
            locomotive.trainLink().setAutomaticRunning(false);
            return;
        }
        double nextSpeed = Math.min(target, horizontal + 0.015D);
        locomotive.method_18800(travelDirection.field_1352 * nextSpeed, velocity.field_1351, travelDirection.field_1350 * nextSpeed);
    }

    private static boolean nextTrainChunkLoaded(class_3218 level, LocomotiveEntity locomotive) {
        class_243 velocity = locomotive.method_18798();
        double horizontal = Math.sqrt(velocity.method_37268());
        class_243 travelDirection = horizontal > 0.001D
                ? new class_243(velocity.field_1352 / horizontal, 0, velocity.field_1350 / horizontal)
                : direction(locomotive);
        double lookAhead = Math.max(1.0D, Math.max(horizontal, targetSpeed(locomotive)) + 0.5D);
        class_243 next = locomotive.method_19538().method_1019(travelDirection.method_1021(lookAhead));
        return level.method_22340(class_2338.method_49638(next));
    }

    private static boolean nextRouteChunkLoaded(class_3218 level, RailMotionCursor cursor) {
        if (cursor == null) return true;
        return level.method_22340(cursor.currentRail()) && level.method_22340(cursor.nextRail());
    }

    public static void noteInteraction(LinkedTrainCar car) {
        PausedTrain paused = PAUSED.get(car.trainLink().locomotiveId());
        if (paused != null) PAUSED.put(car.trainLink().locomotiveId(), new PausedTrain(
                ticks + AutoResumeTimer.DEFAULT_DELAY_TICKS, paused.resumeVelocity()));
    }

    public static void resetFormation(UUID trainId, List<class_1297> cars) {
        TRAILS.remove(trainId);
        LOGICAL_MOTIONS.remove(trainId);
        ROUTES.remove(trainId);
        cars.stream().filter(LocomotiveEntity.class::isInstance).findFirst().ifPresent(locomotive -> {
            MANUAL.remove(locomotive.method_5667());
            PAUSED.remove(locomotive.method_5667());
        });
        cars.forEach(car -> {
            car.method_18799(class_243.field_1353);
            if (car instanceof LinkedTrainCar linked) {
                linked.trainLink().setAutomaticRunning(false);
                linked.trainLink().setParked(true);
            }
            if (car instanceof LogicallyControlledVehicle vehicle)
                vehicle.fabricTrain$setLogicallyControlled(cars.stream().anyMatch(LocomotiveEntity.class::isInstance)
                        || cars.size() > 1);
        });
        TrackTrail trail = new TrackTrail(140.0D);
        cars.stream()
                .sorted(Comparator.comparingInt(entity ->
                        ((LinkedTrainCar) entity).trainLink().carIndex()).reversed())
                .forEach(entity -> trail.record(entity.method_23317(), entity.method_23318(), entity.method_23321()));
        TRAILS.put(trainId, trail);
    }

    public static void detachLine(MinecraftServer server, long lineId) {
        for (class_3218 level : server.method_3738()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            for (class_1297 entity : level.method_27909()) {
                if (!(entity instanceof LinkedTrainCar linked) || linked.trainLink().lineId() != lineId) continue;
                UUID trainId = linked.trainLink().trainId();
                releaseTrainSwitches(trainId);
                PAUSED.remove(linked.trainLink().locomotiveId());
                linked.trainLink().detachFromLine();
                data.unregisterActiveTrain(trainId);
            }
        }
    }

    public static void handleDeletedLine(MinecraftServer server, long lineId, long recoveryDepotId) {
        for (class_3218 level : server.method_3738()) {
            RailwaySavedData data = RailwayDataManager.state(level);
            Map<UUID, List<class_1297>> trains = new HashMap<>();
            for (class_1297 entity : level.method_27909()) {
                if (entity instanceof LinkedTrainCar linked && linked.trainLink().lineId() == lineId
                        && linked.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC) {
                    trains.computeIfAbsent(linked.trainLink().trainId(), ignored -> new ArrayList<>()).add(entity);
                }
            }
            RailwayDevice recovery = data.device(recoveryDepotId);
            for (Map.Entry<UUID, List<class_1297>> entry : trains.entrySet()) {
                boolean recovered = false;
                if (recovery != null && recovery.dimension().equals(RailwayDataManager.dimension(level))) {
                    class_2338 pos = new class_2338(recovery.x(), recovery.y(), recovery.z());
                    if (level.method_22340(pos) && level.method_8321(pos) instanceof TrainDepotBlockEntity depot)
                        recovered = DepotRecoveryService.recover(entry.getValue(), depot);
                }
                if (!recovered) entry.getValue().forEach(entity -> {
                    entity.method_18799(class_243.field_1353);
                    if (entity instanceof LinkedTrainCar linked) linked.trainLink().setAutomaticRunning(false);
                });
                releaseTrainSwitches(entry.getKey());
                data.unregisterActiveTrain(entry.getKey());
            }
        }
    }

    private static boolean prepareNextSwitch(class_3218 level, LocomotiveEntity locomotive, List<class_1297> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(locomotive.trainLink().lineId());
        if (line == null || line.nodeIds().isEmpty()) return true;
        RouteProgress progress = routeProgress(locomotive);
        int nextIndex = Math.min(progress.nextNodeIndex, line.nodeIds().size() - 1);
        RailwayDevice next = data.device(line.nodeIds().get(nextIndex));
        if (next == null || next.type() != DeviceType.SWITCH
                || !next.dimension().equals(RailwayDataManager.dimension(level))) return true;
        class_2338 pos = new class_2338(next.x(), next.y(), next.z());
        UUID trainId = locomotive.trainLink().trainId();
        double reservation = RealtimeSwitchTraffic.reservationDistance(currentLogicalSpeed(trainId));
        if (locomotive.method_5707(class_243.method_24953(pos)) > reservation * reservation) return true;
        if (!hasSwitchRight(level, next.id(), trainId)) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            notifyDiagnostic(level, trainId, "waiting_switch", currentLogicalSpeed(trainId),
                    locomotive.method_24515());
            return false;
        }
        if (level.method_22340(pos) && level.method_8320(pos).method_28498(class_2443.field_11369)) {
            LogicalMotion motion = LOGICAL_MOTIONS.get(trainId);
            var shape = motion == null || motion.cursor == null
                    ? Optional.<class_2768>empty() : motion.cursor.routeShapeAt(pos);
            if (shape.isEmpty() || !shapeConnected(level, pos, shape.get())) {
                cars.forEach(car -> car.method_18799(class_243.field_1353));
                return false;
            }
        }
        return true;
    }

    private static net.minecraft.class_2350 travelDirection(LocomotiveEntity locomotive) {
        return travelDirection(locomotive,false);
    }

    private static net.minecraft.class_2350 travelDirection(LocomotiveEntity locomotive,boolean reverse) {
        LogicalMotion motion=LOGICAL_MOTIONS.get(locomotive.trainLink().trainId());
        if(motion!=null&&motion.cursor!=null){
            var cursorDirection=motion.cursor.travelDirection(!reverse);
            if(cursorDirection.isPresent())return cursorDirection.get();
        }
        class_243 movement = direction(locomotive);
        if(reverse)movement=movement.method_1021(-1);
        return Math.abs(movement.field_1352) >= Math.abs(movement.field_1350)
                ? (movement.field_1352 >= 0 ? net.minecraft.class_2350.field_11034 : net.minecraft.class_2350.field_11039)
                : (movement.field_1350 >= 0 ? net.minecraft.class_2350.field_11035 : net.minecraft.class_2350.field_11043);
    }

    private static boolean prepareManualSwitch(class_3218 level, LocomotiveEntity locomotive, List<class_1297> cars) {
        LogicalMotion motion=LOGICAL_MOTIONS.get(locomotive.trainLink().trainId());
        ManualInput input=MANUAL.get(locomotive.method_5667());
        boolean reverse=motion!=null&&motion.speed.speed()<-0.0001D
                ||(motion!=null&&Math.abs(motion.speed.speed())<0.0001D&&input!=null&&input.backward());
        net.minecraft.class_2350 travel = travelDirection(locomotive,reverse);
        class_2338 railPos = locomotive.method_62825();
        RailwaySavedData data = RailwayDataManager.state(level);
        UUID trainId = locomotive.trainLink().trainId();
        for (int distance = 0; distance <= 2; distance++) {
            class_2338 pos = switchAt(level,railPos.method_10079(travel, distance));
            if (pos==null) continue;
            RailwayDevice device = data.find(RailwayDataManager.dimension(level), pos.method_10263(), pos.method_10264(), pos.method_10260());
            if (device != null) {
                if (!hasSwitchRight(level, device.id(), trainId)) {
                    notifyDiagnostic(level, trainId, "waiting_switch", currentLogicalSpeed(trainId),
                            locomotive.method_24515());
                    return false;
                }
                var state = level.method_8320(pos);
                var shape = SwitchRailRouting.shapeForFixedChoice(
                        SwitchRailRouting.entryFor(device,state),
                        travel, device.switchShapeOrdinal());
                if (shape.isEmpty() || !shapeConnected(level, pos, shape.get())) {
                    return false;
                }
                level.method_8652(pos, state.method_11657(class_2443.field_11369, shape.get()), 3);
            }
            return true;
        }
        return true;
    }

    private static void releaseTrainSwitches(UUID trainId) {
        REALTIME_SWITCH_RIGHTS.entrySet().removeIf(entry -> entry.getValue().equals(trainId));
        RouteProgress progress = ROUTES.get(trainId);
        if (progress != null) progress.lockedSwitchId = 0L;
    }

    private static void escrowUnloadedDestinations(class_3218 level, LocomotiveEntity locomotive, List<class_1297> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        for (class_1297 entity : cars) {
            if (!(entity instanceof CargoCarEntity cargo) || cargo.method_5442()) continue;
            long destinationStationId = CargoUnloadRules.effectiveDestination(cargo.destinationStationId(),
                    locomotive.trainLink().destinationStationId());
            if (destinationStationId <= 0L) continue;
            RailwayDevice station = data.device(destinationStationId);
            if (station == null || !station.dimension().equals(RailwayDataManager.dimension(level))) continue;
            class_2338 destination = new class_2338(station.x(), station.y(), station.z());
            if (level.method_22340(destination)) continue;
            double blocksPerTick = Math.max(0.001D, targetSpeed(locomotive));
            long travelTicks = Math.max(20L, (long) Math.ceil(Math.sqrt(locomotive.method_5707(class_243.method_24953(destination))) / blocksPerTick));
            CargoLedgerService.escrow(level, cargo, station.id(), level.method_8510() + travelTicks);
        }
    }

    private static double targetSpeed(LocomotiveEntity locomotive) {
        double lineLimit = Double.MAX_VALUE;
        if (locomotive.method_37908() instanceof class_3218 level) {
            RailwayLine line = RailwayDataManager.state(level).line(locomotive.trainLink().lineId());
            if (line != null) lineLimit = line.speedLimitKmh();
        }
        double classLimit = locomotive.method_37908() instanceof class_3218 level
                ? RailwayDataManager.state(level).classSpeedLimit(locomotive.trainLink().trainClass())
                : SpeedRules.classLimit(locomotive.trainLink().trainClass());
        return SpeedRules.blocksPerTick(SpeedRules.actualSpeed(lineLimit, classLimit,
                locomotive.trainLink().configuredSpeedLimitKmh()));
    }

    private static void enforceSpeedLimit(class_3218 level, LocomotiveEntity locomotive) {
        class_243 velocity = locomotive.method_18798();
        double horizontal = Math.sqrt(velocity.method_37268());
        double maximum = targetSpeed(locomotive);
        if (horizontal > maximum && horizontal > 0) {
            locomotive.method_18800(velocity.field_1352 * maximum / horizontal, velocity.field_1351, velocity.field_1350 * maximum / horizontal);
        }
    }

    private static boolean tryStartupRecovery(class_3218 level, LocomotiveEntity locomotive, List<class_1297> cars) {
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(locomotive.trainLink().lineId());
        if (line == null) {
            locomotive.trainLink().markStartupRecovered();
            return false;
        }
        if (locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC) {
            data.registerActiveTrain(locomotive.trainLink().trainId(), line.id());
            boolean pathRestored = restoreLoadedAutomaticPath(level, locomotive, line, data);
            RailwayLine restoredLine = data.line(line.id());
            boolean resume = StartupAutomaticResumeRules.shouldResume(
                    locomotive.trainLink().controlMode(),
                    restoredLine == null ? line.status() : restoredLine.status(), pathRestored);
            locomotive.trainLink().setAutomaticRunning(resume);
            if (!resume) cars.forEach(car -> car.method_18799(class_243.field_1353));
            if (pathRestored) locomotive.trainLink().markStartupRecovered();
            return true;
        }
        data.registerActiveTrain(locomotive.trainLink().trainId(), line.id());
        RailwayDevice depotDevice = data.device(data.recoveryDepotId(line.id()));
        if (depotDevice == null || !depotDevice.dimension().equals(RailwayDataManager.dimension(level))) return false;
        class_2338 depotPos = new class_2338(depotDevice.x(), depotDevice.y(), depotDevice.z());
        if (!level.method_22340(depotPos)) {
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return true;
        }
        if (level.method_8321(depotPos) instanceof TrainDepotBlockEntity depot) {
            if (DepotRecoveryService.recover(cars, depot)) return true;
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            return true;
        }
        return false;
    }

    private static boolean restoreLoadedAutomaticPath(class_3218 level, LocomotiveEntity locomotive,
                                                       RailwayLine line, RailwaySavedData data) {
        List<TrackPoint> linePath = RuntimePathCache.get(line.id());
        if (linePath.isEmpty()) {
            if (!WorldLineValidator.validate(level, line, data)) return false;
            linePath = RuntimePathCache.get(line.id());
            if (linePath.isEmpty()) return false;
        }
        WorldLineValidator.DispatchAccess access = WorldLineValidator.validateDispatchAccess(level, line, data);
        ArrayList<TrackPoint> complete = new ArrayList<>();
        if (!access.path().isEmpty()) complete.addAll(access.path());
        if (!complete.isEmpty() && complete.getLast().equals(linePath.getFirst())) complete.removeLast();
        int loopStartIndex = complete.size();
        complete.addAll(linePath);
        if (complete.size() < 2) return false;
        boolean loop = LineLoopRules.isLoop(line.nodeIds(), id -> {
            RailwayDevice device = data.device(id);
            return device == null ? null : device.type();
        });
        registerAutomaticPath(locomotive.trainLink().trainId(), complete, loop, loopStartIndex);
        return true;
    }

    private static void processLineNode(class_3218 level, LocomotiveEntity locomotive, List<class_1297> cars) {
        long lineId = locomotive.trainLink().lineId();
        if (lineId <= 0) return;
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayLine line = data.line(lineId);
        if (line == null || line.nodeIds().size() < 2) return;
        class_2338 railPos = locomotive.method_62825();
        RouteProgress progress = routeProgress(locomotive);
        int expectedIndex = Math.min(progress.nextNodeIndex, line.nodeIds().size() - 1);
        RailwayDevice expected = data.device(line.nodeIds().get(expectedIndex));
        RailwayDevice current = null;
        if (expected != null && expected.type() == DeviceType.STATION) {
            StopTrack stop = WorldLineValidator.resolveStationStopTrack(level, line, expectedIndex, expected, data);
            if (stop != null && railPos.method_10263() == stop.x() && railPos.method_10264() == stop.y() && railPos.method_10260() == stop.z())
                current = expected;
        } else {
            current = data.find(RailwayDataManager.dimension(level), railPos.method_10263(), railPos.method_10264(), railPos.method_10260());
            if (current == null) current = data.find(RailwayDataManager.dimension(level), railPos.method_10263(), railPos.method_10264() - 1, railPos.method_10260());
        }
        if (current == null) {
            progress.lastDeviceId = 0;
            syncRouteProgress(locomotive, progress);
            return;
        }
        final RailwayDevice currentNode = current;
        if (current.id() == progress.lastDeviceId) return;
        if (line.nodeIds().get(expectedIndex) != current.id()) return;
        progress.lastDeviceId = current.id();
        if (current.type() == DeviceType.STATION) {
            class_243 velocity = locomotive.method_18798();
            if (velocity.method_37268() < 0.0001D) velocity = direction(locomotive).method_1021(targetSpeed(locomotive));
            StopTrack stop = WorldLineValidator.resolveStationStopTrack(level, line, expectedIndex, current, data);
            if (stop != null) hardStopAtStation(locomotive, cars, stop);
            else cars.forEach(car -> car.method_18799(class_243.field_1353));
            locomotive.trainLink().setAutomaticRunning(false);
            if (locomotive.trainLink().controlMode() == ControlMode.ROUTE_AUTOMATIC) {
                int dwell = StationDwellRules.automaticSeconds(current, locomotive.trainLink().trainClass());
                PAUSED.put(locomotive.method_5667(), new PausedTrain(
                        EMERGENCY_STATIONS.contains(current.id()) ? ticks + 2 : ticks + (long) dwell * 20L, velocity));
            } else {
                PAUSED.remove(locomotive.method_5667());
            }
            broadcastStationAnnouncement(level, currentNode);
            cars.stream().filter(CargoCarEntity.class::isInstance).map(CargoCarEntity.class::cast)
                    .filter(cargo -> CargoUnloadRules.shouldUnloadAt(currentNode.id(), cargo.destinationStationId(),
                            locomotive.trainLink().destinationStationId()))
                    .forEach(cargo -> {
                        CargoTransferService.unloadAtStation(level,
                                new class_2338(currentNode.x(), currentNode.y(), currentNode.z()), cargo);
                    });
            progress.nextNodeIndex++;
        } else if (current.type() == DeviceType.SWITCH) {
            if (hasSwitchRight(level, current.id(), locomotive.trainLink().trainId())) {
                progress.lockedSwitchId = 0L;
                progress.nextNodeIndex++;
            } else {
                cars.forEach(car -> car.method_18799(class_243.field_1353));
                notifyDiagnostic(level, locomotive.trainLink().trainId(), "waiting_switch",
                        currentLogicalSpeed(locomotive.trainLink().trainId()), locomotive.method_24515());
            }
        } else if (current.type() == DeviceType.DEPOT && expectedIndex == line.nodeIds().size() - 1) {
            class_2338 depotPos = new class_2338(current.x(), current.y(), current.z());
            if (level.method_8321(depotPos) instanceof TrainDepotBlockEntity depot
                    && DepotRecoveryService.recover(cars, depot)) {
                releaseTrainSwitches(locomotive.trainLink().trainId());
                return;
            }
            cars.forEach(car -> car.method_18799(class_243.field_1353));
            locomotive.trainLink().setAutomaticRunning(false);
        } else {
            progress.nextNodeIndex++;
        }
        if (progress.nextNodeIndex >= line.nodeIds().size()) {
            progress.nextNodeIndex = isLoop(line, data) ? 1 : line.nodeIds().size() - 1;
        }
        syncRouteProgress(locomotive, progress);
    }

    private static void processManualStationAnnouncement(class_3218 level, LocomotiveEntity locomotive) {
        class_2338 railPos = locomotive.method_62825();
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayDevice current = data.find(RailwayDataManager.dimension(level),
                railPos.method_10263(), railPos.method_10264(), railPos.method_10260());
        if (current == null) current = data.find(RailwayDataManager.dimension(level),
                railPos.method_10263(), railPos.method_10264() - 1, railPos.method_10260());
        RouteProgress progress = routeProgress(locomotive);
        if (current == null || current.type() != DeviceType.STATION) {
            if (progress.lastDeviceId != 0L) {
                progress.lastDeviceId = 0L;
                syncRouteProgress(locomotive, progress);
            }
            return;
        }
        if (current.id() == progress.lastDeviceId) return;
        progress.lastDeviceId = current.id();
        syncRouteProgress(locomotive, progress);
        broadcastStationAnnouncement(level, current);
    }

    private static void broadcastStationAnnouncement(class_3218 level, RailwayDevice station) {
        if (station.announcement().isBlank()) return;
        level.method_18456().stream()
                .filter(player -> player.method_5649(station.x() + .5, station.y() + .5,
                        station.z() + .5) <= 1024)
                .forEach(player -> player.method_7353(class_2561.method_43470(station.announcement()), true));
    }

    private static void hardStopAtStation(LocomotiveEntity locomotive, List<class_1297> cars, StopTrack stop) {
        StationStopAlignment.Position aligned = StationStopAlignment.position(stop);
        class_2338 stopPos = new class_2338(stop.x(), stop.y(), stop.z());
        LogicalMotion motion = LOGICAL_MOTIONS.computeIfAbsent(locomotive.trainLink().trainId(),
                ignored -> new LogicalMotion());
        motion.speed.stop();
        if (motion.cursor != null) motion.cursor.snapTo(stopPos);
        locomotive.method_5814(aligned.x(), aligned.y(), aligned.z());
        cars.forEach(car -> car.method_18799(class_243.field_1353));
        TRAILS.computeIfAbsent(locomotive.trainLink().trainId(), ignored -> new TrackTrail(140.0D))
                .record(aligned.x(), aligned.y(), aligned.z());
    }

    private static RouteProgress routeProgress(LocomotiveEntity locomotive) {
        return ROUTES.computeIfAbsent(locomotive.trainLink().trainId(), ignored -> new RouteProgress(
                locomotive.trainLink().nextNodeIndex(), locomotive.trainLink().lastDeviceId(), locomotive.trainLink().lockedSwitchId()));
    }

    private static void syncRouteProgress(LocomotiveEntity locomotive, RouteProgress progress) {
        locomotive.trainLink().updateRouteProgress(progress.nextNodeIndex, progress.lastDeviceId, progress.lockedSwitchId);
    }

    private static boolean isLoop(RailwayLine line, RailwaySavedData data) {
        return cn.quit5700.fabrictrain.route.LineLoopRules.isLoop(line.nodeIds(), id -> {
            RailwayDevice device = data.device(id);
            return device == null ? null : device.type();
        });
    }

    private static boolean shapeConnected(class_3218 level, class_2338 pos, class_2768 shape) {
        var exits = class_1688.method_22864(shape);
        return hasRailAtAnyHeight(level,pos.method_10081(exits.getFirst()))
                && hasRailAtAnyHeight(level,pos.method_10081(exits.getSecond()));
    }

    private static boolean hasRailAtAnyHeight(class_3218 level,class_2338 pos){
        return RailHeightOffsets.candidates(pos).stream().anyMatch(candidate->class_2241.method_9479(level,candidate));
    }

    private static class_2338 switchAt(class_3218 level,class_2338 pos){
        return RailHeightOffsets.candidates(pos).stream().filter(candidate->level.method_8320(candidate).method_27852(ModBlocks.SWITCH_RAIL))
                .findFirst().orElse(null);
    }

    private static void follow(class_3218 level, LocomotiveEntity locomotive, class_1297 entity, TrackTrail trail) {
        int index = ((LinkedTrainCar) entity).trainLink().carIndex();
        if (index <= 0) return;
        TrackTrail.Point target = trail.pointBehind(index * CAR_SPACING);
        if (target == null) {
            entity.method_18799(class_243.field_1353);
            return;
        }
        class_2338 targetPos = class_2338.method_49637(target.x(), target.y(), target.z());
        if (!level.method_22340(targetPos)) {
            entity.method_18799(class_243.field_1353);
            return;
        }
        entity.method_5814(target.x(), target.y(), target.z());
        TrackTrail.Point ahead = trail.pointBehind(Math.max(0, index * CAR_SPACING - 0.2D));
        if (ahead != null) {
            double dx = ahead.x() - target.x();
            double dz = ahead.z() - target.z();
            if (dx * dx + dz * dz > 0.000001D)
                entity.method_36456((float) Math.toDegrees(Math.atan2(-dx, dz)));
        }
        entity.method_18799(class_243.field_1353);
    }

    public static void clear() {
        TRAILS.clear();
        PAUSED.clear();
        ROUTES.clear();
        REALTIME_SWITCH_RIGHTS.clear();
        EMERGENCY_STATIONS.clear();
        MANUAL.clear();
        LOGICAL_MOTIONS.clear();
        AUTOMATIC_PATHS.clear();
        CAR_ONLY_INPUT.clear();
        DIAGNOSTIC_DRIVERS.clear();
        LAST_DIAGNOSTIC_REASON.clear();
        OFFLINE_REMOVALS.clear();
        RuntimePathCache.clear();
        PENDING_DESTROYED_TRAINS.clear();
        ticks = 0;
    }

    private static class_1297 findEntity(MinecraftServer server, UUID entityId) {
        if (server == null || entityId == null) return null;
        for (class_3218 level : server.method_3738()) {
            class_1297 entity = level.method_66347(entityId);
            if (entity != null) return entity;
        }
        return null;
    }

    private record PausedTrain(long resumeAtTick, class_243 resumeVelocity) {}
    private record ManualInput(boolean forward,boolean backward,long changedAt){}
    private record SwitchTrafficKey(String dimension, long deviceId) {}
    private record AutomaticPath(List<cn.quit5700.fabrictrain.route.TrackPoint> points, boolean loop,
                                 int loopStartIndex, int linePathStartIndex) {}
    private static final class LogicalMotion {
        private final LogicalSpeedState speed = new LogicalSpeedState();
        private RailMotionCursor cursor;
    }
    private static final class RouteProgress {
        private int nextNodeIndex;
        private long lastDeviceId;
        private long lockedSwitchId;
        private RouteProgress(int nextNodeIndex, long lastDeviceId, long lockedSwitchId) {
            this.nextNodeIndex = Math.max(1, nextNodeIndex);
            this.lastDeviceId = lastDeviceId;
            this.lockedSwitchId = lockedSwitchId;
        }
    }
}
