package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import java.util.*;
import net.minecraft.class_10741;
import net.minecraft.class_18;

public final class OfflineTrainSavedData extends class_18 {
    public static final Codec<OfflineTrainSavedData> CODEC = OfflineTrainState.CODEC.listOf()
            .optionalFieldOf("trains", List.of()).codec()
            .xmap(OfflineTrainSavedData::new, data -> List.copyOf(data.trains.values()));
    public static final class_10741<OfflineTrainSavedData> TYPE = new class_10741<>(
            FabricTrainMod.MOD_ID + "_offline_trains", OfflineTrainSavedData::new, CODEC, null);

    private final Map<UUID, OfflineTrainState> trains = new LinkedHashMap<>();
    public OfflineTrainSavedData() {}
    private OfflineTrainSavedData(List<OfflineTrainState> values) {
        values.forEach(value -> trains.put(value.trainId(), value));
    }
    public synchronized void put(OfflineTrainState state) { trains.put(state.trainId(), state); method_80(); }
    public synchronized void remove(UUID trainId) { if (trains.remove(trainId) != null) method_80(); }
    public synchronized List<OfflineTrainState> trains() { return List.copyOf(trains.values()); }
    public synchronized OfflineTrainState get(UUID trainId) { return trains.get(trainId); }
}
