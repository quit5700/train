package cn.quit5700.fabrictrain.train;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2350;

public final class TrainLink {
    private UUID trainId;
    private UUID locomotiveId;
    private int carIndex;
    private long lineId;
    private TrainClass trainClass = TrainClass.PASSENGER;
    private boolean loadedFromSave;
    private UUID savedSessionId = TrainSession.current();
    private int nextNodeIndex = 1;
    private long lastDeviceId;
    private long lockedSwitchId;
    private boolean automaticRunning;
    private long destinationStationId;
    private boolean parked=true;
    private boolean locomotivePresent;
    private boolean depotGenerated;
    private ControlMode controlMode = ControlMode.MANUAL;
    private double configuredSpeedLimitKmh;
    private int formationForwardOrdinal = -1;
    private long originDepotNumber;
    private long registryTrainNumber;
    private int vehicleNumber = 1;

    public TrainLink() {
        UUID standalone = UUID.randomUUID();
        trainId = standalone;
        locomotiveId = standalone;
    }

    public void assign(UUID trainId, UUID locomotiveId, int carIndex) {
        assign(trainId, locomotiveId, carIndex, lineId);
    }

    public void assign(UUID trainId, UUID locomotiveId, int carIndex, long lineId) {
        if (carIndex < 0) throw new IllegalArgumentException("Car index cannot be negative");
        if (lineId < 0) throw new IllegalArgumentException("Line id cannot be negative");
        this.trainId = trainId;
        this.locomotiveId = locomotiveId;
        this.carIndex = carIndex;
        this.lineId = lineId;
        this.locomotivePresent = true;
    }

    public void assignWithoutLocomotive(UUID trainId, int carIndex) {
        if (carIndex < 0) throw new IllegalArgumentException("Car index cannot be negative");
        this.trainId = trainId;
        this.locomotiveId = new UUID(0L, 0L);
        this.carIndex = carIndex;
        this.lineId = 0L;
        this.locomotivePresent = false;
        this.automaticRunning = false;
        this.formationForwardOrdinal = -1;
    }

    public UUID trainId() { return trainId; }
    public UUID locomotiveId() { return locomotiveId; }
    public int carIndex() { return carIndex; }
    public long originDepotNumber() { return originDepotNumber; }
    public long registryTrainNumber() { return registryTrainNumber; }
    public int vehicleNumber() { return vehicleNumber; }
    public void setRegistryAddress(long depotNumber, long trainNumber, int vehicleNumber) {
        this.originDepotNumber = Math.max(0L, depotNumber);
        this.registryTrainNumber = Math.max(0L, trainNumber);
        this.vehicleNumber = Math.max(1, vehicleNumber);
    }
    public long lineId() { return lineId; }
    public void detachFromLine() {
        lineId = 0L;
        automaticRunning = false;
        nextNodeIndex = 1;
        lastDeviceId = 0L;
        lockedSwitchId = 0L;
    }
    public TrainClass trainClass() { return trainClass; }
    public void setTrainClass(TrainClass requested) { trainClass = requested == null ? TrainClass.PASSENGER : requested; }
    public boolean loadedFromSave() { return loadedFromSave; }
    public void markStartupRecovered() { loadedFromSave = false; }
    public int nextNodeIndex() { return nextNodeIndex; }
    public long lastDeviceId() { return lastDeviceId; }
    public long lockedSwitchId() { return lockedSwitchId; }
    public void updateRouteProgress(int nextNodeIndex, long lastDeviceId, long lockedSwitchId) {
        this.nextNodeIndex = Math.max(1, nextNodeIndex);
        this.lastDeviceId = Math.max(0L, lastDeviceId);
        this.lockedSwitchId = Math.max(0L, lockedSwitchId);
    }
    public boolean automaticRunning() { return automaticRunning; }
    public void setAutomaticRunning(boolean value) { automaticRunning = value;if(value)parked=false; }
    public boolean parked(){return parked;}
    public void setParked(boolean value){parked=value;if(value)automaticRunning=false;}
    public boolean hasLocomotive(){return locomotivePresent;}
    public boolean depotGenerated(){return depotGenerated;}
    public void setDepotGenerated(boolean value){depotGenerated=value;}
    public ControlMode controlMode(){return controlMode;}
    public void setControlMode(ControlMode value){controlMode=value==null?ControlMode.MANUAL:value;}
    public double configuredSpeedLimitKmh(){return configuredSpeedLimitKmh;}
    public void setConfiguredSpeedLimitKmh(double value){configuredSpeedLimitKmh=Double.isFinite(value)&&value>0?value:0D;}
    public Optional<class_2350> formationForward(){
        if(formationForwardOrdinal<0||formationForwardOrdinal>=class_2350.values().length)return Optional.empty();
        class_2350 direction=class_2350.values()[formationForwardOrdinal];
        return direction.method_10166()==class_2350.class_2351.field_11052?Optional.empty():Optional.of(direction);
    }
    public void setFormationForward(class_2350 direction){
        formationForwardOrdinal=direction==null||direction.method_10166()==class_2350.class_2351.field_11052?-1:direction.ordinal();
    }
    public void clearFormationForward(){formationForwardOrdinal=-1;}
    public boolean standalone(){return !locomotivePresent&&carIndex==0;}
    public long destinationStationId(){return destinationStationId;}
    public void setDestinationStationId(long value){destinationStationId=Math.max(0,value);}
    public void detach(UUID entityId){trainId=entityId;locomotiveId=new UUID(0L,0L);carIndex=0;lineId=0;locomotivePresent=false;automaticRunning=false;nextNodeIndex=1;lastDeviceId=0;lockedSwitchId=0;destinationStationId=0;formationForwardOrdinal=-1;originDepotNumber=0L;registryTrainNumber=0L;vehicleNumber=1;}

    public void load(class_11368 input) {
        trainId = parse(input.method_71428("TrainId", trainId.toString()), trainId);
        locomotiveId = parse(input.method_71428("LocomotiveId", locomotiveId.toString()), locomotiveId);
        carIndex = Math.max(0, input.method_71424("CarIndex", 0));
        lineId = Math.max(0L, input.method_71425("LineId", 0L));
        try { trainClass = TrainClass.valueOf(input.method_71428("TrainClass", TrainClass.PASSENGER.name())); }
        catch (IllegalArgumentException ignored) { trainClass = TrainClass.PASSENGER; }
        savedSessionId = parse(input.method_71428("ServerSessionId", new UUID(0L, 0L).toString()), new UUID(0L, 0L));
        loadedFromSave = !savedSessionId.equals(TrainSession.current());
        nextNodeIndex = Math.max(1, input.method_71424("NextNodeIndex", 1));
        lastDeviceId = Math.max(0L, input.method_71425("LastDeviceId", 0L));
        lockedSwitchId = Math.max(0L, input.method_71425("LockedSwitchId", 0L));
        automaticRunning = input.method_71433("AutomaticRunning", false);
        destinationStationId=Math.max(0,input.method_71425("DestinationStationId",0L));
        parked=input.method_71433("Parked",false);
        locomotivePresent=input.method_71433("LocomotivePresent", !locomotiveId.equals(new UUID(0L,0L)));
        depotGenerated=input.method_71433("DepotGenerated",false);
        try { controlMode=ControlMode.valueOf(input.method_71428("ControlMode",
                depotGenerated&&lineId>0?ControlMode.ROUTE_AUTOMATIC.name():ControlMode.MANUAL.name())); }
        catch(IllegalArgumentException ignored){controlMode=depotGenerated&&lineId>0?ControlMode.ROUTE_AUTOMATIC:ControlMode.MANUAL;}
        setConfiguredSpeedLimitKmh(input.method_71422("ConfiguredSpeedLimitKmh",0D));
        formationForwardOrdinal=input.method_71424("FormationForwardOrdinal",-1);
        originDepotNumber=Math.max(0L,input.method_71425("OriginDepotNumber",0L));
        registryTrainNumber=Math.max(0L,input.method_71425("RegistryTrainNumber",0L));
        vehicleNumber=Math.max(1,input.method_71424("VehicleNumber",carIndex+1));
        if(formationForward().isEmpty())formationForwardOrdinal=-1;
    }

    public void save(class_11372 output) {
        output.method_71469("TrainId", trainId.toString());
        output.method_71469("LocomotiveId", locomotiveId.toString());
        output.method_71465("CarIndex", carIndex);
        output.method_71466("LineId", lineId);
        output.method_71469("TrainClass", trainClass.name());
        output.method_71469("ServerSessionId", TrainSession.current().toString());
        output.method_71465("NextNodeIndex", nextNodeIndex);
        output.method_71466("LastDeviceId", lastDeviceId);
        output.method_71466("LockedSwitchId", lockedSwitchId);
        output.method_71472("AutomaticRunning", automaticRunning);
        output.method_71466("DestinationStationId",destinationStationId);
        output.method_71472("Parked",parked);
        output.method_71472("LocomotivePresent",locomotivePresent);
        output.method_71472("DepotGenerated",depotGenerated);
        output.method_71469("ControlMode",controlMode.name());
        output.method_71463("ConfiguredSpeedLimitKmh",configuredSpeedLimitKmh);
        output.method_71465("FormationForwardOrdinal",formationForwardOrdinal);
        output.method_71466("OriginDepotNumber",originDepotNumber);
        output.method_71466("RegistryTrainNumber",registryTrainNumber);
        output.method_71465("VehicleNumber",vehicleNumber);
    }

    private static UUID parse(String value, UUID fallback) {
        try { return UUID.fromString(value); } catch (IllegalArgumentException ignored) { return fallback; }
    }
}
