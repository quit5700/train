package cn.quit5700.fabrictrain.route;

import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.data.RailwayLine;
import cn.quit5700.fabrictrain.data.RailwaySavedData;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Reconciles legacy switch records before any route calculation uses them. */
public final class SwitchEntryStateSynchronizer {
    private SwitchEntryStateSynchronizer() { }

    public static RailwayDevice synchronizeDevice(class_3218 level, RailwaySavedData data, RailwayDevice device) {
        if (device == null || device.type() != DeviceType.SWITCH
                || !device.dimension().equals(RailwayDataManager.dimension(level))) return device;
        class_2680 state = level.method_8320(new class_2338(device.x(), device.y(), device.z()));
        if (!state.method_27852(ModBlocks.SWITCH_RAIL) || !state.method_28498(DeviceRailBlock.PLACEMENT_ENTRY)) return device;
        class_2350 entry = SwitchRailRouting.entryFor(device, state);
        return device.switchEntryOrdinal() == entry.ordinal()
                ? device : data.updateSwitchEntry(device.id(), entry.ordinal());
    }

    public static void synchronizeLine(class_3218 level, RailwaySavedData data, RailwayLine line) {
        if (line == null) return;
        for (long deviceId : line.nodeIds()) synchronizeDevice(level, data, data.device(deviceId));
    }
}
