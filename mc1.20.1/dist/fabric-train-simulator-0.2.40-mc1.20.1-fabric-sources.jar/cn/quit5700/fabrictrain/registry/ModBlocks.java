package cn.quit5700.fabrictrain.registry;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.SignalRailBlock;
import cn.quit5700.fabrictrain.block.DeviceBlock;
import cn.quit5700.fabrictrain.block.DeviceRailBlock;
import cn.quit5700.fabrictrain.data.DeviceType;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import cn.quit5700.fabrictrain.block.TrainDepotBlock;
import cn.quit5700.fabrictrain.block.PowerGeneratorBlock;

public final class ModBlocks {
    public static final class_2248 SIGNAL_RAIL = registerRail("signal_rail", class_2246.field_10167);
    public static final class_2248 SWITCH_RAIL = registerDeviceRail("switch_rail", class_2246.field_10167, DeviceType.SWITCH);
    public static final class_2248 TRAIN_DEPOT = registerDepot("train_depot", class_2246.field_9980);
    public static final class_2248 STATION_MARKER = registerDevice("station_marker", class_2246.field_10085, DeviceType.STATION);
    public static final class_2248 POWER_GENERATOR = registerGenerator("power_generator", class_2246.field_10002);
    public static final class_2248 LOCOMOTIVE_DISPLAY = register("locomotive_display", class_2246.field_10340);
    public static final class_2248 PASSENGER_DISPLAY = register("passenger_display", class_2246.field_10340);
    public static final class_2248 CARGO_DISPLAY = register("cargo_display", class_2246.field_10340);

    private ModBlocks() {
    }

    private static class_2248 register(String path, class_2248 copiedBlock) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new class_2248(class_4970.class_2251.method_9630(copiedBlock));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    private static class_2248 registerRail(String path, class_2248 copiedBlock) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new SignalRailBlock(class_4970.class_2251.method_9630(copiedBlock));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    private static class_2248 registerDevice(String path, class_2248 copiedBlock, DeviceType type) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new DeviceBlock(class_4970.class_2251.method_9630(copiedBlock), type);
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    private static class_2248 registerDepot(String path, class_2248 copiedBlock) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new TrainDepotBlock(class_4970.class_2251.method_9630(copiedBlock));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    private static class_2248 registerGenerator(String path, class_2248 copiedBlock) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new PowerGeneratorBlock(class_4970.class_2251.method_9630(copiedBlock));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    private static class_2248 registerDeviceRail(String path, class_2248 copiedBlock, DeviceType type) {
        class_2960 id = FabricTrainMod.id(path);
        class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, id);
        class_2248 block = new DeviceRailBlock(class_4970.class_2251.method_9630(copiedBlock), type);
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    public static void initialize() {
    }
}

