package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.entity.CargoCarEntity;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import cn.quit5700.fabrictrain.cargo.StationSelectionService;
import cn.quit5700.fabrictrain.data.RailwaySavedData;

public final class TrainClassNetworking {
    private TrainClassNetworking() {}

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) -> context.server().execute(() -> {
            class_1297 entity = context.player().method_51469().method_8469(payload.entityId());
            if (!(entity instanceof LocomotiveEntity locomotive) || context.player().method_5858(entity) > 64.0D) return;
            boolean hasCargo = hasCargo(context.player().method_51469().method_27909(), locomotive);
            TrainClass requested = TrainClass.values()[cn.quit5700.fabrictrain.compat.MathCompat.clamp(payload.trainClassOrdinal(), 0, TrainClass.values().length - 1)];
            TrainClass selected = hasCargo ? TrainClass.CARGO : requested;
            long destination=payload.destinationStationId();
            var data=cn.quit5700.fabrictrain.data.RailwayDataManager.state(context.player().method_51469());
            if(!StationSelectionService.canSelect(data,locomotive.trainLink(),destination))destination=0;
            boolean destinationChanged = locomotive.trainLink().destinationStationId() != destination;
            locomotive.trainLink().setDestinationStationId(destination);
            data.updateClassSpeedLimits(
                    payload.freightSpeedKmh(), payload.passengerSpeedKmh(), payload.expressSpeedKmh());
            for (class_1297 candidate : context.player().method_51469().method_27909()) {
                if (candidate instanceof LinkedTrainCar linked
                        && linked.trainLink().trainId().equals(locomotive.trainLink().trainId())) {
                    linked.trainLink().setTrainClass(selected);
                    linked.trainLink().setDestinationStationId(destination);
                    linked.trainLink().setConfiguredSpeedLimitKmh(data.classSpeedLimit(selected));
                    if(destinationChanged && linked instanceof CargoCarEntity cargo) cargo.setDestinationStationId(0L);
                }
            }
        }));
    }

    private static boolean hasCargo(Iterable<class_1297> entities, LocomotiveEntity locomotive) {
        for (class_1297 candidate : entities) {
            if (candidate instanceof CargoCarEntity cargo
                    && cargo.trainLink().trainId().equals(locomotive.trainLink().trainId())) return true;
        }
        return false;
    }

    public record Station(long id,String name){}
    public record OpenPayload(int entityId, int trainClassOrdinal, boolean hasCargo, double freightSpeedKmh,
                              double passengerSpeedKmh, double expressSpeedKmh,long destinationStationId,List<Station> stations) implements LegacyPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_train_class"));
        public static final LegacyPayloadCodec<class_2540, OpenPayload> CODEC = LegacyPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(class_2540 b) { b.method_10804(entityId); b.method_10804(trainClassOrdinal); b.writeBoolean(hasCargo); b.writeDouble(freightSpeedKmh); b.writeDouble(passengerSpeedKmh); b.writeDouble(expressSpeedKmh);b.method_10791(destinationStationId);b.method_10804(stations.size());for(Station s:stations){b.method_10791(s.id());b.method_10788(s.name(),64);} }
        private static OpenPayload read(class_2540 b) {int entity=b.method_10816(),type=b.method_10816();boolean cargo=b.readBoolean();double freight=b.readDouble(),passenger=b.readDouble(),express=b.readDouble();long destination=b.method_10792();int size=cn.quit5700.fabrictrain.compat.MathCompat.clamp(b.method_10816(),0,1000);java.util.ArrayList<Station> stations=new java.util.ArrayList<>();for(int i=0;i<size;i++)stations.add(new Station(b.method_10792(),b.method_10800(64)));return new OpenPayload(entity,type,cargo,freight,passenger,express,destination,List.copyOf(stations)); }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UpdatePayload(int entityId, int trainClassOrdinal, double freightSpeedKmh,
                                double passengerSpeedKmh, double expressSpeedKmh,long destinationStationId) implements LegacyPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_train_class"));
        public static final LegacyPayloadCodec<class_2540, UpdatePayload> CODEC = LegacyPayload.codec(UpdatePayload::write, UpdatePayload::read);
        private void write(class_2540 b) { b.method_10804(entityId); b.method_10804(trainClassOrdinal); b.writeDouble(freightSpeedKmh); b.writeDouble(passengerSpeedKmh); b.writeDouble(expressSpeedKmh);b.method_10791(destinationStationId); }
        private static UpdatePayload read(class_2540 b) { return new UpdatePayload(b.method_10816(), b.method_10816(), b.readDouble(), b.readDouble(), b.readDouble(),b.method_10792()); }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}



