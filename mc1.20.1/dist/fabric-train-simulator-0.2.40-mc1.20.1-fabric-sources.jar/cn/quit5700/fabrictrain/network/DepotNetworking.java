package cn.quit5700.fabrictrain.network;

import cn.quit5700.fabrictrain.FabricTrainMod;
import cn.quit5700.fabrictrain.block.entity.TrainDepotBlockEntity;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import cn.quit5700.fabrictrain.data.RailwayLine;
import cn.quit5700.fabrictrain.data.RailwaySavedData;
import cn.quit5700.fabrictrain.depot.DepotDispatchService;
import cn.quit5700.fabrictrain.depot.DepotDispatchResult;
import cn.quit5700.fabrictrain.depot.DepotTemplate;
import cn.quit5700.fabrictrain.depot.DepotDispatchConfig;
import cn.quit5700.fabrictrain.depot.DepotSettingsAction;
import cn.quit5700.fabrictrain.train.ControlMode;
import cn.quit5700.fabrictrain.depot.DepotDispatchPrecheck;
import cn.quit5700.fabrictrain.route.WorldLineValidator;
import cn.quit5700.fabrictrain.route.RuntimePathCache;
import cn.quit5700.fabrictrain.power.RailPowerService;
import cn.quit5700.fabrictrain.train.TrainClass;
import cn.quit5700.fabrictrain.train.TrainControllerManager;
import cn.quit5700.fabrictrain.data.LineStatus;
import cn.quit5700.fabrictrain.entity.LocomotiveEntity;
import cn.quit5700.fabrictrain.network.LegacyPayloadTypeRegistry;
import cn.quit5700.fabrictrain.network.LegacyServerPlayNetworking;
import cn.quit5700.fabrictrain.network.LegacyPayloadCodec;
import cn.quit5700.fabrictrain.network.LegacyPayload;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class DepotNetworking {
    private DepotNetworking() {}

    public static void registerServer() {
        LegacyPayloadTypeRegistry.playS2C().register(OpenPayload.ID, OpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playS2C().register(TrainListPayload.ID, TrainListPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(RequestOpenPayload.ID,RequestOpenPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(RequestTrainListPayload.ID, RequestTrainListPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(DeleteTrainPayload.ID, DeleteTrainPayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(ClosePayload.ID, ClosePayload.CODEC);
        LegacyPayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        LegacyServerPlayNetworking.registerGlobalReceiver(RequestOpenPayload.ID,(payload,context)->context.server().execute(()->{
            class_3222 player=context.player();class_2338 pos=payload.pos();
            if (!canAccess(player, pos)) { denyAccess(player); return; }
            if(player.method_51469().method_8321(pos) instanceof TrainDepotBlockEntity depot)open(player,pos,depot);
        }));
        LegacyServerPlayNetworking.registerGlobalReceiver(RequestTrainListPayload.ID, (payload, context) ->
                context.server().execute(() -> sendTrainList(context.player(), payload.pos())));
        LegacyServerPlayNetworking.registerGlobalReceiver(DeleteTrainPayload.ID, (payload, context) ->
                context.server().execute(() -> deleteListedTrain(context.player(), payload)));
        LegacyServerPlayNetworking.registerGlobalReceiver(ClosePayload.ID, (payload, context) ->
                context.server().execute(() -> DepotRemoteAccessSessions.revokeAll(context.player().method_5667())));
        LegacyServerPlayNetworking.registerGlobalReceiver(UpdatePayload.ID, (payload, context) ->
                context.server().execute(() -> update(context.player(), payload)));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                DepotRemoteAccessSessions.revokeAll(handler.method_32311().method_5667()));
    }

    private static void sendTrainList(class_3222 player, class_2338 pos) {
        if (!canAccess(player, pos)) { denyAccess(player); return; }
        if (!(player.method_51469().method_8321(pos) instanceof TrainDepotBlockEntity depot)) return;
        RailwaySavedData data = RailwayDataManager.state(player.method_51469());
        long lineId = depot.selectedLineId();
        if (lineId <= 0L || data.line(lineId) == null) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.depot.train_list_no_line"));
            return;
        }
        List<TrainListEntry> trains = data.presentDepotTrainRecords(lineId).values().stream()
                .sorted(java.util.Comparator.comparingLong(record -> record.number()))
                .map(record -> new TrainListEntry(record.trainId(), record.number(),
                        record.controlMode() == ControlMode.ROUTE_AUTOMATIC))
                .toList();
        LegacyServerPlayNetworking.send(player, new TrainListPayload(pos, trains));
    }

    private static void deleteListedTrain(class_3222 player, DeleteTrainPayload payload) {
        if (!canAccess(player, payload.pos())) { denyAccess(player); return; }
        if (!(player.method_51469().method_8321(payload.pos()) instanceof TrainDepotBlockEntity depot)) return;
        RailwaySavedData data = RailwayDataManager.state(player.method_51469());
        long lineId = depot.selectedLineId();
        if (lineId <= 0L || !data.presentDepotTrainRecords(lineId).containsKey(payload.trainId())) {
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(
                    "message.fabric_train_simulator.train_list.delete_unavailable"));
            sendTrainList(player, payload.pos());
            return;
        }
        TrainControllerManager.deleteTrainEverywhere(player.method_51469().method_8503(), payload.trainId());
        cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.train_list.deleted"));
        sendTrainList(player, payload.pos());
    }

    public static void open(class_3222 player, class_2338 pos, TrainDepotBlockEntity depot) {
        open(player, pos, depot, "");
    }

    private static void open(class_3222 player, class_2338 pos, TrainDepotBlockEntity depot,
                             String operationMessageKey) {
        var data = RailwayDataManager.state(player.method_51469());
        List<LineOption> lines = data.lines().values().stream()
                .sorted(java.util.Comparator.comparingLong(RailwayLine::id))
                .map(line -> new LineOption(line.id(), line.name(), line.status().ordinal())).toList();
        long depotId = deviceIdAt(player, pos);
        long selectedLineId = depotId == 0L ? 0L : data.dispatchLineIdForDepot(depotId);
        if (depot.selectedLineId() != selectedLineId) depot.setSelectedLineId(selectedLineId);
        long active = selectedLineId == 0 ? 0 : data.activeTrainCount(selectedLineId);
        RailwayLine selectedLine = data.line(selectedLineId);
        int lineStatus = selectedLine == null ? -1 : selectedLine.status().ordinal();
        int pauseState = pauseState(player, selectedLine, data);
        RailwayDevice depotDevice = data.device(depotId);
        String depotName = depotDevice == null ? "" : depotDevice.name();
        LegacyServerPlayNetworking.send(player, new OpenPayload(pos, depotName, depot.template().encode(), selectedLineId,
                depot.trainClass().ordinal(), depot.dispatchIntervalSeconds(), depot.maximumTrains(),
                active,depot.speedLimitKmh(TrainClass.CARGO),depot.speedLimitKmh(TrainClass.PASSENGER),
                depot.speedLimitKmh(TrainClass.EXPRESS), depot.automaticDispatchEnabled(), lineStatus, pauseState,
                depot.lastAutomaticDispatchResultOrdinal(), operationMessageKey == null ? "" : operationMessageKey, lines));
    }

    private static long deviceIdAt(class_3222 player, class_2338 pos) {
        var device = RailwayDataManager.state(player.method_51469()).find(RailwayDataManager.dimension(player.method_51469()),
                pos.method_10263(), pos.method_10264(), pos.method_10260());
        return device == null ? 0 : device.id();
    }

    private static void update(class_3222 player, UpdatePayload payload) {
        if (!canAccess(player, payload.pos())) { denyAccess(player); return; }
        if (!(player.method_51469().method_8321(payload.pos()) instanceof TrainDepotBlockEntity depot)) return;
        class_3218 level = (class_3218) player.method_51469();
        RailwaySavedData data = RailwayDataManager.state(level);
        RailwayDevice device = RailwayDataManager.register(level, payload.pos(), DeviceType.DEPOT);
        DepotSettingsAction action = DepotSettingsAction.values()[cn.quit5700.fabrictrain.compat.MathCompat.clamp(payload.action(), 0,
                DepotSettingsAction.values().length - 1)];
        DepotTemplate template = DepotTemplate.decode(payload.template());
        TrainClass trainClass = TrainClass.values()[cn.quit5700.fabrictrain.compat.MathCompat.clamp(payload.trainClass(), 0, TrainClass.values().length - 1)];
        DepotDispatchConfig config = new DepotDispatchConfig(template, trainClass, payload.interval(), payload.maximum(),
                payload.cargoSpeedKmh(), payload.passengerSpeedKmh(), payload.expressSpeedKmh());
        if (action == DepotSettingsAction.TOGGLE_PAUSE) {
            RailwayLine line = data.line(payload.lineId());
            String operationKey;
            if (line == null) {
                operationKey = "message.fabric_train_simulator.depot.no_line";
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(operationKey));
            } else if (line.status() == LineStatus.RUNNING) {
                boolean hasStation = line.nodeIds().stream().map(data::device)
                        .anyMatch(candidate -> candidate != null && candidate.type() == DeviceType.STATION);
                if (!hasStation) {
                    cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.depot.pause_no_station"));
                    open(player, payload.pos(), depot,
                            "message.fabric_train_simulator.depot.pause_no_station");
                    return;
                }
                data.setLineStatus(line.id(), LineStatus.PAUSED);
                operationKey = "message.fabric_train_simulator.depot.paused";
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(operationKey));
            } else if (line.status() == LineStatus.PAUSED) {
                data.setLineStatus(line.id(), LineStatus.RUNNING);
                DepotDispatchService.resetAutomaticTimer(line.id());
                TrainControllerManager.continueAutomaticLine(player.method_51469().method_8503(), line.id());
                operationKey = "message.fabric_train_simulator.depot.continued";
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(operationKey));
            } else {
                operationKey = precheckKey(DepotDispatchPrecheck.check(
                        line.status(), data.activeTrainCount(line.id()), payload.maximum()));
                cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(operationKey));
            }
            open(player, payload.pos(), depot, operationKey);
            return;
        }
        if (action != DepotSettingsAction.SAVE) {
            if (!saveSettings(player, payload, depot, data, device, template, trainClass)) return;
            RailwayLine line = data.line(payload.lineId());
            if (action == DepotSettingsAction.DISPATCH_AUTOMATIC) {
                DepotDispatchPrecheck.Result precheck = DepotDispatchPrecheck.check(
                        line == null ? null : line.status(), 0L,
                        payload.maximum());
                if (precheck == DepotDispatchPrecheck.Result.READY
                        || precheck == DepotDispatchPrecheck.Result.NEEDS_VALIDATION) {
                    RailPowerService.refreshNow(level);
                    RuntimePathCache.remove(line.id());
                    WorldLineValidator.ImmediateDispatchResult validation = WorldLineValidator.validateForImmediateDispatchDetailed(
                            level, payload.pos(), line, data);
                    if (validation.status() != WorldLineValidator.ImmediateDispatchStatus.READY) {
                        if (validation.status() == WorldLineValidator.ImmediateDispatchStatus.TRACK_BROKEN
                                && validation.fromIndex() >= 0 && validation.toIndex() < line.nodeIds().size()) {
                            RailwayDevice from = data.device(line.nodeIds().get(validation.fromIndex()));
                            RailwayDevice to = data.device(line.nodeIds().get(validation.toIndex()));
                            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43469(
                                    "message.fabric_train_simulator.depot.track_broken_between",
                                    from == null ? class_2561.method_43471("message.fabric_train_simulator.depot.unknown_node") : from.name(),
                                    to == null ? class_2561.method_43471("message.fabric_train_simulator.depot.unknown_node") : to.name()));
                        } else {
                            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(immediateValidationKey(validation.status())));
                        }
                        open(player, payload.pos(), depot, immediateValidationKey(validation.status()));
                        return;
                    }
                    data.setLineStatus(line.id(), cn.quit5700.fabrictrain.data.LineStatus.RUNNING);
                    line = data.line(line.id());
                    precheck = DepotDispatchPrecheck.Result.READY;
                }
                if (precheck != DepotDispatchPrecheck.Result.READY) {
                    String operationKey = precheckKey(precheck);
                    cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(operationKey));
                    open(player, payload.pos(), depot, operationKey);
                    return;
                }
            }
            ControlMode controlMode = action == DepotSettingsAction.DISPATCH_AUTOMATIC
                    ? ControlMode.ROUTE_AUTOMATIC : ControlMode.MANUAL;
            Set<java.util.UUID> previousAutomaticTrains = action == DepotSettingsAction.DISPATCH_AUTOMATIC
                    ? TrainControllerManager.automaticTrainIds(level, line.id()) : Set.of();
            DepotDispatchService.DispatchOutcome outcome = DepotDispatchService.dispatchConfiguredOutcome(
                    level, payload.pos(), line, depot, config, !player.method_7337(), controlMode);
            DepotDispatchResult result = outcome.result();
            if (result.succeeded() && action == DepotSettingsAction.DISPATCH_AUTOMATIC) {
                TrainControllerManager.refreshAutomaticLine(level, line.id(), outcome.trainId(), previousAutomaticTrains);
                if (depot.selectedLineId() == payload.lineId()) {
                    depot.setAutomaticDispatchEnabled(true);
                    depot.setCreativeAutomaticDispatch(player.method_7337());
                }
                DepotDispatchService.resetAutomaticTimer(payload.lineId());
            }
            if (action == DepotSettingsAction.DISPATCH_AUTOMATIC) depot.setLastAutomaticDispatchResult(result);
            cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471(result.translationKey()));
            open(player, payload.pos(), depot, result.translationKey());
            return;
        }
        if (!saveSettings(player, payload, depot, data, device, template, trainClass)) return;
        open(player, payload.pos(), depot, "message.fabric_train_simulator.depot.saved");
    }

    private static boolean saveSettings(class_3222 player, UpdatePayload payload, TrainDepotBlockEntity depot,
                                        RailwaySavedData data, RailwayDevice device, DepotTemplate template,
                                        TrainClass trainClass) {
        long displacedDepotId;
        try {
            displacedDepotId = data.bindDispatchDepot(device.id(), payload.lineId());
        } catch (IllegalArgumentException invalidBinding) {
            open(player, payload.pos(), depot, "message.fabric_train_simulator.depot.no_line");
            return false;
        }
        clearDisplacedDepotBinding(player, data, displacedDepotId, payload.lineId());
        data.updateDevice(device.id(), payload.name(), device.dwellSeconds(), device.switchShapeOrdinal(), device.announcement());
        depot.setTemplate(template);
        depot.configure(payload.lineId(), trainClass, payload.interval(), payload.maximum(),payload.cargoSpeedKmh(),
                payload.passengerSpeedKmh(),payload.expressSpeedKmh());
        if (payload.lineId() == 0L || data.line(payload.lineId()) == null
                || data.line(payload.lineId()).status() != cn.quit5700.fabrictrain.data.LineStatus.RUNNING)
            depot.setAutomaticDispatchEnabled(false);
        return true;
    }

    private static boolean canAccess(class_3222 player, class_2338 pos) {
        if (player.method_5649(pos.method_10263() + 0.5D, pos.method_10264() + 0.5D, pos.method_10260() + 0.5D) <= 64.0D)
            return true;
        return DepotRemoteAccessSessions.hasAccess(player.method_5667(),
                RailwayDataManager.dimension((class_3218) player.method_51469()), pos, System.nanoTime());
    }

    private static void denyAccess(class_3222 player) {
        cn.quit5700.fabrictrain.network.OperationChat.suppress(class_2561.method_43471("message.fabric_train_simulator.depot.remote_access_expired"));
    }

    private static String precheckKey(DepotDispatchPrecheck.Result result) {
        return switch (result) {
            case NO_LINE -> "message.fabric_train_simulator.depot.no_line";
            case MAXIMUM_REACHED -> "message.fabric_train_simulator.depot.maximum_reached";
            case PAUSED -> "message.fabric_train_simulator.depot.line_paused";
            case CLOSED -> "message.fabric_train_simulator.depot.line_closed";
            case MAINTENANCE -> "message.fabric_train_simulator.depot.line_maintenance";
            case NEEDS_VALIDATION -> "message.fabric_train_simulator.depot.validation_required";
            case READY -> "message.fabric_train_simulator.depot.success";
        };
    }

    private static String immediateValidationKey(WorldLineValidator.ImmediateDispatchStatus status) {
        return switch (status) {
            case FIRST_NODE_NOT_FOUND -> "message.fabric_train_simulator.depot.first_node_not_found";
            case STATION_STOP_UNBOUND -> "message.fabric_train_simulator.depot.station_stop_unbound";
            case TRACK_BROKEN -> "message.fabric_train_simulator.depot.track_broken";
            case UNPOWERED -> "message.fabric_train_simulator.depot.unpowered";
            case READY -> "message.fabric_train_simulator.depot.success";
        };
    }

    private static void clearDisplacedDepotBinding(class_3222 player, RailwaySavedData data,
                                                    long displacedDepotId, long lineId) {
        if (displacedDepotId == 0L) return;
        RailwayDevice displaced = data.device(displacedDepotId);
        if (displaced == null) return;
        for (class_3218 level : player.method_51469().method_8503().method_3738()) {
            if (!RailwayDataManager.dimension(level).equals(displaced.dimension())) continue;
            class_2338 displacedPos = new class_2338(displaced.x(), displaced.y(), displaced.z());
            if (level.method_22340(displacedPos)
                    && level.method_8321(displacedPos) instanceof TrainDepotBlockEntity oldDepot
                    && oldDepot.selectedLineId() == lineId) {
                oldDepot.setSelectedLineId(0L);
            }
            return;
        }
    }

    private static int pauseState(class_3222 player, RailwayLine line, RailwaySavedData data) {
        if (line == null) return -1;
        if (line.status() == LineStatus.RUNNING) return 0;
        if (line.status() != LineStatus.PAUSED) return -1;
        boolean found = false;
        boolean allHeld = true;
        for (class_1297 entity : player.method_51469().method_27909()) {
            if (!(entity instanceof LocomotiveEntity locomotive)
                    || locomotive.trainLink().lineId() != line.id()
                    || locomotive.trainLink().controlMode() != ControlMode.ROUTE_AUTOMATIC) continue;
            found = true;
            RailwayDevice last = data.device(locomotive.trainLink().lastDeviceId());
            if (locomotive.trainLink().automaticRunning() || last == null || last.type() != DeviceType.STATION)
                allHeld = false;
        }
        return !found || allHeld ? 2 : 1;
    }

    public record LineOption(long id, String name, int status) {}

    public record RequestOpenPayload(class_2338 pos) implements LegacyPayload{
        public static final Type<RequestOpenPayload> ID=new Type<>(FabricTrainMod.id("request_open_depot_settings"));
        public static final LegacyPayloadCodec<class_2540,RequestOpenPayload> CODEC=LegacyPayload.codec(
                (payload,buffer)->buffer.method_10807(payload.pos),buffer->new RequestOpenPayload(buffer.method_10811()));
        @Override public Type<? extends LegacyPayload> type(){return ID;}
    }

    public record RequestTrainListPayload(class_2338 pos) implements LegacyPayload {
        public static final Type<RequestTrainListPayload> ID = new Type<>(FabricTrainMod.id("request_depot_train_list"));
        public static final LegacyPayloadCodec<class_2540, RequestTrainListPayload> CODEC =
                LegacyPayload.codec((payload, buffer) -> buffer.method_10807(payload.pos),
                        buffer -> new RequestTrainListPayload(buffer.method_10811()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record DeleteTrainPayload(class_2338 pos, java.util.UUID trainId) implements LegacyPayload {
        public static final Type<DeleteTrainPayload> ID = new Type<>(FabricTrainMod.id("delete_depot_train"));
        public static final LegacyPayloadCodec<class_2540, DeleteTrainPayload> CODEC =
                LegacyPayload.codec((payload, buffer) -> {
                    buffer.method_10807(payload.pos);
                    buffer.method_10797(payload.trainId);
                }, buffer -> new DeleteTrainPayload(buffer.method_10811(), buffer.method_10790()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record ClosePayload(class_2338 pos) implements LegacyPayload {
        public static final Type<ClosePayload> ID = new Type<>(FabricTrainMod.id("close_depot_settings"));
        public static final LegacyPayloadCodec<class_2540, ClosePayload> CODEC =
                LegacyPayload.codec((payload, buffer) -> buffer.method_10807(payload.pos),
                        buffer -> new ClosePayload(buffer.method_10811()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record TrainListEntry(java.util.UUID trainId, long number, boolean automatic) {}

    public record TrainListPayload(class_2338 depotPos, List<TrainListEntry> trains) implements LegacyPayload {
        public static final Type<TrainListPayload> ID = new Type<>(FabricTrainMod.id("open_depot_train_list"));
        public static final LegacyPayloadCodec<class_2540, TrainListPayload> CODEC =
                LegacyPayload.codec(TrainListPayload::write, TrainListPayload::read);

        private void write(class_2540 buffer) {
            buffer.method_10807(depotPos);
            buffer.method_10804(trains.size());
            for (TrainListEntry train : trains) {
                buffer.method_10797(train.trainId());
                buffer.method_10791(train.number());
                buffer.writeBoolean(train.automatic());
            }
        }

        private static TrainListPayload read(class_2540 buffer) {
            class_2338 depotPos = buffer.method_10811();
            int count = cn.quit5700.fabrictrain.compat.MathCompat.clamp(buffer.method_10816(), 0, 10000);
            ArrayList<TrainListEntry> trains = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                trains.add(new TrainListEntry(buffer.method_10790(), buffer.method_10792(), buffer.readBoolean()));
            }
            return new TrainListPayload(depotPos, List.copyOf(trains));
        }

        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record OpenPayload(class_2338 pos, String name, String template, long lineId, int trainClass, int interval, int maximum,
                              long active,double cargoSpeedKmh,double passengerSpeedKmh,double expressSpeedKmh,
                              boolean automaticDispatchEnabled, int lineStatus, int pauseState,
                              int lastAutomaticDispatchResult,
                              String operationMessageKey,
                              List<LineOption> lines) implements LegacyPayload {
        public static final Type<OpenPayload> ID = new Type<>(FabricTrainMod.id("open_depot_settings"));
        public static final LegacyPayloadCodec<class_2540, OpenPayload> CODEC = LegacyPayload.codec(OpenPayload::write, OpenPayload::read);
        private void write(class_2540 b) {
            b.method_10807(pos); b.method_10788(name, 64); b.method_10788(template, 100); b.method_10791(lineId); b.method_10804(trainClass);
            b.method_10804(interval); b.method_10804(maximum); b.method_10791(active);
            b.writeDouble(cargoSpeedKmh);b.writeDouble(passengerSpeedKmh);b.writeDouble(expressSpeedKmh);b.writeBoolean(automaticDispatchEnabled);b.method_10804(lineStatus);b.method_10804(pauseState);b.method_10804(lastAutomaticDispatchResult);b.method_10788(operationMessageKey,128);b.method_10804(lines.size());
            for (LineOption line : lines) { b.method_10791(line.id()); b.method_10788(line.name(), 64); b.method_10804(line.status()); }
        }
        private static OpenPayload read(class_2540 b) {
            class_2338 pos=b.method_10811();String name=b.method_10800(64);String template=b.method_10800(100);long line=b.method_10792();int type=b.method_10816();
            int interval=b.method_10816(),maximum=b.method_10816();long active=b.method_10792();
            double cargoSpeed=b.readDouble(),passengerSpeed=b.readDouble(),expressSpeed=b.readDouble();boolean enabled=b.readBoolean();int lineStatus=b.method_10816();int pauseState=b.method_10816();int lastResult=b.method_10816();String operationMessageKey=b.method_10800(128);int size=cn.quit5700.fabrictrain.compat.MathCompat.clamp(b.method_10816(),0,1000);
            ArrayList<LineOption> lines=new ArrayList<>();for(int i=0;i<size;i++)lines.add(new LineOption(b.method_10792(),b.method_10800(64),b.method_10816()));
            return new OpenPayload(pos,name,template,line,type,interval,maximum,active,cargoSpeed,passengerSpeed,expressSpeed,enabled,lineStatus,pauseState,lastResult,operationMessageKey,List.copyOf(lines));
        }
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }

    public record UpdatePayload(class_2338 pos, String name, String template, long lineId, int trainClass, int interval,
                                int maximum,double cargoSpeedKmh,double passengerSpeedKmh,double expressSpeedKmh,
                                int action) implements LegacyPayload {
        public static final Type<UpdatePayload> ID = new Type<>(FabricTrainMod.id("update_depot_settings"));
        public static final LegacyPayloadCodec<class_2540, UpdatePayload> CODEC = LegacyPayload.codec(
                (p,b)->{b.method_10807(p.pos);b.method_10788(p.name,64);b.method_10788(p.template,100);b.method_10791(p.lineId);b.method_10804(p.trainClass);b.method_10804(p.interval);b.method_10804(p.maximum);b.writeDouble(p.cargoSpeedKmh);b.writeDouble(p.passengerSpeedKmh);b.writeDouble(p.expressSpeedKmh);b.method_10804(p.action);},
                b->new UpdatePayload(b.method_10811(),b.method_10800(64),b.method_10800(100),b.method_10792(),b.method_10816(),b.method_10816(),b.method_10816(),b.readDouble(),b.readDouble(),b.readDouble(),b.method_10816()));
        @Override public Type<? extends LegacyPayload> type() { return ID; }
    }
}



