package cn.quit5700.fabrictrain.entity;


import cn.quit5700.fabrictrain.compat.NbtCompat;
import cn.quit5700.fabrictrain.registry.ModItems;
import cn.quit5700.fabrictrain.train.LinkedTrainCar;
import cn.quit5700.fabrictrain.train.TrainLink;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1694;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import cn.quit5700.fabrictrain.registry.ModBlocks;
import cn.quit5700.fabrictrain.train.ConnectorInteractionService;
import cn.quit5700.fabrictrain.train.LogicallyControlledVehicle;

public final class CargoCarEntity extends class_1694 implements LinkedTrainCar, LogicallyControlledVehicle {
    private static final class_2940<Boolean> LOGICALLY_CONTROLLED =
            class_2945.method_12791(CargoCarEntity.class, class_2943.field_13323);
    private final TrainLink trainLink = new TrainLink();
    private long destinationStationId;
    private boolean ownTick;
    private int authorizedPushDepth;
    private int placementBrakeTicks = 40;
    public CargoCarEntity(class_1299<? extends class_1694> type, class_1937 level) {
        super(type, level);
    }

    @Override
    protected class_1792 method_42670() {
        return ModItems.CARGO_CAR;
    }

    @Override
    public class_1799 method_31480() {
        return new class_1799(ModItems.CARGO_CAR);
    }

    @Override public class_2680 method_7517() { return ModBlocks.CARGO_DISPLAY.method_9564(); }
    @Override public int method_7526() { return 6; }

    @Override public TrainLink trainLink() { return trainLink; }
    @Override protected void method_5693() {
        super.method_5693();
        field_6011.method_12784(LOGICALLY_CONTROLLED, false);
    }
    @Override public boolean fabricTrain$isLogicallyControlled() { return field_6011.method_12789(LOGICALLY_CONTROLLED); }
    @Override public void fabricTrain$setLogicallyControlled(boolean controlled) { field_6011.method_12778(LOGICALLY_CONTROLLED, controlled); }
    public void releasePlacementBrake() { placementBrakeTicks = 0; }
    @Override public class_1269 method_5688(class_1657 player, class_1268 hand) {
        class_1269 result = ConnectorInteractionService.rightClick(player, hand, this);
        return result != class_1269.field_5811 ? result : super.method_5688(player, hand);
    }
    @Override public void method_5697(class_1297 entity) {
        if (placementBrakeTicks > 0 || fabricTrain$isLogicallyControlled()) return;
        if (entity instanceof PassengerCarEntity || entity instanceof LocomotiveEntity) super.method_5697(entity);
    }
    public void beginAuthorizedPush() { authorizedPushDepth++; }
    public void endAuthorizedPush() { authorizedPushDepth = Math.max(0, authorizedPushDepth - 1); }
    private boolean movementAuthorized() { return ownTick || authorizedPushDepth > 0 || trainLink.hasLocomotive(); }
    @Override public void method_18799(class_243 movement) {
        if (movementAuthorized()) super.method_18799(movement);
    }
    @Override public void method_5762(double x, double y, double z) {
        if (movementAuthorized()) super.method_5762(x, y, z);
    }
    @Override public void method_5773() {
        class_243 before = method_19538();
        boolean linked = fabricTrain$isLogicallyControlled();
        boolean placementBraked = placementBrakeTicks > 0;
        ownTick = true;
        try { super.method_5773(); } finally { ownTick = false; }
        if (placementBraked) placementBrakeTicks--;
        if (LogicallyControlledVehicle.shouldRestorePosition(
                method_37908().method_8608(), linked, placementBraked)) {
            beginAuthorizedPush();
            try {
                method_33574(before);
                method_18799(class_243.field_1353);
            } finally { endAuthorizedPush(); }
        }
    }
    @Override public boolean method_5643(class_1282 source, float amount) {
        if (source.method_5529() instanceof class_1657 player && player.method_31549().field_7477) {
            method_31472();
            return true;
        }
        return super.method_5643(source, amount);
    }
    @Override public void method_5650(class_5529 reason) {
        if (method_37908() instanceof class_3218 serverLevel)
            cn.quit5700.fabrictrain.train.TrainControllerManager.noteVehicleRemoved(
                    serverLevel, trainLink.trainId(), method_5667(), reason);
        super.method_5650(reason);
    }
    public long destinationStationId() { return destinationStationId; }
    public void setDestinationStationId(long value) { destinationStationId = Math.max(0L, value); }
    @Override protected void method_5749(class_2487 input) { super.method_5749(input); trainLink.load(input); destinationStationId = Math.max(0L, NbtCompat.getLong(input, "DestinationStationId", 0L)); placementBrakeTicks = 0; }
    @Override protected void method_5652(class_2487 output) { super.method_5652(output); trainLink.save(output); output.method_10544("DestinationStationId", destinationStationId); }
}


