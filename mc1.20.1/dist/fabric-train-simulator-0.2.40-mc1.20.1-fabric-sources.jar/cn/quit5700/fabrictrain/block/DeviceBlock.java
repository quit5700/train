package cn.quit5700.fabrictrain.block;

import cn.quit5700.fabrictrain.data.DeviceType;
import cn.quit5700.fabrictrain.data.RailwayDataManager;
import cn.quit5700.fabrictrain.data.RailwayDevice;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class DeviceBlock extends class_2248 {
    private final DeviceType type;

    public DeviceBlock(class_2251 properties, DeviceType type) {
        super(properties);
        this.type = type;
    }
    @Override public void method_9567(class_1937 level,class_2338 pos,class_2680 state,net.minecraft.class_1309 placer,net.minecraft.class_1799 stack){super.method_9567(level,pos,state,placer,stack);if(level instanceof class_3218 serverLevel)RailwayDataManager.register(serverLevel,pos,type);}

    @Override
    public void method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        if (level instanceof class_3218 serverLevel) {
            RailwayDataManager.remove(serverLevel, pos);
        }
        super.method_9576(level, pos, state, player);
    }
}
