package cn.quit5700.fabrictrain.train;

import cn.quit5700.fabrictrain.FabricTrainMod;
import com.mojang.serialization.Codec;
import java.util.*;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2509;

public final class OfflineTrainSavedData extends class_18 {
    public static final Codec<OfflineTrainSavedData> CODEC = OfflineTrainState.CODEC.listOf()
            .optionalFieldOf("trains", List.of()).codec()
            .xmap(OfflineTrainSavedData::new, data -> List.copyOf(data.trains.values()));
    public static final String DATA_ID = FabricTrainMod.MOD_ID + "_offline_trains";

    private final Map<UUID, OfflineTrainState> trains = new LinkedHashMap<>();
    public OfflineTrainSavedData() {}
    private OfflineTrainSavedData(List<OfflineTrainState> values) {
        values.forEach(value -> trains.put(value.trainId(), value));
    }
    public synchronized void put(OfflineTrainState state) { trains.put(state.trainId(), state); method_80(); }
    public synchronized void remove(UUID trainId) { if (trains.remove(trainId) != null) method_80(); }
    public synchronized List<OfflineTrainState> trains() { return List.copyOf(trains.values()); }
    public synchronized OfflineTrainState get(UUID trainId) { return trains.get(trainId); }

    public static OfflineTrainSavedData load(class_2487 tag) {
        return CODEC.parse(class_2509.field_11560, tag)
                .result().orElseGet(OfflineTrainSavedData::new);
    }

    @Override public class_2487 method_75(class_2487 tag) {
        return CODEC.encodeStart(class_2509.field_11560, this)
                .result().filter(class_2487.class::isInstance).map(class_2487.class::cast).orElse(tag);
    }
}
