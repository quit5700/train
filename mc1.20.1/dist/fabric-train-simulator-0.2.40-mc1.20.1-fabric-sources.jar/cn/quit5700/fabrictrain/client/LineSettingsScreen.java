package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.data.LineStatus;
import cn.quit5700.fabrictrain.network.LineSettingsNetworking;
import cn.quit5700.fabrictrain.network.LegacyClientPlayNetworking;
import java.util.ArrayList;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class LineSettingsScreen extends class_437 {
    private static final int DESIRED_HEIGHT = 300;
    private final long lineId;
    private final ArrayList<Long> nodeIds;
    private int selectedNode;
    private int status;
    private int interval;
    private double speed;
    private int maximumTrains;
    private int scrollOffset;
    private class_342 lineName;
    private final String initialLineName;

    public LineSettingsScreen(LineSettingsNetworking.OpenPayload payload) {
        super(class_2561.method_43469("screen.fabric_train_simulator.line.title", payload.lineId()));
        lineId = payload.lineId();
        nodeIds = new ArrayList<>(payload.nodeIds());
        selectedNode = Math.min(1, Math.max(0, nodeIds.size() - 1));
        status = payload.statusOrdinal();
        interval = payload.intervalSeconds();
        speed = payload.speedKmh();
        maximumTrains = payload.maximumTrains();
        initialLineName = payload.name();
    }

    private ResponsiveScreenLayout layout() {
        return ResponsiveScreenLayout.of(field_22789, field_22790, 250, DESIRED_HEIGHT, 20);
    }

    @Override
    protected void method_25426() {
        ResponsiveScreenLayout layout = layout();
        int left = layout.left() + 10;
        int contentWidth = layout.panelWidth() - 20;
        int top = layout.top();
        if (lineName == null) {
            lineName = new class_342(field_22793, 0, 0, 210, 20, class_2561.method_43471("screen.fabric_train_simulator.line.name"));
            lineName.method_1880(64);
            lineName.method_1852(initialLineName);
        }
        int inputY = top + 28 - scrollOffset;
        lineName.method_48229(left, inputY);
        lineName.method_25358(contentWidth);
        addContent(lineName, layout);
        pair(layout, top + 62 - scrollOffset, "screen.fabric_train_simulator.line.minus_thirty", "screen.fabric_train_simulator.line.plus_thirty",
                () -> interval = Math.max(0, interval - 30), () -> interval = Math.min(3600, interval + 30));
        pair(layout, top + 88 - scrollOffset, "screen.fabric_train_simulator.line.minus_ten", "screen.fabric_train_simulator.line.plus_ten",
                () -> speed = Math.max(0, speed - 10), () -> speed += 10);
        pair(layout, top + 114 - scrollOffset, "screen.fabric_train_simulator.line.minus_one", "screen.fabric_train_simulator.line.plus_one",
                () -> maximumTrains = Math.max(1, maximumTrains - 1), () -> maximumTrains = Math.min(1000, maximumTrains + 1));
        int actionY = top + 148 - scrollOffset;
        int third = (contentWidth - 12) / 3;
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.status"),
                button -> status = (status + 1) % LineStatus.values().length).method_46434(left, actionY, third, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.refresh"),
                button -> send(true, false)).method_46434(left + 6 + third, actionY, third, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.delete"),
                button -> send(false, true)).method_46434(left + 12 + third * 2, actionY, third, 20).method_46431(), layout);
        controls(layout, top + 182 - scrollOffset, true);
        controls(layout, top + 208 - scrollOffset, false);
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.save"),
                button -> send(false, false)).method_46434(layout.left() + (layout.panelWidth() - 78) / 2,
                layout.footerY(), 78, 20).method_46431());
    }

    private void pair(ResponsiveScreenLayout layout, int y, String leftText, String rightText,
                      Runnable leftAction, Runnable rightAction) {
        int left = layout.left() + 10;
        int buttonWidth = Math.max(44, (layout.panelWidth() - 20) / 4);
        addContent(class_4185.method_46430(class_2561.method_43471(leftText), button -> leftAction.run())
                .method_46434(left, y, buttonWidth, 20).method_46431(), layout);
        addContent(class_4185.method_46430(class_2561.method_43471(rightText), button -> rightAction.run())
                .method_46434(layout.right() - 10 - buttonWidth, y, buttonWidth, 20).method_46431(), layout);
    }

    private void controls(ResponsiveScreenLayout layout, int y, boolean firstRow) {
        int left = layout.left() + 10;
        int contentWidth = layout.panelWidth() - 20;
        int third = (contentWidth - 12) / 3;
        if (firstRow) {
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.previous_node"),
                    button -> selectNode(-1)).method_46434(left, y, third, 20).method_46431(), layout);
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.move_up"),
                    button -> modifyNode(0)).method_46434(left + 6 + third, y, third, 20).method_46431(), layout);
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.next_node"),
                    button -> selectNode(1)).method_46434(left + 12 + third * 2, y, third, 20).method_46431(), layout);
        } else {
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.move_down"),
                    button -> modifyNode(1)).method_46434(left, y, third, 20).method_46431(), layout);
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.delete_node"),
                    button -> modifyNode(2)).method_46434(left + 6 + third, y, third, 20).method_46431(), layout);
            addContent(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.line.add_nodes"),
                    button -> beginEditing()).method_46434(left + 12 + third * 2, y, third, 20).method_46431(), layout);
        }
    }

    private <T extends class_339> T addContent(T widget, ResponsiveScreenLayout layout) {
        widget.field_22764 = widget.method_46427() >= layout.scrollTop() && widget.method_46427() + 20 <= layout.scrollBottom();
        return method_37063(widget);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double vertical) {
        ResponsiveScreenLayout layout = layout();
        if (!layout.scrollRequired()) return super.method_25401(mouseX, mouseY, vertical);
        int maximum = Math.max(0, DESIRED_HEIGHT - layout.panelHeight());
        int next = cn.quit5700.fabrictrain.compat.MathCompat.clamp(scrollOffset - (int) Math.signum(vertical) * 20, 0, maximum);
        if (next == scrollOffset) return false;
        scrollOffset = next;
        method_41843();
        return true;
    }

    private void send(boolean refresh, boolean delete) {
        LegacyClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.method_1882(), status,
                interval, speed, maximumTrains, refresh, delete, -1, -1, false));
        method_25419();
    }

    private void selectNode(int amount) {
        if (nodeIds.size() > 1) selectedNode = 1 + Math.floorMod(selectedNode - 1 + amount, nodeIds.size() - 1);
    }

    private void modifyNode(int action) {
        if (selectedNode <= 0 || selectedNode >= nodeIds.size()) return;
        LegacyClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.method_1882(), status,
                interval, speed, maximumTrains, false, false, selectedNode, action, false));
        if (action == 0 && selectedNode > 1) {
            java.util.Collections.swap(nodeIds, selectedNode, selectedNode - 1);
            selectedNode--;
        } else if (action == 1 && selectedNode < nodeIds.size() - 1) {
            java.util.Collections.swap(nodeIds, selectedNode, selectedNode + 1);
            selectedNode++;
        } else if (action == 2) {
            nodeIds.remove(selectedNode);
            selectedNode = Math.min(selectedNode, nodeIds.size() - 1);
        }
    }

    private void beginEditing() {
        LegacyClientPlayNetworking.send(new LineSettingsNetworking.UpdatePayload(lineId, lineName.method_1882(), status,
                interval, speed, maximumTrains, false, false, -1, -1, true));
        method_25419();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = layout();
        int top = layout.top();
        graphics.method_25294(layout.left(), top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_49601(layout.left(), top, layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 9, 0xFFFFFFFF);
        label(graphics, layout, class_2561.method_43469("screen.fabric_train_simulator.line.interval", interval), top + 68 - scrollOffset);
        label(graphics, layout, class_2561.method_43469("screen.fabric_train_simulator.line.speed", speed), top + 94 - scrollOffset);
        label(graphics, layout, class_2561.method_43469("screen.fabric_train_simulator.line.maximum", maximumTrains), top + 120 - scrollOffset);
        label(graphics, layout, class_2561.method_43469("screen.fabric_train_simulator.line.current_status",
                class_2561.method_43471("status.fabric_train_simulator." + LineStatus.values()[status].name().toLowerCase())), top + 136 - scrollOffset);
        if (!nodeIds.isEmpty()) label(graphics, layout, class_2561.method_43469(
                "screen.fabric_train_simulator.line.selected_node", selectedNode,
                nodeIds.get(Math.max(0, selectedNode))), top + 172 - scrollOffset);
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }

    private void label(class_332 graphics, ResponsiveScreenLayout layout, class_2561 text, int y) {
        if (y >= layout.scrollTop() && y + field_22793.field_2000 <= layout.scrollBottom())
            graphics.method_27534(field_22793, text, field_22789 / 2, y, 0xFFE6E6E6);
    }
}




