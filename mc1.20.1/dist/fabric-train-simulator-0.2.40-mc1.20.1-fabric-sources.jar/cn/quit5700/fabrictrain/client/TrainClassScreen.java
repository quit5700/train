package cn.quit5700.fabrictrain.client;

import cn.quit5700.fabrictrain.network.TrainClassNetworking;
import cn.quit5700.fabrictrain.train.TrainClass;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import cn.quit5700.fabrictrain.network.LegacyClientPlayNetworking;

public final class TrainClassScreen extends class_437 {
    private final int entityId;
    private final boolean hasCargo;
    private TrainClass selected;
    private final double freightSpeed;
    private final double passengerSpeed;
    private final double expressSpeed;
    private final java.util.List<TrainClassNetworking.Station> stations;
    /** Zero is no locomotive destination; stations start at one. */
    private int stationIndex;
    private int dropdownOffset;
    private boolean dropdownOpen;

    public TrainClassScreen(TrainClassNetworking.OpenPayload payload) {
        super(class_2561.method_43471("screen.fabric_train_simulator.train_class.title"));
        entityId = payload.entityId();
        hasCargo = payload.hasCargo();
        selected = TrainClass.values()[cn.quit5700.fabrictrain.compat.MathCompat.clamp(payload.trainClassOrdinal(), 0, TrainClass.values().length - 1)];
        freightSpeed = payload.freightSpeedKmh();
        passengerSpeed = payload.passengerSpeedKmh();
        expressSpeed = payload.expressSpeedKmh();
        stations = payload.stations();
        stationIndex = 0;
        for (int i = 0; i < stations.size(); i++)
            if (stations.get(i).id() == payload.destinationStationId()) stationIndex = i + 1;
    }

    @Override protected void method_25426() {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 240, 250, 20);
        int left = layout.left() + 10;
        int top = layout.top();
        int contentWidth = layout.panelWidth() - 20;
        int third = (contentWidth - 12) / 3;
        method_37063(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.passenger"),
                button -> choose(TrainClass.PASSENGER)).method_46434(left, top + 42, third, 20).method_46431()).field_22763 = !hasCargo;
        method_37063(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.cargo"),
                button -> choose(TrainClass.CARGO)).method_46434(left + 6 + third, top + 42, third, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("class.fabric_train_simulator.express"),
                button -> choose(TrainClass.EXPRESS)).method_46434(left + 12 + third * 2, top + 42, third, 20).method_46431()).field_22763 = !hasCargo;
        if (selected == TrainClass.CARGO) {
            method_37063(class_4185.method_46430(destinationLabel(), button -> {
                dropdownOpen = !dropdownOpen;
                method_41843();
            }).method_46434(left, top + 105, contentWidth, 20).method_46431());
            if (dropdownOpen) addDropdownOptions(layout, left, top + 127, contentWidth);
        }
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.fabric_train_simulator.train_class.save"),
                button -> save()).method_46434(layout.left() + (layout.panelWidth() - 70) / 2, layout.footerY(), 70, 20).method_46431());
    }

    private void addDropdownOptions(ResponsiveScreenLayout layout, int left, int firstY, int width) {
        int rows = Math.max(1, Math.min(4, (layout.footerY() - 20 - firstY) / 20));
        int count = stations.size() + 1;
        dropdownOffset = cn.quit5700.fabrictrain.compat.MathCompat.clamp(dropdownOffset, 0, Math.max(0, count - rows));
        for (int row = 0; row < rows && dropdownOffset + row < count; row++) {
            int option = dropdownOffset + row;
            class_2561 label = option == 0
                    ? class_2561.method_43471("screen.fabric_train_simulator.cargo.no_destination")
                    : class_2561.method_43470(stations.get(option - 1).name());
            method_37063(class_4185.method_46430(label, button -> {
                stationIndex = option;
                dropdownOpen = false;
                method_41843();
            }).method_46434(left, firstY + row * 20, width, 20).method_46431());
        }
    }

    private void choose(TrainClass trainClass) {
        selected = hasCargo ? TrainClass.CARGO : trainClass;
        dropdownOpen = false;
        method_41843();
    }

    private class_2561 destinationLabel() {
        class_2561 value = stationIndex == 0
                ? class_2561.method_43471("screen.fabric_train_simulator.cargo.no_destination")
                : class_2561.method_43470(stations.get(stationIndex - 1).name());
        return value.method_27661().method_27693(" ▼");
    }

    private void save() {
        long destination = stationIndex == 0 ? 0L : stations.get(stationIndex - 1).id();
        LegacyClientPlayNetworking.send(new TrainClassNetworking.UpdatePayload(entityId, selected.ordinal(),
                freightSpeed, passengerSpeed, expressSpeed, destination));
        method_25419();
    }

    @Override public boolean method_25401(double mouseX, double mouseY, double vertical) {
        if (!dropdownOpen) return super.method_25401(mouseX, mouseY, vertical);
        int next = cn.quit5700.fabrictrain.compat.MathCompat.clamp(dropdownOffset - (int) Math.signum(vertical), 0, Math.max(0, stations.size()));
        if (next == dropdownOffset) return false;
        dropdownOffset = next;
        method_41843();
        return true;
    }

    @Override public void method_25394(class_332 graphics, int mouseX, int mouseY, float tickProgress) {
        ResponsiveScreenLayout layout = ResponsiveScreenLayout.of(field_22789, field_22790, 240, 250, 20);
        int left = layout.left();
        int top = layout.top();
        graphics.method_25294(left, top, layout.right(), layout.bottom(), 0xE020232A);
        graphics.method_49601(left, top, layout.panelWidth(), layout.panelHeight(), 0xFF66CCFF);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, top + 10, 0xFFFFFFFF);
        graphics.method_27534(field_22793, class_2561.method_43469("screen.fabric_train_simulator.train_class.current",
                class_2561.method_43471("class.fabric_train_simulator." + selected.name().toLowerCase())),
                field_22789 / 2, top + 72, 0xFFE6E6E6);
        if (selected == TrainClass.CARGO)
            graphics.method_27535(field_22793, class_2561.method_43471("screen.fabric_train_simulator.cargo.destination_label"),
                    left + 10, top + 91, 0xFFCCCCCC);
        if (hasCargo && !dropdownOpen)
            graphics.method_27534(field_22793, class_2561.method_43471("screen.fabric_train_simulator.train_class.cargo_locked"),
                    field_22789 / 2, layout.footerY() - 14, 0xFFFFAA55);
        super.method_25394(graphics, mouseX, mouseY, tickProgress);
    }
}




